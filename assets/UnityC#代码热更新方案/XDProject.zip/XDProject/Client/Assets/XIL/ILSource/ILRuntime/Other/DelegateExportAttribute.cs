#if USE_HOTnamespace ILRuntime.Other
{
    /// <summary>
    /// A Delegate Custom Attr, It tells the CodeGenerationTools : this delegate need to register a delegate convertor,when generate ILRuntimeHelper.cs file.
    /// </summary>
    public class DelegateExportAttribute : System.Attribute
    {
    }
}
#endif