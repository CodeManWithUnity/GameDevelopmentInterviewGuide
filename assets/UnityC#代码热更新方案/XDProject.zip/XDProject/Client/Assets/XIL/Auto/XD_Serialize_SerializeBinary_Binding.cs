#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_Serialize_SerializeBinary_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.Serialize.SerializeBinary);
            args = new Type[]{typeof(System.Type), typeof(System.Func<System.IO.BinaryReader, System.Object>)};
            method = type.GetMethod("RegistCustormReader", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RegistCustormReader_0);
            args = new Type[]{typeof(System.Type), typeof(System.Func<System.IO.BinaryReader, System.Object>)};
            method = type.GetMethod("RemoveCustormReader", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemoveCustormReader_1);
            args = new Type[]{typeof(System.Type), typeof(System.Action<System.IO.BinaryWriter, System.Object>)};
            method = type.GetMethod("RegistCustormWriter", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RegistCustormWriter_2);
            args = new Type[]{typeof(System.Type), typeof(System.Action<System.IO.BinaryWriter, System.Object>)};
            method = type.GetMethod("RemoveCustormReader", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemoveCustormReader_3);
            args = new Type[]{typeof(System.IO.Stream), typeof(System.Type), typeof(System.Type)};
            method = type.GetMethod("Serialize", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Serialize_4);
            args = new Type[]{typeof(System.Object), typeof(System.Type), typeof(System.IO.Stream)};
            method = type.GetMethod("Deserialize", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Deserialize_5);

            field = type.GetField("Tag", flag);
            app.RegisterCLRFieldGetter(field, get_Tag_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Tag_0, null);
            field = type.GetField("flag", flag);
            app.RegisterCLRFieldGetter(field, get_flag_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_flag_1, null);




        }


        static StackObject* RegistCustormReader_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Func<System.IO.BinaryReader, System.Object> @func = (System.Func<System.IO.BinaryReader, System.Object>)typeof(System.Func<System.IO.BinaryReader, System.Object>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @t = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Serialize.SerializeBinary.RegistCustormReader(@t, @func);

            return __ret;
        }

        static StackObject* RemoveCustormReader_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Func<System.IO.BinaryReader, System.Object> @func = (System.Func<System.IO.BinaryReader, System.Object>)typeof(System.Func<System.IO.BinaryReader, System.Object>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @t = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Serialize.SerializeBinary.RemoveCustormReader(@t, @func);

            return __ret;
        }

        static StackObject* RegistCustormWriter_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<System.IO.BinaryWriter, System.Object> @func = (System.Action<System.IO.BinaryWriter, System.Object>)typeof(System.Action<System.IO.BinaryWriter, System.Object>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @t = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Serialize.SerializeBinary.RegistCustormWriter(@t, @func);

            return __ret;
        }

        static StackObject* RemoveCustormReader_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<System.IO.BinaryWriter, System.Object> @func = (System.Action<System.IO.BinaryWriter, System.Object>)typeof(System.Action<System.IO.BinaryWriter, System.Object>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @t = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Serialize.SerializeBinary.RemoveCustormReader(@t, @func);

            return __ret;
        }

        static StackObject* Serialize_4(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Type @att = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @type = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.IO.Stream @input = (System.IO.Stream)typeof(System.IO.Stream).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Serialize.SerializeBinary.Serialize(@input, @type, @att);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance, true);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method, true);
        }

        static StackObject* Deserialize_5(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.IO.Stream @output = (System.IO.Stream)typeof(System.IO.Stream).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Type @att = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Object @t = (System.Object)typeof(System.Object).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Serialize.SerializeBinary.Deserialize(@t, @att, @output);

            return __ret;
        }


        static object get_Tag_0(ref object o)
        {
            return XD.Serialize.SerializeBinary.Tag;
        }

        static StackObject* CopyToStack_Tag_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Serialize.SerializeBinary.Tag;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_flag_1(ref object o)
        {
            return XD.Serialize.SerializeBinary.flag;
        }

        static StackObject* CopyToStack_flag_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Serialize.SerializeBinary.flag;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }




    }
}
#endif
