#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_ITweenFunction_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.ITweenFunction);
            args = new Type[]{typeof(System.Single), typeof(System.Single), typeof(XD.tool.ITweenFunction.EaseType), typeof(System.Single), typeof(System.Action)};
            method = type.GetMethod("SetParam", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SetParam_0);
            args = new Type[]{typeof(System.Single)};
            method = type.GetMethod("Update", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Update_1);
            args = new Type[]{};
            method = type.GetMethod("GetStep", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetStep_2);
            args = new Type[]{};
            method = type.GetMethod("IsOver", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, IsOver_3);

            field = type.GetField("time", flag);
            app.RegisterCLRFieldGetter(field, get_time_0);
            app.RegisterCLRFieldSetter(field, set_time_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_time_0, AssignFromStack_time_0);
            field = type.GetField("easeType", flag);
            app.RegisterCLRFieldGetter(field, get_easeType_1);
            app.RegisterCLRFieldSetter(field, set_easeType_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeType_1, AssignFromStack_easeType_1);
            field = type.GetField("start", flag);
            app.RegisterCLRFieldGetter(field, get_start_2);
            app.RegisterCLRFieldSetter(field, set_start_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_start_2, AssignFromStack_start_2);
            field = type.GetField("end", flag);
            app.RegisterCLRFieldGetter(field, get_end_3);
            app.RegisterCLRFieldSetter(field, set_end_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_end_3, AssignFromStack_end_3);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.tool.ITweenFunction());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.tool.ITweenFunction[s]);

            args = new Type[]{};
            method = type.GetConstructor(flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Ctor_0);

        }


        static StackObject* SetParam_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 6);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action @complete = (System.Action)typeof(System.Action).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Single @time = *(float*)&ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            XD.tool.ITweenFunction.EaseType @easeType = (XD.tool.ITweenFunction.EaseType)typeof(XD.tool.ITweenFunction.EaseType).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 4);
            System.Single @end = *(float*)&ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 5);
            System.Single @start = *(float*)&ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 6);
            XD.tool.ITweenFunction instance_of_this_method = (XD.tool.ITweenFunction)typeof(XD.tool.ITweenFunction).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            instance_of_this_method.SetParam(@start, @end, @easeType, @time, @complete);

            return __ret;
        }

        static StackObject* Update_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Single @t = *(float*)&ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            XD.tool.ITweenFunction instance_of_this_method = (XD.tool.ITweenFunction)typeof(XD.tool.ITweenFunction).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            var result_of_this_method = instance_of_this_method.Update(@t);

            __ret->ObjectType = ObjectTypes.Float;
            *(float*)&__ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static StackObject* GetStep_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            XD.tool.ITweenFunction instance_of_this_method = (XD.tool.ITweenFunction)typeof(XD.tool.ITweenFunction).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            var result_of_this_method = instance_of_this_method.GetStep();

            __ret->ObjectType = ObjectTypes.Float;
            *(float*)&__ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static StackObject* IsOver_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            XD.tool.ITweenFunction instance_of_this_method = (XD.tool.ITweenFunction)typeof(XD.tool.ITweenFunction).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            var result_of_this_method = instance_of_this_method.IsOver();

            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }


        static object get_time_0(ref object o)
        {
            return ((XD.tool.ITweenFunction)o).time;
        }

        static StackObject* CopyToStack_time_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.ITweenFunction)o).time;
            __ret->ObjectType = ObjectTypes.Float;
            *(float*)&__ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static void set_time_0(ref object o, object v)
        {
            ((XD.tool.ITweenFunction)o).time = (System.Single)v;
        }

        static StackObject* AssignFromStack_time_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Single @time = *(float*)&ptr_of_this_method->Value;
            ((XD.tool.ITweenFunction)o).time = @time;
            return ptr_of_this_method;
        }

        static object get_easeType_1(ref object o)
        {
            return ((XD.tool.ITweenFunction)o).easeType;
        }

        static StackObject* CopyToStack_easeType_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.ITweenFunction)o).easeType;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_easeType_1(ref object o, object v)
        {
            ((XD.tool.ITweenFunction)o).easeType = (XD.tool.ITweenFunction.EaseType)v;
        }

        static StackObject* AssignFromStack_easeType_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            XD.tool.ITweenFunction.EaseType @easeType = (XD.tool.ITweenFunction.EaseType)typeof(XD.tool.ITweenFunction.EaseType).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.tool.ITweenFunction)o).easeType = @easeType;
            return ptr_of_this_method;
        }

        static object get_start_2(ref object o)
        {
            return ((XD.tool.ITweenFunction)o).start;
        }

        static StackObject* CopyToStack_start_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.ITweenFunction)o).start;
            __ret->ObjectType = ObjectTypes.Float;
            *(float*)&__ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static void set_start_2(ref object o, object v)
        {
            ((XD.tool.ITweenFunction)o).start = (System.Single)v;
        }

        static StackObject* AssignFromStack_start_2(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Single @start = *(float*)&ptr_of_this_method->Value;
            ((XD.tool.ITweenFunction)o).start = @start;
            return ptr_of_this_method;
        }

        static object get_end_3(ref object o)
        {
            return ((XD.tool.ITweenFunction)o).end;
        }

        static StackObject* CopyToStack_end_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.ITweenFunction)o).end;
            __ret->ObjectType = ObjectTypes.Float;
            *(float*)&__ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static void set_end_3(ref object o, object v)
        {
            ((XD.tool.ITweenFunction)o).end = (System.Single)v;
        }

        static StackObject* AssignFromStack_end_3(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Single @end = *(float*)&ptr_of_this_method->Value;
            ((XD.tool.ITweenFunction)o).end = @end;
            return ptr_of_this_method;
        }



        static StackObject* Ctor_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);

            var result_of_this_method = new XD.tool.ITweenFunction();

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


    }
}
#endif
