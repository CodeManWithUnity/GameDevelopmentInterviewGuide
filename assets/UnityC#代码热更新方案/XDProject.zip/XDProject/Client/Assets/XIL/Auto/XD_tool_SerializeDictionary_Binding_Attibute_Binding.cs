#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_SerializeDictionary_Binding_Attibute_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.SerializeDictionary.Attibute);

            field = type.GetField("names", flag);
            app.RegisterCLRFieldGetter(field, get_names_0);
            app.RegisterCLRFieldSetter(field, set_names_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_names_0, AssignFromStack_names_0);


            app.RegisterCLRCreateArrayInstance(type, s => new XD.tool.SerializeDictionary.Attibute[s]);

            args = new Type[]{typeof(System.String[])};
            method = type.GetConstructor(flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Ctor_0);

        }



        static object get_names_0(ref object o)
        {
            return ((XD.tool.SerializeDictionary.Attibute)o).names;
        }

        static StackObject* CopyToStack_names_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.SerializeDictionary.Attibute)o).names;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_names_0(ref object o, object v)
        {
            ((XD.tool.SerializeDictionary.Attibute)o).names = (System.String[])v;
        }

        static StackObject* AssignFromStack_names_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.String[] @names = (System.String[])typeof(System.String[]).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.tool.SerializeDictionary.Attibute)o).names = @names;
            return ptr_of_this_method;
        }



        static StackObject* Ctor_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);
            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String[] @names = (System.String[])typeof(System.String[]).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = new XD.tool.SerializeDictionary.Attibute(@names);

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


    }
}
#endif
