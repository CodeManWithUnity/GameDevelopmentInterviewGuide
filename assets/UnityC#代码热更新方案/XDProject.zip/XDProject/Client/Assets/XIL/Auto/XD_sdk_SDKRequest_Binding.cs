#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_SDKRequest_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.SDKRequest);

            field = type.GetField("Init", flag);
            app.RegisterCLRFieldGetter(field, get_Init_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Init_0, null);
            field = type.GetField("CreateProduct", flag);
            app.RegisterCLRFieldGetter(field, get_CreateProduct_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_CreateProduct_1, null);
            field = type.GetField("Purchase", flag);
            app.RegisterCLRFieldGetter(field, get_Purchase_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Purchase_2, null);
            field = type.GetField("MoreGame", flag);
            app.RegisterCLRFieldGetter(field, get_MoreGame_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_MoreGame_3, null);
            field = type.GetField("Exit", flag);
            app.RegisterCLRFieldGetter(field, get_Exit_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_Exit_4, null);
            field = type.GetField("Quit", flag);
            app.RegisterCLRFieldGetter(field, get_Quit_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_Quit_5, null);
            field = type.GetField("Logout", flag);
            app.RegisterCLRFieldGetter(field, get_Logout_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_Logout_6, null);
            field = type.GetField("Login", flag);
            app.RegisterCLRFieldGetter(field, get_Login_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_Login_7, null);
            field = type.GetField("UserCenter", flag);
            app.RegisterCLRFieldGetter(field, get_UserCenter_8);
            app.RegisterCLRFieldBinding(field, CopyToStack_UserCenter_8, null);
            field = type.GetField("Event", flag);
            app.RegisterCLRFieldGetter(field, get_Event_9);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_9, null);
            field = type.GetField("BindAccount", flag);
            app.RegisterCLRFieldGetter(field, get_BindAccount_10);
            app.RegisterCLRFieldBinding(field, CopyToStack_BindAccount_10, null);
            field = type.GetField("SwitchAccount", flag);
            app.RegisterCLRFieldGetter(field, get_SwitchAccount_11);
            app.RegisterCLRFieldBinding(field, CopyToStack_SwitchAccount_11, null);
            field = type.GetField("RoleData", flag);
            app.RegisterCLRFieldGetter(field, get_RoleData_12);
            app.RegisterCLRFieldBinding(field, CopyToStack_RoleData_12, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.sdk.SDKRequest());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.SDKRequest[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.sdk.SDKRequest instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.sdk.SDKRequest[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_Init_0(ref object o)
        {
            return XD.sdk.SDKRequest.Init;
        }

        static StackObject* CopyToStack_Init_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Init;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_CreateProduct_1(ref object o)
        {
            return XD.sdk.SDKRequest.CreateProduct;
        }

        static StackObject* CopyToStack_CreateProduct_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.CreateProduct;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Purchase_2(ref object o)
        {
            return XD.sdk.SDKRequest.Purchase;
        }

        static StackObject* CopyToStack_Purchase_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Purchase;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_MoreGame_3(ref object o)
        {
            return XD.sdk.SDKRequest.MoreGame;
        }

        static StackObject* CopyToStack_MoreGame_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.MoreGame;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Exit_4(ref object o)
        {
            return XD.sdk.SDKRequest.Exit;
        }

        static StackObject* CopyToStack_Exit_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Exit;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Quit_5(ref object o)
        {
            return XD.sdk.SDKRequest.Quit;
        }

        static StackObject* CopyToStack_Quit_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Quit;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Logout_6(ref object o)
        {
            return XD.sdk.SDKRequest.Logout;
        }

        static StackObject* CopyToStack_Logout_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Logout;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Login_7(ref object o)
        {
            return XD.sdk.SDKRequest.Login;
        }

        static StackObject* CopyToStack_Login_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Login;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_UserCenter_8(ref object o)
        {
            return XD.sdk.SDKRequest.UserCenter;
        }

        static StackObject* CopyToStack_UserCenter_8(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.UserCenter;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Event_9(ref object o)
        {
            return XD.sdk.SDKRequest.Event;
        }

        static StackObject* CopyToStack_Event_9(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.Event;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_BindAccount_10(ref object o)
        {
            return XD.sdk.SDKRequest.BindAccount;
        }

        static StackObject* CopyToStack_BindAccount_10(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.BindAccount;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_SwitchAccount_11(ref object o)
        {
            return XD.sdk.SDKRequest.SwitchAccount;
        }

        static StackObject* CopyToStack_SwitchAccount_11(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.SwitchAccount;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_RoleData_12(ref object o)
        {
            return XD.sdk.SDKRequest.RoleData;
        }

        static StackObject* CopyToStack_RoleData_12(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKRequest.RoleData;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.sdk.SDKRequest();
            ins = (XD.sdk.SDKRequest)o;
            return ins;
        }


    }
}
#endif
