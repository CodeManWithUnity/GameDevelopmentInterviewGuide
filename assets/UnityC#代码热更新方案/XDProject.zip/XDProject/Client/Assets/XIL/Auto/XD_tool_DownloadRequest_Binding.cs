#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_DownloadRequest_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.DownloadRequest);
            args = new Type[]{typeof(System.String)};
            method = type.GetMethod("GetPersistent", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetPersistent_0);
            args = new Type[]{typeof(System.String)};
            method = type.GetMethod("Delete", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Delete_1);
            args = new Type[]{typeof(System.String), typeof(System.String), typeof(System.Action<System.String, System.Boolean>), typeof(System.Action<System.Single>), typeof(System.Boolean), typeof(System.Int32), typeof(System.Int32)};
            method = type.GetMethod("Request", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Request_2);
            args = new Type[]{typeof(System.String), typeof(System.String), typeof(System.Action<System.String, System.Boolean>), typeof(System.Action<System.Single>), typeof(System.String), typeof(System.Int32), typeof(System.Int32)};
            method = type.GetMethod("Request", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Request_3);

            field = type.GetField("Tag", flag);
            app.RegisterCLRFieldGetter(field, get_Tag_0);
            app.RegisterCLRFieldSetter(field, set_Tag_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Tag_0, AssignFromStack_Tag_0);
            field = type.GetField("use_url_request", flag);
            app.RegisterCLRFieldGetter(field, get_use_url_request_1);
            app.RegisterCLRFieldSetter(field, set_use_url_request_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_use_url_request_1, AssignFromStack_use_url_request_1);
            field = type.GetField("use_url_request_varify", flag);
            app.RegisterCLRFieldGetter(field, get_use_url_request_varify_2);
            app.RegisterCLRFieldSetter(field, set_use_url_request_varify_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_use_url_request_varify_2, AssignFromStack_use_url_request_varify_2);




        }


        static StackObject* GetPersistent_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @path = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.tool.DownloadRequest.GetPersistent(@path);

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* Delete_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @savepath = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.tool.DownloadRequest.Delete(@savepath);

            return __ret;
        }

        static StackObject* Request_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 7);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @timeout = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Int32 @retry_count = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Boolean @url_vesion = ptr_of_this_method->Value == 1;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 4);
            System.Action<System.Single> @progress = (System.Action<System.Single>)typeof(System.Action<System.Single>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 5);
            System.Action<System.String, System.Boolean> @callback = (System.Action<System.String, System.Boolean>)typeof(System.Action<System.String, System.Boolean>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 6);
            System.String @savepath = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 7);
            System.String @url = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.tool.DownloadRequest.Request(@url, @savepath, @callback, @progress, @url_vesion, @retry_count, @timeout);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* Request_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 7);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @timeout = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Int32 @retry_count = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.String @version = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 4);
            System.Action<System.Single> @progress = (System.Action<System.Single>)typeof(System.Action<System.Single>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 5);
            System.Action<System.String, System.Boolean> @callback = (System.Action<System.String, System.Boolean>)typeof(System.Action<System.String, System.Boolean>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 6);
            System.String @savepath = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 7);
            System.String @url = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.tool.DownloadRequest.Request(@url, @savepath, @callback, @progress, @version, @retry_count, @timeout);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object get_Tag_0(ref object o)
        {
            return XD.tool.DownloadRequest.Tag;
        }

        static StackObject* CopyToStack_Tag_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.DownloadRequest.Tag;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_Tag_0(ref object o, object v)
        {
            XD.tool.DownloadRequest.Tag = (System.String)v;
        }

        static StackObject* AssignFromStack_Tag_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.String @Tag = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            XD.tool.DownloadRequest.Tag = @Tag;
            return ptr_of_this_method;
        }

        static object get_use_url_request_1(ref object o)
        {
            return XD.tool.DownloadRequest.use_url_request;
        }

        static StackObject* CopyToStack_use_url_request_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.DownloadRequest.use_url_request;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_use_url_request_1(ref object o, object v)
        {
            XD.tool.DownloadRequest.use_url_request = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_use_url_request_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @use_url_request = ptr_of_this_method->Value == 1;
            XD.tool.DownloadRequest.use_url_request = @use_url_request;
            return ptr_of_this_method;
        }

        static object get_use_url_request_varify_2(ref object o)
        {
            return XD.tool.DownloadRequest.use_url_request_varify;
        }

        static StackObject* CopyToStack_use_url_request_varify_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.DownloadRequest.use_url_request_varify;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_use_url_request_varify_2(ref object o, object v)
        {
            XD.tool.DownloadRequest.use_url_request_varify = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_use_url_request_varify_2(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @use_url_request_varify = ptr_of_this_method->Value == 1;
            XD.tool.DownloadRequest.use_url_request_varify = @use_url_request_varify;
            return ptr_of_this_method;
        }




    }
}
#endif
