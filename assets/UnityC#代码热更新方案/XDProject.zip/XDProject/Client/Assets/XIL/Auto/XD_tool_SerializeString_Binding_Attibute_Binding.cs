#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_SerializeString_Binding_Attibute_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.SerializeString.Attibute);

            field = type.GetField("array", flag);
            app.RegisterCLRFieldGetter(field, get_array_0);
            app.RegisterCLRFieldSetter(field, set_array_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_array_0, AssignFromStack_array_0);
            field = type.GetField("index", flag);
            app.RegisterCLRFieldGetter(field, get_index_1);
            app.RegisterCLRFieldSetter(field, set_index_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_index_1, AssignFromStack_index_1);


            app.RegisterCLRCreateArrayInstance(type, s => new XD.tool.SerializeString.Attibute[s]);

            args = new Type[]{typeof(System.Int32), typeof(System.Int32)};
            method = type.GetConstructor(flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Ctor_0);

        }



        static object get_array_0(ref object o)
        {
            return ((XD.tool.SerializeString.Attibute)o).array;
        }

        static StackObject* CopyToStack_array_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.SerializeString.Attibute)o).array;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static void set_array_0(ref object o, object v)
        {
            ((XD.tool.SerializeString.Attibute)o).array = (System.Int32)v;
        }

        static StackObject* AssignFromStack_array_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Int32 @array = ptr_of_this_method->Value;
            ((XD.tool.SerializeString.Attibute)o).array = @array;
            return ptr_of_this_method;
        }

        static object get_index_1(ref object o)
        {
            return ((XD.tool.SerializeString.Attibute)o).index;
        }

        static StackObject* CopyToStack_index_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.tool.SerializeString.Attibute)o).index;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static void set_index_1(ref object o, object v)
        {
            ((XD.tool.SerializeString.Attibute)o).index = (System.Int32)v;
        }

        static StackObject* AssignFromStack_index_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Int32 @index = ptr_of_this_method->Value;
            ((XD.tool.SerializeString.Attibute)o).index = @index;
            return ptr_of_this_method;
        }



        static StackObject* Ctor_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);
            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @array = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Int32 @index = ptr_of_this_method->Value;


            var result_of_this_method = new XD.tool.SerializeString.Attibute(@index, @array);

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


    }
}
#endif
