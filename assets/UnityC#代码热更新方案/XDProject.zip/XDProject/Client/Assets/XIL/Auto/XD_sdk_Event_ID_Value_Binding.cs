#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_Event_ID_Value_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.Event_ID_Value);

            field = type.GetField("Event_Share", flag);
            app.RegisterCLRFieldGetter(field, get_Event_Share_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_Share_0, null);
            field = type.GetField("Event_URI", flag);
            app.RegisterCLRFieldGetter(field, get_Event_URI_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_URI_1, null);
            field = type.GetField("Event_User_Center", flag);
            app.RegisterCLRFieldGetter(field, get_Event_User_Center_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_User_Center_2, null);
            field = type.GetField("Event_More_Game", flag);
            app.RegisterCLRFieldGetter(field, get_Event_More_Game_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_More_Game_3, null);
            field = type.GetField("Event_Floating_Window", flag);
            app.RegisterCLRFieldGetter(field, get_Event_Floating_Window_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_Floating_Window_4, null);
            field = type.GetField("User_Reg", flag);
            app.RegisterCLRFieldGetter(field, get_User_Reg_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Reg_5, null);
            field = type.GetField("User_Login", flag);
            app.RegisterCLRFieldGetter(field, get_User_Login_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Login_6, null);
            field = type.GetField("User_Create_Role", flag);
            app.RegisterCLRFieldGetter(field, get_User_Create_Role_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Create_Role_7, null);
            field = type.GetField("User_Purchase_Order", flag);
            app.RegisterCLRFieldGetter(field, get_User_Purchase_Order_8);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Purchase_Order_8, null);
            field = type.GetField("User_Purchase", flag);
            app.RegisterCLRFieldGetter(field, get_User_Purchase_9);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Purchase_9, null);
            field = type.GetField("User_Logout", flag);
            app.RegisterCLRFieldGetter(field, get_User_Logout_10);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Logout_10, null);
            field = type.GetField("User_Enter_Server", flag);
            app.RegisterCLRFieldGetter(field, get_User_Enter_Server_11);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Enter_Server_11, null);
            field = type.GetField("User_Level_Up", flag);
            app.RegisterCLRFieldGetter(field, get_User_Level_Up_12);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Level_Up_12, null);
            field = type.GetField("User_Other", flag);
            app.RegisterCLRFieldGetter(field, get_User_Other_13);
            app.RegisterCLRFieldBinding(field, CopyToStack_User_Other_13, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.sdk.Event_ID_Value());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.Event_ID_Value[s]);

            args = new Type[]{};
            method = type.GetConstructor(flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Ctor_0);

        }



        static object get_Event_Share_0(ref object o)
        {
            return XD.sdk.Event_ID_Value.Event_Share;
        }

        static StackObject* CopyToStack_Event_Share_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.Event_Share;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_Event_URI_1(ref object o)
        {
            return XD.sdk.Event_ID_Value.Event_URI;
        }

        static StackObject* CopyToStack_Event_URI_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.Event_URI;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_Event_User_Center_2(ref object o)
        {
            return XD.sdk.Event_ID_Value.Event_User_Center;
        }

        static StackObject* CopyToStack_Event_User_Center_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.Event_User_Center;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_Event_More_Game_3(ref object o)
        {
            return XD.sdk.Event_ID_Value.Event_More_Game;
        }

        static StackObject* CopyToStack_Event_More_Game_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.Event_More_Game;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_Event_Floating_Window_4(ref object o)
        {
            return XD.sdk.Event_ID_Value.Event_Floating_Window;
        }

        static StackObject* CopyToStack_Event_Floating_Window_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.Event_Floating_Window;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Reg_5(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Reg;
        }

        static StackObject* CopyToStack_User_Reg_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Reg;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Login_6(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Login;
        }

        static StackObject* CopyToStack_User_Login_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Login;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Create_Role_7(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Create_Role;
        }

        static StackObject* CopyToStack_User_Create_Role_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Create_Role;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Purchase_Order_8(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Purchase_Order;
        }

        static StackObject* CopyToStack_User_Purchase_Order_8(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Purchase_Order;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Purchase_9(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Purchase;
        }

        static StackObject* CopyToStack_User_Purchase_9(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Purchase;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Logout_10(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Logout;
        }

        static StackObject* CopyToStack_User_Logout_10(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Logout;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Enter_Server_11(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Enter_Server;
        }

        static StackObject* CopyToStack_User_Enter_Server_11(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Enter_Server;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Level_Up_12(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Level_Up;
        }

        static StackObject* CopyToStack_User_Level_Up_12(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Level_Up;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }

        static object get_User_Other_13(ref object o)
        {
            return XD.sdk.Event_ID_Value.User_Other;
        }

        static StackObject* CopyToStack_User_Other_13(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.Event_ID_Value.User_Other;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method;
            return __ret + 1;
        }



        static StackObject* Ctor_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);

            var result_of_this_method = new XD.sdk.Event_ID_Value();

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


    }
}
#endif
