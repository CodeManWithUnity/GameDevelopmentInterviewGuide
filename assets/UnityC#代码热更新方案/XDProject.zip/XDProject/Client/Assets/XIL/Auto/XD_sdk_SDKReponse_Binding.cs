#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_SDKReponse_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.SDKReponse);

            field = type.GetField("Init", flag);
            app.RegisterCLRFieldGetter(field, get_Init_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Init_0, null);
            field = type.GetField("Login", flag);
            app.RegisterCLRFieldGetter(field, get_Login_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Login_1, null);
            field = type.GetField("CreateProduct", flag);
            app.RegisterCLRFieldGetter(field, get_CreateProduct_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_CreateProduct_2, null);
            field = type.GetField("Purchase", flag);
            app.RegisterCLRFieldGetter(field, get_Purchase_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_Purchase_3, null);
            field = type.GetField("Logout", flag);
            app.RegisterCLRFieldGetter(field, get_Logout_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_Logout_4, null);
            field = type.GetField("Exit", flag);
            app.RegisterCLRFieldGetter(field, get_Exit_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_Exit_5, null);
            field = type.GetField("Event", flag);
            app.RegisterCLRFieldGetter(field, get_Event_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_Event_6, null);
            field = type.GetField("BindAccount", flag);
            app.RegisterCLRFieldGetter(field, get_BindAccount_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_BindAccount_7, null);
            field = type.GetField("SwitchAccount", flag);
            app.RegisterCLRFieldGetter(field, get_SwitchAccount_8);
            app.RegisterCLRFieldBinding(field, CopyToStack_SwitchAccount_8, null);
            field = type.GetField("RoleData", flag);
            app.RegisterCLRFieldGetter(field, get_RoleData_9);
            app.RegisterCLRFieldBinding(field, CopyToStack_RoleData_9, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.sdk.SDKReponse());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.SDKReponse[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.sdk.SDKReponse instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.sdk.SDKReponse[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_Init_0(ref object o)
        {
            return XD.sdk.SDKReponse.Init;
        }

        static StackObject* CopyToStack_Init_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Init;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Login_1(ref object o)
        {
            return XD.sdk.SDKReponse.Login;
        }

        static StackObject* CopyToStack_Login_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Login;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_CreateProduct_2(ref object o)
        {
            return XD.sdk.SDKReponse.CreateProduct;
        }

        static StackObject* CopyToStack_CreateProduct_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.CreateProduct;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Purchase_3(ref object o)
        {
            return XD.sdk.SDKReponse.Purchase;
        }

        static StackObject* CopyToStack_Purchase_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Purchase;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Logout_4(ref object o)
        {
            return XD.sdk.SDKReponse.Logout;
        }

        static StackObject* CopyToStack_Logout_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Logout;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Exit_5(ref object o)
        {
            return XD.sdk.SDKReponse.Exit;
        }

        static StackObject* CopyToStack_Exit_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Exit;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Event_6(ref object o)
        {
            return XD.sdk.SDKReponse.Event;
        }

        static StackObject* CopyToStack_Event_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.Event;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_BindAccount_7(ref object o)
        {
            return XD.sdk.SDKReponse.BindAccount;
        }

        static StackObject* CopyToStack_BindAccount_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.BindAccount;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_SwitchAccount_8(ref object o)
        {
            return XD.sdk.SDKReponse.SwitchAccount;
        }

        static StackObject* CopyToStack_SwitchAccount_8(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.SwitchAccount;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_RoleData_9(ref object o)
        {
            return XD.sdk.SDKReponse.RoleData;
        }

        static StackObject* CopyToStack_RoleData_9(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKReponse.RoleData;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.sdk.SDKReponse();
            ins = (XD.sdk.SDKReponse)o;
            return ins;
        }


    }
}
#endif
