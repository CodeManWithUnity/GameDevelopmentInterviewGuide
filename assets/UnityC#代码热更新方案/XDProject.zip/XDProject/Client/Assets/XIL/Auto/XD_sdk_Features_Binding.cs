#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_Features_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.Features);

            field = type.GetField("back_to_exit", flag);
            app.RegisterCLRFieldGetter(field, get_back_to_exit_0);
            app.RegisterCLRFieldSetter(field, set_back_to_exit_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_back_to_exit_0, AssignFromStack_back_to_exit_0);
            field = type.GetField("account_type", flag);
            app.RegisterCLRFieldGetter(field, get_account_type_1);
            app.RegisterCLRFieldSetter(field, set_account_type_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_account_type_1, AssignFromStack_account_type_1);
            field = type.GetField("purchase_type", flag);
            app.RegisterCLRFieldGetter(field, get_purchase_type_2);
            app.RegisterCLRFieldSetter(field, set_purchase_type_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_purchase_type_2, AssignFromStack_purchase_type_2);
            field = type.GetField("user_name", flag);
            app.RegisterCLRFieldGetter(field, get_user_name_3);
            app.RegisterCLRFieldSetter(field, set_user_name_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_user_name_3, AssignFromStack_user_name_3);
            field = type.GetField("more_game", flag);
            app.RegisterCLRFieldGetter(field, get_more_game_4);
            app.RegisterCLRFieldSetter(field, set_more_game_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_more_game_4, AssignFromStack_more_game_4);
            field = type.GetField("exit_enable", flag);
            app.RegisterCLRFieldGetter(field, get_exit_enable_5);
            app.RegisterCLRFieldSetter(field, set_exit_enable_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_exit_enable_5, AssignFromStack_exit_enable_5);
            field = type.GetField("quit_enable", flag);
            app.RegisterCLRFieldGetter(field, get_quit_enable_6);
            app.RegisterCLRFieldSetter(field, set_quit_enable_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_quit_enable_6, AssignFromStack_quit_enable_6);
            field = type.GetField("back_to_logout", flag);
            app.RegisterCLRFieldGetter(field, get_back_to_logout_7);
            app.RegisterCLRFieldSetter(field, set_back_to_logout_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_back_to_logout_7, AssignFromStack_back_to_logout_7);
            field = type.GetField("pay_lock", flag);
            app.RegisterCLRFieldGetter(field, get_pay_lock_8);
            app.RegisterCLRFieldSetter(field, set_pay_lock_8);
            app.RegisterCLRFieldBinding(field, CopyToStack_pay_lock_8, AssignFromStack_pay_lock_8);
            field = type.GetField("user_center", flag);
            app.RegisterCLRFieldGetter(field, get_user_center_9);
            app.RegisterCLRFieldSetter(field, set_user_center_9);
            app.RegisterCLRFieldBinding(field, CopyToStack_user_center_9, AssignFromStack_user_center_9);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.sdk.Features());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.Features[s]);

            args = new Type[]{};
            method = type.GetConstructor(flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Ctor_0);

        }



        static object get_back_to_exit_0(ref object o)
        {
            return ((XD.sdk.Features)o).back_to_exit;
        }

        static StackObject* CopyToStack_back_to_exit_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).back_to_exit;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_back_to_exit_0(ref object o, object v)
        {
            ((XD.sdk.Features)o).back_to_exit = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_back_to_exit_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @back_to_exit = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).back_to_exit = @back_to_exit;
            return ptr_of_this_method;
        }

        static object get_account_type_1(ref object o)
        {
            return ((XD.sdk.Features)o).account_type;
        }

        static StackObject* CopyToStack_account_type_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).account_type;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_account_type_1(ref object o, object v)
        {
            ((XD.sdk.Features)o).account_type = (XD.sdk.SDKLoginType)v;
        }

        static StackObject* AssignFromStack_account_type_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            XD.sdk.SDKLoginType @account_type = (XD.sdk.SDKLoginType)typeof(XD.sdk.SDKLoginType).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.sdk.Features)o).account_type = @account_type;
            return ptr_of_this_method;
        }

        static object get_purchase_type_2(ref object o)
        {
            return ((XD.sdk.Features)o).purchase_type;
        }

        static StackObject* CopyToStack_purchase_type_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).purchase_type;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_purchase_type_2(ref object o, object v)
        {
            ((XD.sdk.Features)o).purchase_type = (XD.sdk.SDKPurchaseType)v;
        }

        static StackObject* AssignFromStack_purchase_type_2(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            XD.sdk.SDKPurchaseType @purchase_type = (XD.sdk.SDKPurchaseType)typeof(XD.sdk.SDKPurchaseType).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.sdk.Features)o).purchase_type = @purchase_type;
            return ptr_of_this_method;
        }

        static object get_user_name_3(ref object o)
        {
            return ((XD.sdk.Features)o).user_name;
        }

        static StackObject* CopyToStack_user_name_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).user_name;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_user_name_3(ref object o, object v)
        {
            ((XD.sdk.Features)o).user_name = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_user_name_3(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @user_name = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).user_name = @user_name;
            return ptr_of_this_method;
        }

        static object get_more_game_4(ref object o)
        {
            return ((XD.sdk.Features)o).more_game;
        }

        static StackObject* CopyToStack_more_game_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).more_game;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_more_game_4(ref object o, object v)
        {
            ((XD.sdk.Features)o).more_game = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_more_game_4(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @more_game = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).more_game = @more_game;
            return ptr_of_this_method;
        }

        static object get_exit_enable_5(ref object o)
        {
            return ((XD.sdk.Features)o).exit_enable;
        }

        static StackObject* CopyToStack_exit_enable_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).exit_enable;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_exit_enable_5(ref object o, object v)
        {
            ((XD.sdk.Features)o).exit_enable = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_exit_enable_5(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @exit_enable = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).exit_enable = @exit_enable;
            return ptr_of_this_method;
        }

        static object get_quit_enable_6(ref object o)
        {
            return ((XD.sdk.Features)o).quit_enable;
        }

        static StackObject* CopyToStack_quit_enable_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).quit_enable;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_quit_enable_6(ref object o, object v)
        {
            ((XD.sdk.Features)o).quit_enable = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_quit_enable_6(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @quit_enable = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).quit_enable = @quit_enable;
            return ptr_of_this_method;
        }

        static object get_back_to_logout_7(ref object o)
        {
            return ((XD.sdk.Features)o).back_to_logout;
        }

        static StackObject* CopyToStack_back_to_logout_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).back_to_logout;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_back_to_logout_7(ref object o, object v)
        {
            ((XD.sdk.Features)o).back_to_logout = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_back_to_logout_7(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @back_to_logout = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).back_to_logout = @back_to_logout;
            return ptr_of_this_method;
        }

        static object get_pay_lock_8(ref object o)
        {
            return ((XD.sdk.Features)o).pay_lock;
        }

        static StackObject* CopyToStack_pay_lock_8(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).pay_lock;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_pay_lock_8(ref object o, object v)
        {
            ((XD.sdk.Features)o).pay_lock = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_pay_lock_8(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @pay_lock = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).pay_lock = @pay_lock;
            return ptr_of_this_method;
        }

        static object get_user_center_9(ref object o)
        {
            return ((XD.sdk.Features)o).user_center;
        }

        static StackObject* CopyToStack_user_center_9(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.Features)o).user_center;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_user_center_9(ref object o, object v)
        {
            ((XD.sdk.Features)o).user_center = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_user_center_9(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @user_center = ptr_of_this_method->Value == 1;
            ((XD.sdk.Features)o).user_center = @user_center;
            return ptr_of_this_method;
        }



        static StackObject* Ctor_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);

            var result_of_this_method = new XD.sdk.Features();

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


    }
}
#endif
