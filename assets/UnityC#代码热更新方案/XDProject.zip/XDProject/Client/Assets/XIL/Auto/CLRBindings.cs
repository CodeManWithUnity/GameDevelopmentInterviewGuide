#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ILRuntime.Runtime.Generated
{
    class CLRBindings
    {
        /// <summary>
        /// Initialize the CLR binding, please invoke this AFTER CLR Redirection registration
        /// </summary>
        public static void Initialize(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            System_Int32_Binding.Register(app);
            System_Single_Binding.Register(app);
            System_Int64_Binding.Register(app);
            System_Object_Binding.Register(app);
            System_String_Binding.Register(app);
            System_UInt32_Binding.Register(app);
            System_UInt64_Binding.Register(app);
            UnityEngine_Vector2_Binding.Register(app);
            UnityEngine_Vector3_Binding.Register(app);
            System_Reflection_MethodInfo_Binding.Register(app);
            System_Reflection_FieldInfo_Binding.Register(app);
            System_Reflection_PropertyInfo_Binding.Register(app);
            System_Collections_Generic_List_1_ILTypeInstance_Binding.Register(app);
            ILRuntime_Runtime_Intepreter_ILTypeInstance_Binding.Register(app);
            System_Array_Binding.Register(app);
            System_Type_Binding.Register(app);
            System_Math_Binding.Register(app);
            System_Convert_Binding.Register(app);
            System_DateTime_Binding.Register(app);
            System_TimeSpan_Binding.Register(app);
            System_Enum_Binding.Register(app);
            System_Collections_IEnumerator_Binding.Register(app);
            System_Collections_IEnumerable_Binding.Register(app);
            System_Text_StringBuilder_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_ILTypeInstance_ILTypeInstance_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_Int32_ILTypeInstance_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_UInt32_ILTypeInstance_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_Int64_ILTypeInstance_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_UInt64_ILTypeInstance_Binding.Register(app);
            System_Collections_Generic_Dictionary_2_String_ILTypeInstance_Binding.Register(app);
            UnityEngine_Color_Binding.Register(app);
            LogQueue_Binding.Register(app);
            ResourceCache_Binding.Register(app);
            XD_MiniJSON_Json2_Binding.Register(app);
            XD_MiniJSON_Json_Binding.Register(app);
            XD_Xml_XmlExtend_Binding.Register(app);
            XD_Xml_RxmlField_Binding.Register(app);
            XD_Xml_RxmlArray_Binding.Register(app);
            XD_Xml_RxmlNode_Binding.Register(app);
            XD_Serialize_SerializeBinary_Binding.Register(app);
            XD_Mono_LifecycleManager_Binding.Register(app);
            XD_Mono_AnimEventCallback_Binding.Register(app);
            XD_Mono_CoroutineManager_Binding.Register(app);
            XD_Mono_DictionaryObject_Binding.Register(app);
            XD_Mono_MountSource_Binding.Register(app);
            XD_Mono_MountTarget_Binding.Register(app);
            XD_Mono_UpdateManager_Binding.Register(app);
            XD_Mono_PrefabAttach_Binding.Register(app);
            XD_Mono_ObjectBinder_Binding.Register(app);
            XD_Mono_TimeDisappear_Binding.Register(app);
            XD_Hook_XDHookRoute_Binding.Register(app);
            XD_Hook_XDHookStep_Binding.Register(app);
            XD_Hook_XDHookInterface_Binding.Register(app);
            XD_Hook_XDHookManager_Binding.Register(app);
            XD_Hook_XDPluginHookN_Binding.Register(app);
            XD_Hook_XDPluginHookRoot_Binding.Register(app);
            XD_tool_ObjectResource_Binding.Register(app);
            XD_tool_DataAssembly_Binding.Register(app);
            XD_tool_JsonAssembly_Binding.Register(app);
            XD_tool_DataManager_Binding.Register(app);
            XD_tool_DictionaryDiff_Binding.Register(app);
            XD_tool_ReflectionTool_Binding.Register(app);
            XD_tool_TypeCollection_Binding.Register(app);
            XD_tool_XDDelegateProxySingle2_Binding.Register(app);
            XD_tool_XDDelegateProxySingle_Binding.Register(app);
            XD_tool_XDDelegateProxy_Binding.Register(app);
            XD_tool_BinaryVarify_Binding.Register(app);
            XD_tool_FileEX_Binding.Register(app);
            XD_tool_GlobalFunc_Binding.Register(app);
            XD_tool_PrintTool_Binding.Register(app);
            XD_tool_URLRequestVarify_Binding.Register(app);
            XD_tool_XDCryptor_Binding.Register(app);
            XD_tool_SerializeDictionary_Binding.Register(app);
            XD_tool_Settings_Binding.Register(app);
            XD_tool_StrategySingle_Binding.Register(app);
            XD_tool_SerializeStrategy_Binding.Register(app);
            XD_tool_DeserializeStrategy_Binding.Register(app);
            XD_tool_SerializeString_Binding.Register(app);
            XD_tool_StrategyMethod_Binding.Register(app);
            XD_tool_CollectionTool_Binding.Register(app);
            XD_tool_Debug_Binding.Register(app);
            XD_tool_Config_Binding.Register(app);
            XD_tool_ConfigPresident_Binding.Register(app);
            XD_tool_DefinesManager_Binding.Register(app);
            XD_tool_TaskFunction_Binding.Register(app);
            XD_tool_TaskTrigger_Binding.Register(app);
            XD_tool_ServerRedirect_Binding.Register(app);
            XD_tool_URLVersion_Binding.Register(app);
            XD_tool_FastCryptUtil_Binding.Register(app);
            XD_tool_IteratorTool_Binding.Register(app);
            XD_tool_PathUnity_Binding.Register(app);
            XD_tool_StopWatch_Binding.Register(app);
            XD_tool_Math_Binding.Register(app);
            XD_tool_RXMLServerSetting_Binding.Register(app);
            XD_tool_RXMLServer_Binding.Register(app);
            XD_tool_RXMLServerList_Binding.Register(app);
            XD_tool_ServerRedirectLegacy_Binding.Register(app);
            XD_tool_ThreadDelegate_Binding.Register(app);
            XD_tool_PersistentFileAccess_Binding.Register(app);
            XD_tool_ITweenFunction_Binding.Register(app);
            XD_tool_SoundManager_Binding.Register(app);
            XD_tool_DownloadRequest_Binding.Register(app);
            XD_tool_UrlRequest_Binding.Register(app);
            ResourceCache_Binding_OnRequestOver_Binding.Register(app);
            XD_Mono_LifecycleManager_Binding_Status_Binding.Register(app);
            XD_Hook_XDHookManager_Binding_Format_Binding.Register(app);
            XD_tool_ObjectResource_Binding_Request_Binding.Register(app);
            XD_tool_DataManager_Binding_DataSet_Binding.Register(app);
            XD_tool_ReflectionTool_Binding_Member_Binding.Register(app);
            XD_tool_URLRequestVarify_Binding_FileData_Binding.Register(app);
            XD_tool_URLRequestVarify_Binding_Status_Binding.Register(app);
            XD_tool_SerializeDictionary_Binding_Attibute_Binding.Register(app);
            XD_tool_StrategySingle_Binding_Filter_Binding.Register(app);
            XD_tool_SerializeString_Binding_Attibute_Binding.Register(app);
            XD_tool_ServerRedirect_Binding_Status_Binding.Register(app);
            XD_tool_ITweenFunction_Binding_EaseType_Binding.Register(app);
            XD_tool_SoundManager_Binding_SoundPlaying_Binding.Register(app);
            XD_tool_DownloadRequest_Binding_FileDownloadHandler_Binding.Register(app);
            XD_Hook_XDHookComponentValue_Binding_RxmlComponentValue_Binding_ValueType_Binding.Register(app);
            XD_Hook_XDHookEventAssembky_Binding_RxmlEvent_Binding_ValueType_Binding.Register(app);
            XD_Hook_XDHookTextLocalization_Binding_RxmlHookLocalization_Binding_Type_Binding.Register(app);
            XD_Hook_XDHookImage_Binding_RxmlHookImage_Binding_PathType_Binding.Register(app);
            XD_Unity_CommonUnityHandle_Binding.Register(app);
            XD_Unity_UnityHandle_Binding.Register(app);
            XD_Unity_UnityInteraction_Binding.Register(app);
            XD_Unity_UnityHandle_Binding_Task_Binding.Register(app);
            XD_sdk_SDKLoginType_Binding.Register(app);
            XD_sdk_SDKPurchaseType_Binding.Register(app);
            XD_sdk_SDKRequest_Binding.Register(app);
            XD_sdk_SDKReponse_Binding.Register(app);
            XD_sdk_SDKEventResult_Binding.Register(app);
            XD_sdk_Event_ID_Value_Binding.Register(app);
            XD_sdk_SDKResult_Binding.Register(app);
            XD_sdk_SDKProcess_Binding.Register(app);
            XD_sdk_Features_Binding.Register(app);
            XD_sdk_SDKProcess_Binding_Status_Binding.Register(app);
        }

        /// <summary>
        /// Release the CLR binding, please invoke this BEFORE ILRuntime Appdomain destroy
        /// </summary>
        public static void Shutdown(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
        }
    }
}
#endif
