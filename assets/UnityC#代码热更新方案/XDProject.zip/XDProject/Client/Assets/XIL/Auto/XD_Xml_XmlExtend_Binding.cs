#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_Xml_XmlExtend_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            Type[] args;
            Type type = typeof(XD.Xml.XmlExtend);
            args = new Type[]{typeof(System.Xml.XmlNode)};
            method = type.GetMethod("ToDictionary", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, ToDictionary_0);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.String)};
            method = type.GetMethod("GetAttribute", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetAttribute_1);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.String)};
            method = type.GetMethod("GetAttributeValue", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetAttributeValue_2);
            args = new Type[]{typeof(System.Xml.XmlNode)};
            method = type.GetMethod("GetAllAttributes", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetAllAttributes_3);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.String), typeof(System.Object)};
            method = type.GetMethod("AddAttribite", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, AddAttribite_4);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.String)};
            method = type.GetMethod("RemoveAttribite", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemoveAttribite_5);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Xml.XmlNode)};
            method = type.GetMethod("AddChild", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, AddChild_6);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.String)};
            method = type.GetMethod("AddChild", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, AddChild_7);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Xml.XmlNode)};
            method = type.GetMethod("RemoveChild", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemoveChild_8);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Predicate<System.Xml.XmlNode>)};
            method = type.GetMethod("GetChild", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetChild_9);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Predicate<System.Xml.XmlNode>)};
            method = type.GetMethod("GetChildsList", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetChildsList_10);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Predicate<System.Xml.XmlNode>)};
            method = type.GetMethod("GetChilds", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetChilds_11);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Action<System.Xml.XmlNode>), typeof(System.Predicate<System.Xml.XmlNode>)};
            method = type.GetMethod("ForeachChildsAsc", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, ForeachChildsAsc_12);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Action<System.Xml.XmlAttribute>), typeof(System.Predicate<System.Xml.XmlAttribute>)};
            method = type.GetMethod("ForeachAttrsAsc", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, ForeachAttrsAsc_13);
            args = new Type[]{typeof(System.Xml.XmlNode), typeof(System.Action<System.Xml.XmlNode>), typeof(System.Predicate<System.Xml.XmlNode>)};
            method = type.GetMethod("ForeachChildsDesc", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, ForeachChildsDesc_14);
            args = new Type[]{typeof(System.String)};
            method = type.GetMethod("NewDocument", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, NewDocument_15);





        }


        static StackObject* ToDictionary_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.ToDictionary(@node);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetAttribute_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetAttribute(@node, @name);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetAttributeValue_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetAttributeValue(@node, @name);

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetAllAttributes_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetAllAttributes(@node);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* AddAttribite_4(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Object @o = (System.Object)typeof(System.Object).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.String @name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.AddAttribite(@node, @name, @o);

            return __ret;
        }

        static StackObject* RemoveAttribite_5(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.RemoveAttribite(@node, @name);

            return __ret;
        }

        static StackObject* AddChild_6(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Xml.XmlNode @n = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.AddChild(@node, @n);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* AddChild_7(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.AddChild(@node, @name);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* RemoveChild_8(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Xml.XmlNode @child = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.RemoveChild(@node, @child);

            return __ret;
        }

        static StackObject* GetChild_9(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlNode> @match = (System.Predicate<System.Xml.XmlNode>)typeof(System.Predicate<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetChild(@node, @match);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetChildsList_10(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlNode> @match = (System.Predicate<System.Xml.XmlNode>)typeof(System.Predicate<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetChildsList(@node, @match);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetChilds_11(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlNode> @match = (System.Predicate<System.Xml.XmlNode>)typeof(System.Predicate<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.GetChilds(@node, @match);

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* ForeachChildsAsc_12(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlNode> @match = (System.Predicate<System.Xml.XmlNode>)typeof(System.Predicate<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Action<System.Xml.XmlNode> @action = (System.Action<System.Xml.XmlNode>)typeof(System.Action<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.ForeachChildsAsc(@node, @action, @match);

            return __ret;
        }

        static StackObject* ForeachAttrsAsc_13(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlAttribute> @match = (System.Predicate<System.Xml.XmlAttribute>)typeof(System.Predicate<System.Xml.XmlAttribute>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Action<System.Xml.XmlAttribute> @action = (System.Action<System.Xml.XmlAttribute>)typeof(System.Action<System.Xml.XmlAttribute>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.ForeachAttrsAsc(@node, @action, @match);

            return __ret;
        }

        static StackObject* ForeachChildsDesc_14(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 3);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Predicate<System.Xml.XmlNode> @match = (System.Predicate<System.Xml.XmlNode>)typeof(System.Predicate<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Action<System.Xml.XmlNode> @action = (System.Action<System.Xml.XmlNode>)typeof(System.Action<System.Xml.XmlNode>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Xml.XmlNode @node = (System.Xml.XmlNode)typeof(System.Xml.XmlNode).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Xml.XmlExtend.ForeachChildsDesc(@node, @action, @match);

            return __ret;
        }

        static StackObject* NewDocument_15(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @root = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Xml.XmlExtend.NewDocument(@root);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }





    }
}
#endif
