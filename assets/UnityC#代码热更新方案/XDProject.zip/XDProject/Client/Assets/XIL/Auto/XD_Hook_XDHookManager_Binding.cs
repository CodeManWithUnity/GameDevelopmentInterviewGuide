#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_Hook_XDHookManager_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.Hook.XDHookManager);
            args = new Type[]{};
            method = type.GetMethod("Clear", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Clear_0);
            args = new Type[]{typeof(System.Byte[]), typeof(XD.Hook.XDHookManager.Format)};
            method = type.GetMethod("LoadSettings", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, LoadSettings_1);
            args = new Type[]{typeof(System.String)};
            method = type.GetMethod("GetCondition", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetCondition_2);
            args = new Type[]{typeof(System.String), typeof(System.Boolean)};
            method = type.GetMethod("SetCondition", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SetCondition_3);
            args = new Type[]{typeof(System.Type)};
            method = type.GetMethod("GetHookInterface", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetHookInterface_4);
            args = new Type[]{typeof(System.String)};
            method = type.GetMethod("GetHookInterface", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetHookInterface_5);
            args = new Type[]{};
            method = type.GetMethod("GetAllHookInterface", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetAllHookInterface_6);

            field = type.GetField("Process_Sub_Path", flag);
            app.RegisterCLRFieldGetter(field, get_Process_Sub_Path_0);
            app.RegisterCLRFieldSetter(field, set_Process_Sub_Path_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Process_Sub_Path_0, AssignFromStack_Process_Sub_Path_0);
            field = type.GetField("Tag", flag);
            app.RegisterCLRFieldGetter(field, get_Tag_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Tag_1, null);




        }


        static StackObject* Clear_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            XD.Hook.XDHookManager.Clear();

            return __ret;
        }

        static StackObject* LoadSettings_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            XD.Hook.XDHookManager.Format @format = (XD.Hook.XDHookManager.Format)typeof(XD.Hook.XDHookManager.Format).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Byte[] @data = (System.Byte[])typeof(System.Byte[]).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Hook.XDHookManager.LoadSettings(@data, @format);

            return __ret;
        }

        static StackObject* GetCondition_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @key = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Hook.XDHookManager.GetCondition(@key);

            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static StackObject* SetCondition_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Boolean @b = ptr_of_this_method->Value == 1;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.String @key = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.Hook.XDHookManager.SetCondition(@key, @b);

            return __ret;
        }

        static StackObject* GetHookInterface_4(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Type @type = (System.Type)typeof(System.Type).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Hook.XDHookManager.GetHookInterface(@type);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetHookInterface_5(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.String @type_info = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.Hook.XDHookManager.GetHookInterface(@type_info);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetAllHookInterface_6(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.Hook.XDHookManager.GetAllHookInterface();

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object get_Process_Sub_Path_0(ref object o)
        {
            return XD.Hook.XDHookManager.Process_Sub_Path;
        }

        static StackObject* CopyToStack_Process_Sub_Path_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookManager.Process_Sub_Path;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_Process_Sub_Path_0(ref object o, object v)
        {
            XD.Hook.XDHookManager.Process_Sub_Path = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_Process_Sub_Path_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @Process_Sub_Path = ptr_of_this_method->Value == 1;
            XD.Hook.XDHookManager.Process_Sub_Path = @Process_Sub_Path;
            return ptr_of_this_method;
        }

        static object get_Tag_1(ref object o)
        {
            return XD.Hook.XDHookManager.Tag;
        }

        static StackObject* CopyToStack_Tag_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookManager.Tag;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }




    }
}
#endif
