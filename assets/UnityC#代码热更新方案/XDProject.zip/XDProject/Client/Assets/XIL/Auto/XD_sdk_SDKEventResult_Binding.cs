#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_SDKEventResult_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.SDKEventResult);

            field = type.GetField("Success", flag);
            app.RegisterCLRFieldGetter(field, get_Success_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Success_0, null);
            field = type.GetField("Fail", flag);
            app.RegisterCLRFieldGetter(field, get_Fail_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Fail_1, null);
            field = type.GetField("Error", flag);
            app.RegisterCLRFieldGetter(field, get_Error_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_2, null);
            field = type.GetField("Cancel", flag);
            app.RegisterCLRFieldGetter(field, get_Cancel_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_Cancel_3, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.sdk.SDKEventResult());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.SDKEventResult[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.sdk.SDKEventResult instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.sdk.SDKEventResult[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_Success_0(ref object o)
        {
            return XD.sdk.SDKEventResult.Success;
        }

        static StackObject* CopyToStack_Success_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKEventResult.Success;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Fail_1(ref object o)
        {
            return XD.sdk.SDKEventResult.Fail;
        }

        static StackObject* CopyToStack_Fail_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKEventResult.Fail;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_2(ref object o)
        {
            return XD.sdk.SDKEventResult.Error;
        }

        static StackObject* CopyToStack_Error_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKEventResult.Error;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Cancel_3(ref object o)
        {
            return XD.sdk.SDKEventResult.Cancel;
        }

        static StackObject* CopyToStack_Cancel_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKEventResult.Cancel;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.sdk.SDKEventResult();
            ins = (XD.sdk.SDKEventResult)o;
            return ins;
        }


    }
}
#endif
