#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_SDKProcess_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            MethodBase method;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.SDKProcess);
            args = new Type[]{typeof(XD.sdk.SDKReponse), typeof(System.Action<XD.sdk.SDKResult>)};
            method = type.GetMethod("RegistListener", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RegistListener_0);
            args = new Type[]{typeof(XD.sdk.SDKReponse), typeof(System.Action<XD.sdk.SDKResult>)};
            method = type.GetMethod("RemovetListener", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemovetListener_1);
            args = new Type[]{};
            method = type.GetMethod("RemovetAllListener", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, RemovetAllListener_2);
            args = new Type[]{typeof(System.String), typeof(System.Action<XD.sdk.SDKResult>)};
            method = type.GetMethod("CreateSDK", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, CreateSDK_3);
            args = new Type[]{};
            method = type.GetMethod("GetVersion", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetVersion_4);
            args = new Type[]{};
            method = type.GetMethod("GetSDKFeature", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetSDKFeature_5);
            args = new Type[]{};
            method = type.GetMethod("GetStatus", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetStatus_6);
            args = new Type[]{typeof(System.String), typeof(System.String), typeof(System.String), typeof(System.String), typeof(System.Int32), typeof(System.Int32), typeof(System.String), typeof(System.Action<XD.sdk.SDKResult, System.String>)};
            method = type.GetMethod("CreateProduct", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, CreateProduct_7);
            args = new Type[]{typeof(System.String), typeof(System.String), typeof(System.String), typeof(System.Action<XD.sdk.SDKResult, System.String>)};
            method = type.GetMethod("Purchase", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Purchase_8);
            args = new Type[]{typeof(System.Int32)};
            method = type.GetMethod("ShowMoreGame", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, ShowMoreGame_9);
            args = new Type[]{typeof(System.Int32)};
            method = type.GetMethod("Exit", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Exit_10);
            args = new Type[]{typeof(System.Int32)};
            method = type.GetMethod("Quit", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Quit_11);
            args = new Type[]{typeof(System.Int32)};
            method = type.GetMethod("SetSDK", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SetSDK_12);
            args = new Type[]{typeof(System.Action<XD.sdk.SDKResult, System.String>)};
            method = type.GetMethod("Login", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Login_13);
            args = new Type[]{typeof(System.Int32), typeof(System.Action<XD.sdk.SDKResult, System.String>)};
            method = type.GetMethod("SwitchAccount", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SwitchAccount_14);
            args = new Type[]{};
            method = type.GetMethod("Logout", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Logout_15);
            args = new Type[]{typeof(System.Collections.IDictionary)};
            method = type.GetMethod("Event", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Event_16);
            args = new Type[]{typeof(System.Collections.IDictionary)};
            method = type.GetMethod("UserCenter", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, UserCenter_17);
            args = new Type[]{typeof(System.Collections.IDictionary)};
            method = type.GetMethod("BindAccount", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, BindAccount_18);
            args = new Type[]{typeof(XD.sdk.SDKRequest), typeof(System.Collections.IDictionary)};
            method = type.GetMethod("Request", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, Request_19);
            args = new Type[]{};
            method = type.GetMethod("IsLockOnPay", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, IsLockOnPay_20);
            args = new Type[]{typeof(System.Collections.IDictionary), typeof(System.Int32)};
            method = type.GetMethod("SetUserData", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SetUserData_21);
            args = new Type[]{typeof(System.Collections.IDictionary)};
            method = type.GetMethod("SetUserData", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, SetUserData_22);
            args = new Type[]{typeof(System.Collections.IDictionary)};
            method = type.GetMethod("GetUserData", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetUserData_23);
            args = new Type[]{};
            method = type.GetMethod("GetAllData", flag, null, args, null);
            app.RegisterCLRMethodRedirection(method, GetAllData_24);

            field = type.GetField("tag_sdk", flag);
            app.RegisterCLRFieldGetter(field, get_tag_sdk_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_tag_sdk_0, null);
            field = type.GetField("USE_NEW", flag);
            app.RegisterCLRFieldGetter(field, get_USE_NEW_1);
            app.RegisterCLRFieldSetter(field, set_USE_NEW_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_USE_NEW_1, AssignFromStack_USE_NEW_1);




        }


        static StackObject* RegistListener_0(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult> @fun = (System.Action<XD.sdk.SDKResult>)typeof(System.Action<XD.sdk.SDKResult>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            XD.sdk.SDKReponse @evt = (XD.sdk.SDKReponse)typeof(XD.sdk.SDKReponse).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.RegistListener(@evt, @fun);

            return __ret;
        }

        static StackObject* RemovetListener_1(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult> @fun = (System.Action<XD.sdk.SDKResult>)typeof(System.Action<XD.sdk.SDKResult>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            XD.sdk.SDKReponse @evt = (XD.sdk.SDKReponse)typeof(XD.sdk.SDKReponse).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.RemovetListener(@evt, @fun);

            return __ret;
        }

        static StackObject* RemovetAllListener_2(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            XD.sdk.SDKProcess.RemovetAllListener();

            return __ret;
        }

        static StackObject* CreateSDK_3(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult> @complete = (System.Action<XD.sdk.SDKResult>)typeof(System.Action<XD.sdk.SDKResult>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.String @json = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.sdk.SDKProcess.CreateSDK(@json, @complete);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetVersion_4(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.sdk.SDKProcess.GetVersion();

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetSDKFeature_5(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.sdk.SDKProcess.GetSDKFeature();

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetStatus_6(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.sdk.SDKProcess.GetStatus();

            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* CreateProduct_7(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 8);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult, System.String> @complete = (System.Action<XD.sdk.SDKResult, System.String>)typeof(System.Action<XD.sdk.SDKResult, System.String>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.String @currency = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.Int32 @count = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 4);
            System.Int32 @price = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 5);
            System.String @product_desc = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 6);
            System.String @product_name = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 7);
            System.String @product_id = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 8);
            System.String @Purachse_Item_ID = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.sdk.SDKProcess.CreateProduct(@Purachse_Item_ID, @product_id, @product_name, @product_desc, @price, @count, @currency, @complete);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* Purchase_8(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 4);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult, System.String> @complete = (System.Action<XD.sdk.SDKResult, System.String>)typeof(System.Action<XD.sdk.SDKResult, System.String>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.String @purchase_info = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 3);
            System.String @purchase_url = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 4);
            System.String @purchase_id = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.sdk.SDKProcess.Purchase(@purchase_id, @purchase_url, @purchase_info, @complete);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* ShowMoreGame_9(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @platform = ptr_of_this_method->Value;


            XD.sdk.SDKProcess.ShowMoreGame(@platform);

            return __ret;
        }

        static StackObject* Exit_10(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @platform = ptr_of_this_method->Value;


            var result_of_this_method = XD.sdk.SDKProcess.Exit(@platform);

            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static StackObject* Quit_11(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @platform = ptr_of_this_method->Value;


            XD.sdk.SDKProcess.Quit(@platform);

            return __ret;
        }

        static StackObject* SetSDK_12(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @index = ptr_of_this_method->Value;


            XD.sdk.SDKProcess.SetSDK(@index);

            return __ret;
        }

        static StackObject* Login_13(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult, System.String> @complete = (System.Action<XD.sdk.SDKResult, System.String>)typeof(System.Action<XD.sdk.SDKResult, System.String>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.sdk.SDKProcess.Login(@complete);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* SwitchAccount_14(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Action<XD.sdk.SDKResult, System.String> @complete = (System.Action<XD.sdk.SDKResult, System.String>)typeof(System.Action<XD.sdk.SDKResult, System.String>).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Int32 @platform = ptr_of_this_method->Value;


            var result_of_this_method = XD.sdk.SDKProcess.SwitchAccount(@platform, @complete);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* Logout_15(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            XD.sdk.SDKProcess.Logout();

            return __ret;
        }

        static StackObject* Event_16(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.Event(@ji);

            return __ret;
        }

        static StackObject* UserCenter_17(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.UserCenter(@ji);

            return __ret;
        }

        static StackObject* BindAccount_18(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.BindAccount(@ji);

            return __ret;
        }

        static StackObject* Request_19(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            XD.sdk.SDKRequest @request = (XD.sdk.SDKRequest)typeof(XD.sdk.SDKRequest).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.Request(@request, @ji);

            return __ret;
        }

        static StackObject* IsLockOnPay_20(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.sdk.SDKProcess.IsLockOnPay();

            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static StackObject* SetUserData_21(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 2);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Int32 @platform = ptr_of_this_method->Value;

            ptr_of_this_method = ILIntepreter.Minus(__esp, 2);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.SetUserData(@ji, @platform);

            return __ret;
        }

        static StackObject* SetUserData_22(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            XD.sdk.SDKProcess.SetUserData(@ji);

            return __ret;
        }

        static StackObject* GetUserData_23(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* ptr_of_this_method;
            StackObject* __ret = ILIntepreter.Minus(__esp, 1);

            ptr_of_this_method = ILIntepreter.Minus(__esp, 1);
            System.Collections.IDictionary @ji = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            __intp.Free(ptr_of_this_method);


            var result_of_this_method = XD.sdk.SDKProcess.GetUserData(@ji);

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static StackObject* GetAllData_24(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            StackObject* __ret = ILIntepreter.Minus(__esp, 0);


            var result_of_this_method = XD.sdk.SDKProcess.GetAllData();

            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object get_tag_sdk_0(ref object o)
        {
            return XD.sdk.SDKProcess.tag_sdk;
        }

        static StackObject* CopyToStack_tag_sdk_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKProcess.tag_sdk;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_USE_NEW_1(ref object o)
        {
            return XD.sdk.SDKProcess.USE_NEW;
        }

        static StackObject* CopyToStack_USE_NEW_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.sdk.SDKProcess.USE_NEW;
            __ret->ObjectType = ObjectTypes.Integer;
            __ret->Value = result_of_this_method ? 1 : 0;
            return __ret + 1;
        }

        static void set_USE_NEW_1(ref object o, object v)
        {
            XD.sdk.SDKProcess.USE_NEW = (System.Boolean)v;
        }

        static StackObject* AssignFromStack_USE_NEW_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Boolean @USE_NEW = ptr_of_this_method->Value == 1;
            XD.sdk.SDKProcess.USE_NEW = @USE_NEW;
            return ptr_of_this_method;
        }




    }
}
#endif
