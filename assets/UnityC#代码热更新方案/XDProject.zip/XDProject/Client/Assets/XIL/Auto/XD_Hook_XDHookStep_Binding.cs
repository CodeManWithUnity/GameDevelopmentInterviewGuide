#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_Hook_XDHookStep_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.Hook.XDHookStep);

            field = type.GetField("None", flag);
            app.RegisterCLRFieldGetter(field, get_None_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_None_0, null);
            field = type.GetField("Attach", flag);
            app.RegisterCLRFieldGetter(field, get_Attach_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Attach_1, null);
            field = type.GetField("Awake", flag);
            app.RegisterCLRFieldGetter(field, get_Awake_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Awake_2, null);
            field = type.GetField("Start", flag);
            app.RegisterCLRFieldGetter(field, get_Start_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_Start_3, null);
            field = type.GetField("Enable", flag);
            app.RegisterCLRFieldGetter(field, get_Enable_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_Enable_4, null);
            field = type.GetField("Disable", flag);
            app.RegisterCLRFieldGetter(field, get_Disable_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_Disable_5, null);
            field = type.GetField("Destory", flag);
            app.RegisterCLRFieldGetter(field, get_Destory_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_Destory_6, null);
            field = type.GetField("All", flag);
            app.RegisterCLRFieldGetter(field, get_All_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_All_7, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.Hook.XDHookStep());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.Hook.XDHookStep[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.Hook.XDHookStep instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.Hook.XDHookStep[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_None_0(ref object o)
        {
            return XD.Hook.XDHookStep.None;
        }

        static StackObject* CopyToStack_None_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.None;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Attach_1(ref object o)
        {
            return XD.Hook.XDHookStep.Attach;
        }

        static StackObject* CopyToStack_Attach_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Attach;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Awake_2(ref object o)
        {
            return XD.Hook.XDHookStep.Awake;
        }

        static StackObject* CopyToStack_Awake_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Awake;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Start_3(ref object o)
        {
            return XD.Hook.XDHookStep.Start;
        }

        static StackObject* CopyToStack_Start_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Start;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Enable_4(ref object o)
        {
            return XD.Hook.XDHookStep.Enable;
        }

        static StackObject* CopyToStack_Enable_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Enable;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Disable_5(ref object o)
        {
            return XD.Hook.XDHookStep.Disable;
        }

        static StackObject* CopyToStack_Disable_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Disable;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Destory_6(ref object o)
        {
            return XD.Hook.XDHookStep.Destory;
        }

        static StackObject* CopyToStack_Destory_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.Destory;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_All_7(ref object o)
        {
            return XD.Hook.XDHookStep.All;
        }

        static StackObject* CopyToStack_All_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookStep.All;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.Hook.XDHookStep();
            ins = (XD.Hook.XDHookStep)o;
            return ins;
        }


    }
}
#endif
