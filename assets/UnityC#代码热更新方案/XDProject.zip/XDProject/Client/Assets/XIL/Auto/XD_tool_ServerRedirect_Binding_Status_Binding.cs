#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_ServerRedirect_Binding_Status_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.ServerRedirect.Status);

            field = type.GetField("Sucess", flag);
            app.RegisterCLRFieldGetter(field, get_Sucess_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Sucess_0, null);
            field = type.GetField("Error_Server_List", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Server_List_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Server_List_1, null);
            field = type.GetField("Error_Server_List_Ini", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Server_List_Ini_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Server_List_Ini_2, null);
            field = type.GetField("Error_Server_List_Null", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Server_List_Null_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Server_List_Null_3, null);
            field = type.GetField("Error_Setting", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Setting_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Setting_4, null);
            field = type.GetField("Error_Server_Ini", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Server_Ini_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Server_Ini_5, null);
            field = type.GetField("Error_Setting_Custorm", flag);
            app.RegisterCLRFieldGetter(field, get_Error_Setting_Custorm_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_Error_Setting_Custorm_6, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.tool.ServerRedirect.Status());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.tool.ServerRedirect.Status[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.tool.ServerRedirect.Status instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.tool.ServerRedirect.Status[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_Sucess_0(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Sucess;
        }

        static StackObject* CopyToStack_Sucess_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Sucess;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Server_List_1(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Server_List;
        }

        static StackObject* CopyToStack_Error_Server_List_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Server_List;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Server_List_Ini_2(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Server_List_Ini;
        }

        static StackObject* CopyToStack_Error_Server_List_Ini_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Server_List_Ini;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Server_List_Null_3(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Server_List_Null;
        }

        static StackObject* CopyToStack_Error_Server_List_Null_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Server_List_Null;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Setting_4(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Setting;
        }

        static StackObject* CopyToStack_Error_Setting_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Setting;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Server_Ini_5(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Server_Ini;
        }

        static StackObject* CopyToStack_Error_Server_Ini_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Server_Ini;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Error_Setting_Custorm_6(ref object o)
        {
            return XD.tool.ServerRedirect.Status.Error_Setting_Custorm;
        }

        static StackObject* CopyToStack_Error_Setting_Custorm_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ServerRedirect.Status.Error_Setting_Custorm;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.tool.ServerRedirect.Status();
            ins = (XD.tool.ServerRedirect.Status)o;
            return ins;
        }


    }
}
#endif
