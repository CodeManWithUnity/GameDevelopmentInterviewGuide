#if USE_HOT && UNITY_ANDROID
namespace IL
{
    public partial class DelegateBridge
    {
        public bool __Gen_Delegate_Imp1(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp2(object p0, object p1, object p2, XD.Hook.XDHookStep p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public XD.Hook.XDHookStep __Gen_Delegate_Imp3(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                XD.Hook.XDHookStep result = default(XD.Hook.XDHookStep);
                result = (XD.Hook.XDHookStep)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Type __Gen_Delegate_Imp4(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Type result = default(System.Type);
                result = (System.Type)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp5(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp6(object p0, object p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp7(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp8(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp9(System.Byte[] p0, object p1, UnityEngine.RuntimePlatform p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public string __Gen_Delegate_Imp10(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp11()
        {
            using (var pObjs = new EmptyObjs())
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp12(XD.Mono.LifecycleManager.Status p0)
        {
            using (var pObjs = new Objects(p0))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp13(int p0)
        {
            using (var pObjs = new Objects(p0))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp14(int p0, object p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp15(object p0, object p1, object p2, int p3, int p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp16(object p0, int p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp17(object p0, object p1, int p2, object p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp18(int p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp19(int p0, object p1, object p2, object p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp20(int p0, object p1, object p2, object p3, object p4, int p5)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp21(XD.Analytics.XDAnalytics.Event p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.Action<System.Action<System.Collections.IDictionary>> __Gen_Delegate_Imp22(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Action<System.Action<System.Collections.IDictionary>> result = default(System.Action<System.Action<System.Collections.IDictionary>>);
                result = (System.Action<System.Action<System.Collections.IDictionary>>)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Func<System.Delegate, System.Delegate> __Gen_Delegate_Imp23(object p0, object p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                System.Func<System.Delegate, System.Delegate> result = default(System.Func<System.Delegate, System.Delegate>);
                result = (System.Func<System.Delegate, System.Delegate>)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public int __Gen_Delegate_Imp24(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                int result = default(int);
                result = (int)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public int __Gen_Delegate_Imp25(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                int result = default(int);
                result = (int)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp26(object p0, int p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public object __Gen_Delegate_Imp27(object p0, object p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public ILRuntime.Runtime.Intepreter.ILTypeInstance __Gen_Delegate_Imp28(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                ILRuntime.Runtime.Intepreter.ILTypeInstance result = default(ILRuntime.Runtime.Intepreter.ILTypeInstance);
                result = (ILRuntime.Runtime.Intepreter.ILTypeInstance)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp29(object p0, bool p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public object __Gen_Delegate_Imp30(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp31(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp32(object p0, object p1, System.Object[] p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public object __Gen_Delegate_Imp33(object p0, object p1, System.Object[] p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Reflection.MethodInfo __Gen_Delegate_Imp34(object p0, object p1, System.Type[] p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                System.Reflection.MethodInfo result = default(System.Reflection.MethodInfo);
                result = (System.Reflection.MethodInfo)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp35(object p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp36(object p0, object p1, object p2, object p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp37(object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp38(object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp39(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp40(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp41(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp42(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp43(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public object __Gen_Delegate_Imp44(object p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp45(object p0, object p1, object p2, object p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp46(object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp47(object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp48(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp49(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp50(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp51(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp52(object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public bool __Gen_Delegate_Imp53()
        {
            using (var pObjs = new EmptyObjs())
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp54(object p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public object __Gen_Delegate_Imp55()
        {
            using (var pObjs = new EmptyObjs())
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp56(object p0, object p1, int p2, int p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp57(object p0, object p1, int p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UnityEngine.RuntimePlatform __Gen_Delegate_Imp58()
        {
            using (var pObjs = new EmptyObjs())
            {
                UnityEngine.RuntimePlatform result = default(UnityEngine.RuntimePlatform);
                result = (UnityEngine.RuntimePlatform)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp59(int p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp60(bool p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp61()
        {
            using (var pObjs = new EmptyObjs())
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public UnityEngine.Material[] __Gen_Delegate_Imp62(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UnityEngine.Material[] result = default(UnityEngine.Material[]);
                result = (UnityEngine.Material[])methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp63(int p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.IO.Stream __Gen_Delegate_Imp64(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.IO.Stream result = default(System.IO.Stream);
                result = (System.IO.Stream)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp65(object p0, System.Byte[] p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp66(bool p0)
        {
            using (var pObjs = new Objects(p0))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public string __Gen_Delegate_Imp67()
        {
            using (var pObjs = new EmptyObjs())
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.Generic.Dictionary<System.Int32, System.String> __Gen_Delegate_Imp68(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Collections.Generic.Dictionary<System.Int32, System.String> result = default(System.Collections.Generic.Dictionary<System.Int32, System.String>);
                result = (System.Collections.Generic.Dictionary<System.Int32, System.String>)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp69(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public XD.Localization.Runtime.LocalizationAsset __Gen_Delegate_Imp70(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                XD.Localization.Runtime.LocalizationAsset result = default(XD.Localization.Runtime.LocalizationAsset);
                result = (XD.Localization.Runtime.LocalizationAsset)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public XD.Localization.Runtime.LocalizationDownload __Gen_Delegate_Imp71()
        {
            using (var pObjs = new EmptyObjs())
            {
                XD.Localization.Runtime.LocalizationDownload result = default(XD.Localization.Runtime.LocalizationDownload);
                result = (XD.Localization.Runtime.LocalizationDownload)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public bool __Gen_Delegate_Imp72(object p0, System.Byte[] p1, int p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public float __Gen_Delegate_Imp73(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                float result = default(float);
                result = (float)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp74(object p0, object p1, System.Byte[] p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp75(object p0, bool p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public object __Gen_Delegate_Imp76(System.Object[] p0)
        {
            using (var pObjs = new Objects(p0))
            {
                object result = default(object);
                result = (object)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public bool __Gen_Delegate_Imp77(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public string __Gen_Delegate_Imp78(int p0)
        {
            using (var pObjs = new Objects(p0))
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public string __Gen_Delegate_Imp79(object p0, int p1, int p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public bool __Gen_Delegate_Imp80(char p0)
        {
            using (var pObjs = new Objects(p0))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public UnityEngine.Vector4 __Gen_Delegate_Imp81(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UnityEngine.Vector4 result = default(UnityEngine.Vector4);
                result = (UnityEngine.Vector4)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp82(object p0, UnityEngine.Vector4 p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UnityEngine.RectTransform __Gen_Delegate_Imp83(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UnityEngine.RectTransform result = default(UnityEngine.RectTransform);
                result = (UnityEngine.RectTransform)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public UnityEngine.Color __Gen_Delegate_Imp84(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UnityEngine.Color result = default(UnityEngine.Color);
                result = (UnityEngine.Color)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp85(object p0, UnityEngine.Color p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp86(object p0, object p1, bool p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public bool __Gen_Delegate_Imp87(object p0, bool p1, int p2, float p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp88(object p0, object p1, object p2, bool p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public int __Gen_Delegate_Imp89(object p0, int p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                int result = default(int);
                result = (int)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp90(object p0, object p1, bool p2, object p3, object p4, object p5, object p6, bool p7, int p8, object p9, object p10, bool p11)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp91(object p0, UnityEngine.Vector2 p1, UnityEngine.Vector2 p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp92(object p0, int p1, int p2, int p3, int p4, bool p5)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public bool __Gen_Delegate_Imp93(object p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public string __Gen_Delegate_Imp94(object p0, object p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp95(object p0, int p1, int p2, int p3, int p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp96(object p0, int p1, int p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public bool __Gen_Delegate_Imp97(object p0, int p1, int p2, int p3, int p4, float p5, float p6, object p7)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp98(object p0, object p1, bool p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public string __Gen_Delegate_Imp99(object p0, object p1, bool p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                string result = default(string);
                result = (string)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp100(object p0, float p1, float p2, float p3, float p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp101(object p0, float p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp102(object p0, bool p1, bool p2, bool p3, bool p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp103(object p0, int p1, int p2, bool p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UnityEngine.Rect __Gen_Delegate_Imp104(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UnityEngine.Rect result = default(UnityEngine.Rect);
                result = (UnityEngine.Rect)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp105(object p0, UnityEngine.Rect p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public bool __Gen_Delegate_Imp106(object p0, bool p1, UniWebViewTransitionEdge p2, float p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public bool __Gen_Delegate_Imp107(object p0, UnityEngine.Rect p1, float p2, float p3, object p4)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3, p4))
            {
                bool result = default(bool);
                result = (bool)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp108(object p0, UniWebViewContentInsetAdjustmentBehavior p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UniWebViewLogger.Level __Gen_Delegate_Imp109(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UniWebViewLogger.Level result = default(UniWebViewLogger.Level);
                result = (UniWebViewLogger.Level)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp110(object p0, UniWebViewLogger.Level p1)
        {
            using (var pObjs = new Objects(p0, p1))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UniWebViewLogger __Gen_Delegate_Imp111()
        {
            using (var pObjs = new EmptyObjs())
            {
                UniWebViewLogger result = default(UniWebViewLogger);
                result = (UniWebViewLogger)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp112(object p0, UniWebViewLogger.Level p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public UniWebViewNativeListener __Gen_Delegate_Imp113(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                UniWebViewNativeListener result = default(UniWebViewNativeListener);
                result = (UniWebViewNativeListener)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp114(object p0, bool p1, bool p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp115(object p0, object p1, int p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public void __Gen_Delegate_Imp116(object p0, object p1, WebViewMessage p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp117(System.Byte[] p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp118(System.Byte[] p0, object p1, object p2, object p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.Collections.Generic.List<XD.tool.XDZip.FileData> __Gen_Delegate_Imp119(object p0)
        {
            using (var pObjs = new Objects(p0))
            {
                System.Collections.Generic.List<XD.tool.XDZip.FileData> result = default(System.Collections.Generic.List<XD.tool.XDZip.FileData>);
                result = (System.Collections.Generic.List<XD.tool.XDZip.FileData>)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }
        public void __Gen_Delegate_Imp120(object p0, object p1, object p2, int p3)
        {
            using (var pObjs = new Objects(p0, p1, p2, p3))
            {
                methodInfo.Invoke(null, pObjs.objs);
            }
        }
        public System.Collections.IEnumerator __Gen_Delegate_Imp121(object p0, object p1, object p2)
        {
            using (var pObjs = new Objects(p0, p1, p2))
            {
                System.Collections.IEnumerator result = default(System.Collections.IEnumerator);
                result = (System.Collections.IEnumerator)methodInfo.Invoke(null, pObjs.objs);
                return result;
            }
        }

    }
}
#endif