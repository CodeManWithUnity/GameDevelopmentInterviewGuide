#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_sdk_SDKResult_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.sdk.SDKResult);

            field = type.GetField("result", flag);
            app.RegisterCLRFieldGetter(field, get_result_0);
            app.RegisterCLRFieldSetter(field, set_result_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_result_0, AssignFromStack_result_0);
            field = type.GetField("msg", flag);
            app.RegisterCLRFieldGetter(field, get_msg_1);
            app.RegisterCLRFieldSetter(field, set_msg_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_msg_1, AssignFromStack_msg_1);
            field = type.GetField("param", flag);
            app.RegisterCLRFieldGetter(field, get_param_2);
            app.RegisterCLRFieldSetter(field, set_param_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_param_2, AssignFromStack_param_2);


            app.RegisterCLRCreateArrayInstance(type, s => new XD.sdk.SDKResult[s]);


        }



        static object get_result_0(ref object o)
        {
            return ((XD.sdk.SDKResult)o).result;
        }

        static StackObject* CopyToStack_result_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.SDKResult)o).result;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_result_0(ref object o, object v)
        {
            ((XD.sdk.SDKResult)o).result = (XD.sdk.SDKEventResult)v;
        }

        static StackObject* AssignFromStack_result_0(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            XD.sdk.SDKEventResult @result = (XD.sdk.SDKEventResult)typeof(XD.sdk.SDKEventResult).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.sdk.SDKResult)o).result = @result;
            return ptr_of_this_method;
        }

        static object get_msg_1(ref object o)
        {
            return ((XD.sdk.SDKResult)o).msg;
        }

        static StackObject* CopyToStack_msg_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.SDKResult)o).msg;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_msg_1(ref object o, object v)
        {
            ((XD.sdk.SDKResult)o).msg = (System.String)v;
        }

        static StackObject* AssignFromStack_msg_1(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.String @msg = (System.String)typeof(System.String).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.sdk.SDKResult)o).msg = @msg;
            return ptr_of_this_method;
        }

        static object get_param_2(ref object o)
        {
            return ((XD.sdk.SDKResult)o).param;
        }

        static StackObject* CopyToStack_param_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = ((XD.sdk.SDKResult)o).param;
            object obj_result_of_this_method = result_of_this_method;
            if(obj_result_of_this_method is CrossBindingAdaptorType)
            {    
                return ILIntepreter.PushObject(__ret, __mStack, ((CrossBindingAdaptorType)obj_result_of_this_method).ILInstance);
            }
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static void set_param_2(ref object o, object v)
        {
            ((XD.sdk.SDKResult)o).param = (System.Collections.IDictionary)v;
        }

        static StackObject* AssignFromStack_param_2(ref object o, ILIntepreter __intp, StackObject* ptr_of_this_method, IList<object> __mStack)
        {
            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;
            System.Collections.IDictionary @param = (System.Collections.IDictionary)typeof(System.Collections.IDictionary).CheckCLRTypes(StackObject.ToObject(ptr_of_this_method, __domain, __mStack));
            ((XD.sdk.SDKResult)o).param = @param;
            return ptr_of_this_method;
        }




    }
}
#endif
