#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_tool_ITweenFunction_Binding_EaseType_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.tool.ITweenFunction.EaseType);

            field = type.GetField("easeInQuad", flag);
            app.RegisterCLRFieldGetter(field, get_easeInQuad_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInQuad_0, null);
            field = type.GetField("easeOutQuad", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutQuad_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutQuad_1, null);
            field = type.GetField("easeInOutQuad", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutQuad_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutQuad_2, null);
            field = type.GetField("easeInCubic", flag);
            app.RegisterCLRFieldGetter(field, get_easeInCubic_3);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInCubic_3, null);
            field = type.GetField("easeOutCubic", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutCubic_4);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutCubic_4, null);
            field = type.GetField("easeInOutCubic", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutCubic_5);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutCubic_5, null);
            field = type.GetField("easeInQuart", flag);
            app.RegisterCLRFieldGetter(field, get_easeInQuart_6);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInQuart_6, null);
            field = type.GetField("easeOutQuart", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutQuart_7);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutQuart_7, null);
            field = type.GetField("easeInOutQuart", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutQuart_8);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutQuart_8, null);
            field = type.GetField("easeInQuint", flag);
            app.RegisterCLRFieldGetter(field, get_easeInQuint_9);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInQuint_9, null);
            field = type.GetField("easeOutQuint", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutQuint_10);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutQuint_10, null);
            field = type.GetField("easeInOutQuint", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutQuint_11);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutQuint_11, null);
            field = type.GetField("easeInSine", flag);
            app.RegisterCLRFieldGetter(field, get_easeInSine_12);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInSine_12, null);
            field = type.GetField("easeOutSine", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutSine_13);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutSine_13, null);
            field = type.GetField("easeInOutSine", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutSine_14);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutSine_14, null);
            field = type.GetField("easeInExpo", flag);
            app.RegisterCLRFieldGetter(field, get_easeInExpo_15);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInExpo_15, null);
            field = type.GetField("easeOutExpo", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutExpo_16);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutExpo_16, null);
            field = type.GetField("easeInOutExpo", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutExpo_17);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutExpo_17, null);
            field = type.GetField("easeInCirc", flag);
            app.RegisterCLRFieldGetter(field, get_easeInCirc_18);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInCirc_18, null);
            field = type.GetField("easeOutCirc", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutCirc_19);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutCirc_19, null);
            field = type.GetField("easeInOutCirc", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutCirc_20);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutCirc_20, null);
            field = type.GetField("linear", flag);
            app.RegisterCLRFieldGetter(field, get_linear_21);
            app.RegisterCLRFieldBinding(field, CopyToStack_linear_21, null);
            field = type.GetField("spring", flag);
            app.RegisterCLRFieldGetter(field, get_spring_22);
            app.RegisterCLRFieldBinding(field, CopyToStack_spring_22, null);
            field = type.GetField("easeInBounce", flag);
            app.RegisterCLRFieldGetter(field, get_easeInBounce_23);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInBounce_23, null);
            field = type.GetField("easeOutBounce", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutBounce_24);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutBounce_24, null);
            field = type.GetField("easeInOutBounce", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutBounce_25);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutBounce_25, null);
            field = type.GetField("easeInBack", flag);
            app.RegisterCLRFieldGetter(field, get_easeInBack_26);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInBack_26, null);
            field = type.GetField("easeOutBack", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutBack_27);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutBack_27, null);
            field = type.GetField("easeInOutBack", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutBack_28);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutBack_28, null);
            field = type.GetField("easeInElastic", flag);
            app.RegisterCLRFieldGetter(field, get_easeInElastic_29);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInElastic_29, null);
            field = type.GetField("easeOutElastic", flag);
            app.RegisterCLRFieldGetter(field, get_easeOutElastic_30);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeOutElastic_30, null);
            field = type.GetField("easeInOutElastic", flag);
            app.RegisterCLRFieldGetter(field, get_easeInOutElastic_31);
            app.RegisterCLRFieldBinding(field, CopyToStack_easeInOutElastic_31, null);
            field = type.GetField("punch", flag);
            app.RegisterCLRFieldGetter(field, get_punch_32);
            app.RegisterCLRFieldBinding(field, CopyToStack_punch_32, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.tool.ITweenFunction.EaseType());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.tool.ITweenFunction.EaseType[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.tool.ITweenFunction.EaseType instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.tool.ITweenFunction.EaseType[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_easeInQuad_0(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInQuad;
        }

        static StackObject* CopyToStack_easeInQuad_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInQuad;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutQuad_1(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutQuad;
        }

        static StackObject* CopyToStack_easeOutQuad_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutQuad;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutQuad_2(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutQuad;
        }

        static StackObject* CopyToStack_easeInOutQuad_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutQuad;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInCubic_3(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInCubic;
        }

        static StackObject* CopyToStack_easeInCubic_3(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInCubic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutCubic_4(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutCubic;
        }

        static StackObject* CopyToStack_easeOutCubic_4(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutCubic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutCubic_5(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutCubic;
        }

        static StackObject* CopyToStack_easeInOutCubic_5(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutCubic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInQuart_6(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInQuart;
        }

        static StackObject* CopyToStack_easeInQuart_6(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInQuart;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutQuart_7(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutQuart;
        }

        static StackObject* CopyToStack_easeOutQuart_7(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutQuart;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutQuart_8(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutQuart;
        }

        static StackObject* CopyToStack_easeInOutQuart_8(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutQuart;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInQuint_9(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInQuint;
        }

        static StackObject* CopyToStack_easeInQuint_9(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInQuint;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutQuint_10(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutQuint;
        }

        static StackObject* CopyToStack_easeOutQuint_10(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutQuint;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutQuint_11(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutQuint;
        }

        static StackObject* CopyToStack_easeInOutQuint_11(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutQuint;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInSine_12(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInSine;
        }

        static StackObject* CopyToStack_easeInSine_12(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInSine;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutSine_13(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutSine;
        }

        static StackObject* CopyToStack_easeOutSine_13(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutSine;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutSine_14(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutSine;
        }

        static StackObject* CopyToStack_easeInOutSine_14(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutSine;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInExpo_15(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInExpo;
        }

        static StackObject* CopyToStack_easeInExpo_15(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInExpo;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutExpo_16(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutExpo;
        }

        static StackObject* CopyToStack_easeOutExpo_16(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutExpo;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutExpo_17(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutExpo;
        }

        static StackObject* CopyToStack_easeInOutExpo_17(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutExpo;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInCirc_18(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInCirc;
        }

        static StackObject* CopyToStack_easeInCirc_18(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInCirc;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutCirc_19(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutCirc;
        }

        static StackObject* CopyToStack_easeOutCirc_19(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutCirc;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutCirc_20(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutCirc;
        }

        static StackObject* CopyToStack_easeInOutCirc_20(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutCirc;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_linear_21(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.linear;
        }

        static StackObject* CopyToStack_linear_21(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.linear;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_spring_22(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.spring;
        }

        static StackObject* CopyToStack_spring_22(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.spring;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInBounce_23(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInBounce;
        }

        static StackObject* CopyToStack_easeInBounce_23(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInBounce;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutBounce_24(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutBounce;
        }

        static StackObject* CopyToStack_easeOutBounce_24(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutBounce;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutBounce_25(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutBounce;
        }

        static StackObject* CopyToStack_easeInOutBounce_25(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutBounce;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInBack_26(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInBack;
        }

        static StackObject* CopyToStack_easeInBack_26(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInBack;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutBack_27(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutBack;
        }

        static StackObject* CopyToStack_easeOutBack_27(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutBack;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutBack_28(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutBack;
        }

        static StackObject* CopyToStack_easeInOutBack_28(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutBack;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInElastic_29(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInElastic;
        }

        static StackObject* CopyToStack_easeInElastic_29(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInElastic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeOutElastic_30(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeOutElastic;
        }

        static StackObject* CopyToStack_easeOutElastic_30(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeOutElastic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_easeInOutElastic_31(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.easeInOutElastic;
        }

        static StackObject* CopyToStack_easeInOutElastic_31(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.easeInOutElastic;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_punch_32(ref object o)
        {
            return XD.tool.ITweenFunction.EaseType.punch;
        }

        static StackObject* CopyToStack_punch_32(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.tool.ITweenFunction.EaseType.punch;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.tool.ITweenFunction.EaseType();
            ins = (XD.tool.ITweenFunction.EaseType)o;
            return ins;
        }


    }
}
#endif
