#if USE_HOT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Linq;
using ILRuntime.CLR.TypeSystem;
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using ILRuntime.Runtime.Stack;
using ILRuntime.Reflection;
using ILRuntime.CLR.Utils;

namespace ILRuntime.Runtime.Generated
{
    unsafe class XD_Hook_XDHookManager_Binding_Format_Binding
    {
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            BindingFlags flag = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
            FieldInfo field;
            Type[] args;
            Type type = typeof(XD.Hook.XDHookManager.Format);

            field = type.GetField("Xml", flag);
            app.RegisterCLRFieldGetter(field, get_Xml_0);
            app.RegisterCLRFieldBinding(field, CopyToStack_Xml_0, null);
            field = type.GetField("Json", flag);
            app.RegisterCLRFieldGetter(field, get_Json_1);
            app.RegisterCLRFieldBinding(field, CopyToStack_Json_1, null);
            field = type.GetField("Binary", flag);
            app.RegisterCLRFieldGetter(field, get_Binary_2);
            app.RegisterCLRFieldBinding(field, CopyToStack_Binary_2, null);


            app.RegisterCLRCreateDefaultInstance(type, () => new XD.Hook.XDHookManager.Format());
            app.RegisterCLRCreateArrayInstance(type, s => new XD.Hook.XDHookManager.Format[s]);


        }

        static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, StackObject* ptr_of_this_method, IList<object> __mStack, ref XD.Hook.XDHookManager.Format instance_of_this_method)
        {
            ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);
            switch(ptr_of_this_method->ObjectType)
            {
                case ObjectTypes.Object:
                    {
                        __mStack[ptr_of_this_method->Value] = instance_of_this_method;
                    }
                    break;
                case ObjectTypes.FieldReference:
                    {
                        var ___obj = __mStack[ptr_of_this_method->Value];
                        if(___obj is ILTypeInstance)
                        {
                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            var t = __domain.GetType(___obj.GetType()) as CLRType;
                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, instance_of_this_method);
                        }
                    }
                    break;
                case ObjectTypes.StaticFieldReference:
                    {
                        var t = __domain.GetType(ptr_of_this_method->Value);
                        if(t is ILType)
                        {
                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = instance_of_this_method;
                        }
                        else
                        {
                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, instance_of_this_method);
                        }
                    }
                    break;
                 case ObjectTypes.ArrayReference:
                    {
                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as XD.Hook.XDHookManager.Format[];
                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = instance_of_this_method;
                    }
                    break;
            }
        }


        static object get_Xml_0(ref object o)
        {
            return XD.Hook.XDHookManager.Format.Xml;
        }

        static StackObject* CopyToStack_Xml_0(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookManager.Format.Xml;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Json_1(ref object o)
        {
            return XD.Hook.XDHookManager.Format.Json;
        }

        static StackObject* CopyToStack_Json_1(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookManager.Format.Json;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }

        static object get_Binary_2(ref object o)
        {
            return XD.Hook.XDHookManager.Format.Binary;
        }

        static StackObject* CopyToStack_Binary_2(ref object o, ILIntepreter __intp, StackObject* __ret, IList<object> __mStack)
        {
            var result_of_this_method = XD.Hook.XDHookManager.Format.Binary;
            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);
        }


        static object PerformMemberwiseClone(ref object o)
        {
            var ins = new XD.Hook.XDHookManager.Format();
            ins = (XD.Hook.XDHookManager.Format)o;
            return ins;
        }


    }
}
#endif
