﻿#if LOCALIZATION_UGUI_PRO
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using XD.tool;
using XD.Editor;
using System;

public class XDHookFieldTMPro : IXDXmlCache,IXDComponentExpland
{
    


    public void Regist(Action<string, Func<Transform[], string>> regist)
    {

        regist("TMFontSize", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return DeserializeStrategy.Deserialize(tm.fontSize);
        });
        regist("TMColor", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return DeserializeStrategy.Deserialize(tm.color);
        });

        regist("TMAlignment", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.alignment.ToString();
        });
        regist("TMLineSpcae", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.lineSpacing.ToString();
        });
        regist("TMWordSpcae", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.wordSpacing.ToString();
        });
        regist("TMParagraphSpcae", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.paragraphSpacing.ToString();
        });
        regist("TMCharSpcae", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.characterSpacing.ToString();
        });
        regist("TMFontStyles", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.fontStyle.ToString();
        });
        regist("TMWarpping", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.enableWordWrapping.ToString();
        });
        regist("TMOverflowMode", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            return tm.overflowMode.ToString();
        });
        regist("TMAutoSize", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            Vector4 v = new Vector4(tm.fontSizeMin, tm.fontSizeMax, tm.characterWidthAdjustment, tm.lineSpacingAdjustment);
            return DeserializeStrategy.Deserialize(v);
        });
        regist("TMMargin", (ts) =>
        {
            TMPro.TextMeshProUGUI tm = ts[0].GetComponent<TMPro.TextMeshProUGUI>();
            if (tm == null)
            {
                return "";
            }
            Vector4 v = tm.margin;
            return DeserializeStrategy.Deserialize(v);
        });
    }

    public void Regist(Action<Type, Action<Component>> regist)
    {
        regist(typeof(TMPro.TextMeshProUGUI), (c) =>
        {
            TMPro.TextMeshProUGUI label = (TMPro.TextMeshProUGUI)c;
            EditorGUILayout.LabelField($"Text:",GUILayout.Width(80));
            EditorGUILayout.TextField(label.text, GUILayout.Width(200));
        });
    }
}

#endif