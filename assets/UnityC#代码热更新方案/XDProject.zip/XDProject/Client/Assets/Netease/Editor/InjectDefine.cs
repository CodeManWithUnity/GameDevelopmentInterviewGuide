﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using MonoXIL.Cecil;
using UnityEngine;

namespace XD.IL
{
    public class InjectDefineMain : InjectDefine
    {
      
        public List<string> skip_inject_name = new List<string>()
        {
            "ILRuntime",
            //"XD.Loader",
            "wxb.",

            "UnityEditor",
            
            "UniWebView",
            



        };
        public List<Type> skip_inject_type = new List<Type>()
        {           
            typeof(WebViewObject),
            typeof(UnityWebView),            
        };
       
        private List<MethodBase> skip_inject_method = new List<MethodBase>()
        {
           
        };
        public bool CheckType(TypeDefinition type)
        {
            string full_name = type.FullName;
            foreach (var bl in skip_inject_name)
            {
                if (full_name.Contains(bl))
                {
                    Debug.Log($"SkipInjectType Name,[{type}]");
                    return false;
                }
            }
            foreach (var t in skip_inject_type)
            {
                if (type.FullName == t.FullName)
                {
                    Debug.Log($"SkipInjectType Type,[{type}]");
                    return false;
                }
            }
            return true;
        }
        public bool CheckType(Type type)
        {
            string full_name = type.FullName;
            foreach (var bl in skip_inject_name)
            {
                if (full_name.Contains(bl))
                {
                    Debug.Log($"SkipInjectType Name,[{type}]");
                    return false;
                }
            }
            foreach (var t in skip_inject_type)
            {
                if (type.FullName == t.FullName)
                {
                    Debug.Log($"SkipInjectType Type,[{type}]");
                    return false;
                }
            }
            return true;
        }
        public bool CheckMethod(MethodDefinition method)
        {
            if(method.Name=="Update")
            {
                return false;
            }
            foreach (MethodBase m in skip_inject_method)
            {
                if (method.DeclaringType.FullName == m.DeclaringType.FullName && method.Name == m.Name)
                {
                    return false;
                }
            }
            return true;
        }
      
        public bool CheckBridgeType(Type type)
        {
           return true;
        }

        public bool CheckBridgeMethod(MethodInfo method)
        {
            return true;
        }
    }
    public class EditorDefineMain : EditorDefine
    {
        public bool IsEditorDelegate(Type dele)
        {
            return false;
        }

        public bool IsEditorMethod(MethodBase method)
        {
            return false;
        }
        public static List<Type> editor_types = new List<Type>()
        {
           
        };
        public bool IsEditorType(Type type)
        {
            return editor_types.Contains(type);
        }
    }
}