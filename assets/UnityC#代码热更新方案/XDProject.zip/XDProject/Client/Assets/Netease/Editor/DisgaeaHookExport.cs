﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.Editor.Hook;

public class DisgaeaHookExport : IHookExportSetting
{
    public bool CheckPrefab(string name)
    {
        return !name.Contains(@"AssetBundles/prefabs/effect/command")&& !name.Contains(@"AssetBundles\prefabs\effect\command");
    }

    public bool CheckScene(string name,string root)
    {
        return true;
    }

    public string[] GetPrefabDirs()
    {
        return new string[] { "Assets"};
    }

    public string[] GetSceneDirs()
    {
        return new string[] { "Assets" };
    }
}
