﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using XD.tool;

namespace XD.IL
{
    public class RegtypeDefineMain : ILRegTypeDefine
    {
       

        public Assembly Assembly()
        {
            return ReflectionTool.GetAssembly("Assembly-CSharp");
        }

        public bool CheckDelegate(Type d)
        {
            return true;
        }
        private List<Type> skip_list = new List<Type>()
        {
            //typeof(Unagi.Asset.Utility),
            typeof(WebViewObject),
            typeof(UnityWebView)
        };
        private List<MethodBase> skip_inject_method = new List<MethodBase>()
        {
            //XDILGenUtility.GetMethod(typeof(Unagi.DB.Sqlite3.Sqlite3),"Dump"),
            //XDILGenUtility.GetMethod(typeof(Unagi.DB.KVS.KVSRecordBase),"Load"),
            //XDILGenUtility.GetMethod(typeof(Unagi.Network.WebAPIRequest),"Create"),
        };

        public bool CheckType(Type type)
        {
            return !skip_list.Contains(type);
        }

        public bool CheckMethod(MethodBase method)
        {
            foreach (MethodBase m in skip_inject_method)
            {
                if (method.DeclaringType.FullName == m.DeclaringType.FullName && method.Name == m.Name)
                {
                    return false;
                }
            }
            return true;
        }

        public bool CheckFieldAndProperty(Type source)
        {
           return true;
        }
    }

    //public class RegtypeDefineFirstpass : ILRegTypeDefine
    //{
    //    public Assembly Assembly()
    //    {
    //        return ReflectionTool.GetAssembly("Assembly-CSharp-firstpass");
    //    }
    //    private List<Type> skip_delegate = new List<Type>()
    //    {
    //        //typeof(CriAtomPlugin.PreviewCallback),
    //    };
    //    public bool CheckDelegate(Type d)
    //    {
    //        return !skip_delegate.Contains(d);
    //    }
    //    private List<Type> skip_list = new List<Type>()
    //    {
    //        //typeof(CriAtomPlugin),            
    //    };

    //    public bool CheckType(Type type)
    //    {
    //        return !skip_list.Contains(type);
    //    }

    //    public bool CheckMethod(MethodBase method)
    //    {
    //        return true;
    //    }
    //    public bool CheckFieldAndProperty(Type source)
    //    {
    //        return true;
    //    }
    //}
}
