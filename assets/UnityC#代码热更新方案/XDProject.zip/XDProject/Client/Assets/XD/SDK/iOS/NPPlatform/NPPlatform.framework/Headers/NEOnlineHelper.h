//
//  NEOnlineHelper.h
//  NEOnlineHelper
//

#define NUSDK_VERSION @"2.3.0"

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NPSDKHelper.h"

@interface NEOnlineUser : NSObject
@property (retain)  NSString* channelId;
@property (retain)  NSString* channelUserId;
@property (retain)  NSString* userName;
@property (retain)  NSString* token;
@property (retain)  NSString* nickName;
@property (retain)  NSString* userAvatar;
@property (retain)  NSString* productCode;
@end

@interface NEOrder : NSObject
@property (retain)  NSString* signedOrder;
@property (retain)  NSString* orderId;
@end

@protocol NEOnlineInitDelegate <NSObject>
-(void) onInitResponse:(int) index : (NSString*) msg;
@end

@protocol NEOnlinePayResultDelegate <NSObject>
@required
-(void) onFailed : (NSString*) msg;
-(void) onSuccess : (NSString*) msg;
-(void) onOderNo : (NSString*) msg;
@end

@protocol NEOnlineLoginDelegate <NSObject>
@required
-(void) onLogout : (NSString *) remain;
-(void) onLoginSuccess : (NEOnlineUser*) user : (NSString *) remain;
-(void) onLoginFailed : (NSString*) reason : (NSString *) remain;
@end

@protocol NEOnlineExitDelegate <NSObject>
@required
-(void) onNoExiterProvide;
-(void) onSDKExit : (BOOL) isExit;
@end

@protocol NEOnlineCommonDelegate <NSObject>
-(void) onCommonResponse:(int) index :(NSString*) tag :(NSString*) value;
@end

@protocol IAfterOrder <NSObject>
@required
-(void) afterOrder : (BOOL) isSuccess : (NEOrder*) order;
@end

@interface NEOnlineHelper : NSObject<NPSDKHelperInitDelegate, NPSDKHelperLoginDelegate, NPSDKHelperPayDelegate, NPSDKHelperBindDelegate, NPSDKHelperLogDelegate, IAfterOrder>
+(id) Instance;
- (void) setInitListener:(id)initListener;
- (void) setLoginListener:(id)loginListener;
- (void) exit:(id)exitListener;
- (void) login:(NSString*)remain;
- (void) logout:(NSString*)remain;
- (void) pay:(int32_t)unitPrice :(NSString*)unitName :(NSString*)productId :(NSString*)currencyType :(int32_t)count :(NSString*)callBackInfo :(NSString*)callBackUrl :(id)payResultListener;
- (void) setRoleData:(NSString*)roleId :(NSString*)roleName :(NSString*)roleLevel :(NSString*)zoneId :(NSString*)zoneName;
- (void) setData:(NSString*)key :(NSString*)value;
- (NSString*) getData:(NSString*)key :(NSString*)value;
- (void) callCommonApi:(NSString *)apiName :(NSString *)apiArgs :(id)commonApiListener;

/* 生命周期 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
- (void)applicationDidEnterBackground:(UIApplication *)application;
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url;
- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler;
- (void)applicationWillTerminate:(UIApplication *)application;
@end

