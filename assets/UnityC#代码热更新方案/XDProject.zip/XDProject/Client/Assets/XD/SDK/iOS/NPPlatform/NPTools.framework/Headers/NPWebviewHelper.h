//
//  NPWebviewHelper.h
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#pragma mark - 通用接口定义(CP接入)

@interface NPWebviewHelper : NSObject

@property (nonatomic, assign) int ScreenOrientation;   // webview朝向：0 - 可旋转；1 - 仅限横屏Left；2 - 仅限竖屏Portrait
@property (nonatomic, assign) BOOL TitleEnable;        // 是否显示标题：YES - 显示；NO - 不显示
@property (nonatomic, assign) BOOL BackEnable;         // 是否显示返回按钮：YES - 显示；NO - 不显示
@property (nonatomic, assign) int LinkStyle;           // webview内超链接跳转方式：0 - webview内跳转；1 - 跳转至外部浏览器
@property (nonatomic, copy) NSString *NavigationColor; // 导航栏颜色

+ (NPWebviewHelper *)Instance;

/*
 * webview
 * @param
 *
 * 默认风格：竖屏 | 标题隐藏 | 返回按钮隐藏 | webview内跳转 | 导航栏网易红
 */
- (void)show:(NSString *)url withRotateEnable:(BOOL)rotateEnable;

/* 调试模式开关 */
- (void)openDebugMode;

@end
