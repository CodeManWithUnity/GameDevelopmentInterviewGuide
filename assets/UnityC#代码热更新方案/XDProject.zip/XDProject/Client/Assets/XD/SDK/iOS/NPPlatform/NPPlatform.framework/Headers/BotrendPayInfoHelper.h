//
//  BotrendPayInfoHelper.h
//  NPPlatform
//
//  Created by 葛宝生 on 2018/12/27.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#ifndef BotrendPayInfoHelper_h
#define BotrendPayInfoHelper_h

#import <Foundation/Foundation.h>

/* 支付信息 */
@interface BotrendPayInfoHelper : NSObject

@property (copy, nonatomic) NSString *roleId;
@property (copy, nonatomic) NSString *roleName;
@property (copy, nonatomic) NSString *serverId;
@property (copy, nonatomic) NSString *serverName;

@property (copy, nonatomic) NSString *orderId;
@property (copy, nonatomic) NSString *productId;
@property (copy, nonatomic) NSString *productName;
@property (copy, nonatomic) NSString *currencyType;
@property (assign, nonatomic) int32_t productPrice;
@property (assign, nonatomic) int32_t productCount;

@property (copy, nonatomic) NSString *callbackInfo;         // CP支付透传参数
@property (copy, nonatomic) NSString *callbackURL;          // CP支付回调地址

@property (assign, nonatomic) int orderType;                // 0-sandbox | 1-formal

+ (instancetype)instance;
- (instancetype)newInstance;
@end

#endif /* BotrendPayInfoHelper_h */
