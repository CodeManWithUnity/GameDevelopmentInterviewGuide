

#ifndef UnitySDKListener_h
#define UnitySDKListener_h
#import "StringTool.h"
#import "DataManager.h"
#import "SDKData.h"
#import "DataManager.h"
#import "JSONFactory.h"

// static const char* Unity_Init_Over="OnInitOver";
// static const char* Unity_Login_Over="OnLogin";

// static const char* Unity_Pay_Over="OnPayOver";
// //static const char* Unity_Switch_Account="OnSwitchAccount";
// static const char* Unity_Logout="OnLogout";
// //static const char* Unity_Session_Invalid="OnSessionInvalid";
// static const char* Unity_Exit="OnExit";
// static const char* Unity_Event="OnEvent";

// void UnitySend(const char* fun,NSMutableDictionary* par)
// {
    // NSLog(@"UnitySend %s,dic=%@",fun,par);
	// NSString* gameobject=[DataManager Get:@"unity_sdk_listener"];
    // NSString* json=DictionaryToJson(par);
     // NSLog(@"UnitySend %s,Json=%@",fun,json);
    // UnitySendMessage([gameobject  UTF8String],fun,[json UTF8String]);    
    
// }


// void UnitySendEvent(NSMutableDictionary* dic)
// {
    // UnitySend(Unity_Event,dic);
// }

// void UnitySendInitOver(NSString* msg)
// {
    // NSMutableDictionary* dic=MessageResult(RES_CODE_NO_ERROR,msg);
    // UnitySend(Unity_Init_Over,dic);
// }

// void UnitySendLogin(SDKBase* sdk)
// {
    // NSMutableDictionary* dic=LoginToken(sdk);
    // UnitySend(Unity_Login_Over,dic);
// }


// void UnitySendLoginError(int error ,NSString* msg)
// {
    // NSMutableDictionary* dic=MessageResult(error, msg);
    // UnitySend(Unity_Login_Over,dic);
// }

// void UnitySendLogout(int error,NSString* msg)
// {
      // NSMutableDictionary* dic=MessageResult(error, msg);
    // UnitySend(Unity_Logout, dic);
// }

// void UnitySendPay(SDKBase* sdk)
// {
    // NSMutableDictionary*dic=PaySucess(sdk);
    // UnitySend( Unity_Pay_Over, dic);
// }
// void UnitySendPayError(int error,NSString* msg)
// {
    // NSMutableDictionary*dic=MessageResult(error, msg);
    // UnitySend( Unity_Pay_Over, dic);
// }

// void UnitySendExit(NSMutableDictionary* dic)
// {
    // UnitySend(Unity_Exit, dic);
// }

//void UnityPlatformHook(NSString* message,NSMutableDictionary* dic)
//{
//    [dic setObject:message forKey:@"MessageType"];
//    UnitySendMessage("PlatformHook","OnHookCallback",[DictionaryToJson(dic) UTF8String]);
//}

#endif /* PlatformSender_h */
