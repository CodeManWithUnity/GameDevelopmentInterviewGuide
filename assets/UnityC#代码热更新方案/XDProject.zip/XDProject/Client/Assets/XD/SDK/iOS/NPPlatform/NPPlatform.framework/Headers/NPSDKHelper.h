//
//  NPSDKHelper.h
//  NPPlatform
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "BotrendPayInfoHelper.h"

// 内购步骤
typedef NS_ENUM(NSInteger, IAPStep) {
    IAPStepAddTransactionObserver,      // 添加交易监听
    IAPStepCheckUnfinishedTransaction,  // 检查未完成的交易
    IAPStepCallPurchaseInterface,       // 调用支付接口
    IAPStepNotSupportPayments,          // 不支持内购
    IAPStepProcessPreviousTransaction,  // 开始处理在此之前未完成的交易
    IAPStepStartPaymentFlow,            // 开始支付流程
    IAPStepCreateOrderStubSuccess,      // 创建订单存根成功
    IAPStepCreateOrderStubFailure,      // 创建订单存根失败
    IAPStepStartRequestProductInfo,     // 开始请求商品详情
    IAPStepRequestProductInfoSuccess,   // 请求商品详情成功
    IAPStepRequestProductInfoFailure,   // 请求商品详情失败
    IAPStepRequestProductInfoFinish,    // 请求商品详情完成
    IAPStepResponseWithInvalidProducts, // 请求商品成功，但返回了无效商品
    IAPStepResponseWithoutProducts,     // 没有可用的商品，需检查iTunesConnect中的商品配置
    IAPStepSelectedInvalidProduct,      // 选中的商品处于失效状态，需检查iTunesConnect中的商品配置
    IAPStepSelectedProduct,             // 成功获取当前要购买的商品
    IAPStepAddToPaymentQueue,           // 已成功将购买请求加入队列，开始等待StoreKit回调
    IAPStepUpdateTransaction,           // 收到StoreKit回调
    IAPStepTransactionError,            // 交易出现错误
    IAPStepCallbackPaymentResult,       // 回调支付结果
    IAPStepReceiptError,                // 票据不存在
    IAPStepProcessTransaction,          // 开始处理Transaction
    IAPStepStartReportToServer,         // 开始上报订单给服务器
    IAPStepReportToServerSuccess,       // 上报订单给服务器成功
    IAPStepReportToServerFailure,       // 上报订单给服务器失败
    IAPStepStartFinishTransaction,      // 开始结束交易
    IAPStepFinishTransactionSuccess,    // 结束交易成功
    IAPStepEndPaymentFlow,              // 结束支付流程
    IAPStepStartReissueOrder,           // 开始补发订单（如有未上报成功的订单，在个人中心可以手动补发）
    IAPStepReissueOrderSuccess,         // 补发订单成功
    IAPStepReissueOrderFailure,         // 补发订单失败
    IAPStepRemoveTransactionObserver    // 移除交易监听
};

/* 用户信息 */
@interface NPSDKHelperUser : NSObject

@property (copy, nonatomic) NSString *channelUserId;
@property (copy, nonatomic) NSString *userName;
@property (copy, nonatomic) NSString *token;
@property (copy, nonatomic) NSString *nickName;
@property (copy, nonatomic) NSString *userAvatar;

//+ (instancetype)instance;

@end


#pragma mark - 回调协议

/* 初始化 */
@protocol NPSDKHelperInitDelegate<NSObject>

@required
- (void)onNPInitSuccess:(NSString *)msg;
- (void)onNPInitFailure:(NSString *)msg;

@end

/* 登录 */
@protocol NPSDKHelperLoginDelegate<NSObject>

@required
- (void)onNPLoginSuccess:(NPSDKHelperUser *)user;
- (void)onNPLoginFailed:(NSString *)reason;

- (void)onNPLogout:(NSString *)msg;

- (void)onNPSwitch:(NPSDKHelperUser *)newUser;

@optional
- (void)onNPLoginUIClosed:(NSString *)msg;

@end

/* 实名认证 */
//@protocol NPSDKHelperRealNameDelegate<NSObject>
//
//@required
//- (void)onNPRealNameVerified:(BOOL)flag;
//
//@end

/* 支付 */
@protocol  NPSDKHelperPayDelegate<NSObject>

@required
- (void)onNPPaySuccess:(NSString *)msg;
- (void)onNPPayFailed:(NSString *)reason;

@end

/* 绑定 */
@protocol NPSDKHelperBindDelegate <NSObject>

@required
- (void)onBindSuccess:(NSString *)msg;
- (void)onBindFailed:(NSString *)reason;

@end

/* 日志 */
@protocol NPSDKHelperLogDelegate <NSObject>

@required
- (void)onLog:(NSString *)log;

@end

#pragma mark - 通用接口定义(CP接入)

@interface NPSDKHelper : NSObject

+ (NPSDKHelper *)Instance;

/* 生命周期 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
- (void)applicationDidEnterBackground:(UIApplication *)application;
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url;
- (void)applicationWillTerminate:(UIApplication *)application;


// 设置初始化回调
+ (void)setInitDelegate:(id)initListener;

/* 是否已经初始化 */
+ (BOOL)isInited;

/* 获取NPSDK服务端环境 */
+ (NSString *)getSdkEnv;

/* 设置NPSDK服务端环境 */
+ (void)setSdkEnvironment:(NSString *)mode;

/*
 * 登录
 * @param loginListener - 登录回调
 */
+ (void)login:(id)loginListener;

/* 是否已经登录 */
+ (BOOL)isLogined;

/* 用户中心 */
+ (void)showUserCenter;

/* 切换账号 */
//+ (void)switchAccount;

/* 隐藏悬浮窗 */
+ (void)hideFloatingWindow;

/* 显示悬浮窗 */
+ (void)showFloatingWindow;

/* 获取用户自定义悬浮窗显隐开关 */
+ (BOOL)getUserFloatWindowFlag;

/* 获取当前用户昵称 */
+ (NSString *)getCurrentNickname;

/* 获取当前用户头像 */
+ (NSString *)getCurrentUserAvatar;

/* 获取身份凭证 */
+ (NSString *)getUserTicket;

/* 注销登录 */
 + (void)logout;

/* 支付 */
+ (void)purchase:(BotrendPayInfoHelper *)payInfo withCallback:(id)payResultDelegate;

/* 上传支付请求信息 */
+ (void)submitPayRequestReq:(NSString *)orderID
              withProductID:(NSString *)productID
            withProductName:(NSString *)productName
             withProductDes:(NSString *)productDes
           withCurrencyType:(NSString *)currencyType
         withCurrencyAmount:(NSString *)currencyAmount
                withPayType:(NSString *)payType
            withRequestTime:(NSString *)requestTime
                  withAppID:(NSString *)appID
              withChannelID:(NSString *)channelID
                 withUserID:(NSString *)userID
                 withRoleID:(NSString *)roleID
               withRoleName:(NSString *)roleName
                 withZoneID:(NSString *)zoneID
               withZoneName:(NSString *)zoneName
               withPlatform:(NSString *)plat;

/* 上传支付成功信息 */
+ (void)submitPaySuccessReq:(NSString *)orderID
            withSuccessTime:(NSString *)successTime
                  withAppID:(NSString *)appID
               withPlatform:(NSString *)plat;

/* 是否已经实名认证 */
+ (BOOL)isRealNameVerified;

/* 实名认证 */
//+ (void)requestRealNameVerify:(NSString *)name andIDNum:(NSString *)idNum andPhoneNum:(NSString *)phoneNum andDelegate:(id)realNameDelegate;

/* 获取NPSDK版本号 */
+ (NSString *)getSdkVersion;

/* 用户注册统计 */
+ (void)setRegisterWithAccount:(NSString *)account;

/* 用户登录统计 */
+ (void)setLoginWithAccount:(NSString *)account;

/* 用户订单统计 */
+ (void)createOrder:(NSString *)orderNo currencyType:(NSString *)type currencyAmount:(float)amount;
+ (void)createOrder:(NSString *)orderNo currencyAmount:(float)amount;

/* 充值成功统计 */
+ (void)paymentWithOrder:(NSString *)orderNo payType:(NSString *)payType currencyType:(NSString *)type currencyAmount:(float)amount;
+ (void)paymentWithOrder:(NSString *)orderNo payType:(NSString *)payType currencyAmount:(float)amount;

/* 自定义事件统计 */
+ (void)setEvent:(NSString *)desc;

/* 调试模式开关 */
+ (void)setDebugMode:(BOOL)flag;

/* 打开绑定账号页面 */
+ (void)bindAccount:(id<NPSDKHelperBindDelegate>)delegate;

/* 监听日志 */
+ (void)startLog:(id<NPSDKHelperLogDelegate>)delegate;

/* 是否已存在游戏自有账号 */
+ (BOOL)isCustomerLoginAvailable;

/*
*处理游戏自有账号数据
*/
+ (void)processCustomerLoginData:(NSString *)data delegate:(id<NPSDKHelperLoginDelegate>)loginDelegate;

@end
