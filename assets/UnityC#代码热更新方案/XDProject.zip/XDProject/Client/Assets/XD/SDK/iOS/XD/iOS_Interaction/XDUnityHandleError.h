//
//  XDUnityHandleError.h
//  Unity-iPhone
//
//  Created by aaa on 2020/8/27.
//

#ifndef XDUnityHandleError_h
#define XDUnityHandleError_h
#include "StringTool.h"

static void XDUnityHandleError(NSString* receiver,int task_id,NSString* error)
{
   NSMutableDictionary* res=[[NSMutableDictionary alloc] initWithCapacity:5];
    
    [res setObject:receiver forKey:@"receiver"];
    [res setObject:[NSNumber numberWithInt:task_id] forKey:@"task_id"];
  
    [res setObject:error forKey:@"error"];
    NSString* json=DictionaryToJson(res);
    UnitySendMessage("XDUnityHandle","OnResponse",[json UTF8String]);
}

#endif /* XDUnityHandleError_h */
