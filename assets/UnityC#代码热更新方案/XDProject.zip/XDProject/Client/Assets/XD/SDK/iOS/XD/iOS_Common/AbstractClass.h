#ifndef AbstractClass_h
#define AbstractClass_h

#define AbstractMethodNotImplemented()\
@throw [NSException exceptionWithName:NSInternalInconsistencyException \
reson:[NSString stringWithFormat:@"Abstrct Method"] userInfo:nil]

#endif

