//#import <Foundation/Foundation.h>
//#import "StringTool.h"
//#import "SDKBase.h"
//#import "DataManager.h"
//#import "UnityInterface.h"
//#include "SDKData.h"
//
//
//
//static char* GetChar(const char* cc)
//{
//    char* c=new char[strlen(cc)+1];
//    strcpy(c, cc);
//    return  c;
//}
//
//
//#pragma mark Plug-in Function
//
//extern "C"
//{
//    static NSMutableArray *sdks;
//    void InitApp(const char *json) {
//        NSDictionary* dic=CreateDictionary(json);
//        NSString* game_object=[dic objectForKey:IKey_Gameobject];
//		[DataManager Set:@"unity_sdk_listener" Value:game_object];
//		NSArray* list_sdks=[dic objectForKey:@"sdk_configs"];
//        sdks=[[NSMutableArray alloc] initWithCapacity:[list_sdks count]];
//       for(int i=0;i<[list_sdks count];++i)
//	   {
//		   NSDictionary* dic_sdk=[list_sdks objectAtIndex:i];
//		   NSString* class_name=[dic_sdk objectForKey:@"class"];
//		   Class c=NSClassFromString(class_name);
//           SDKBase* sdk=[[c alloc] init] ;
//           [sdk InitApp:dic_sdk];
//           [sdks addObject:sdk];
//           [SDKData Set:[NSString stringWithFormat:@"%@_config",class_name] Value:dic_sdk];
//        }
//    }
//	SDKBase* GetSDK(NSDictionary* dic)
//	{
//		NSNumber* p=[dic objectForKey:@"Platform"];
//        int pi=[p intValue];
//		if(pi<0||pi>=[sdks count])
//		{
//			return [sdks objectAtIndex:0];
//		}
//		return [sdks objectAtIndex:pi];
//	}
//    
//
//    void Login(const char *json) {
//        NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) Login:dic];
//    }
// 		void Logout(const char *json) {
//            NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) Logout:dic];
//    }
//       char* PurchasePre(const char *json)
//    {
//        NSDictionary* dic=CreateDictionary(json);
//        NSString* out= [GetSDK(dic) PurchasePre:dic];
//        return GetChar([out UTF8String]);
//    }
//
//   void Purchase(const char *json) {
//       NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) Purchase:dic];
//    }
//    void Exit(const char *json)
//    {
//        NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) Exit:dic];
//    }
//    
//    void SetUserData(const char *json)
//    {
//        NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) SetUserData:dic];
//    }
//	void Event(const char *json)
//    {
//        NSDictionary* dic=CreateDictionary(json);
//        [GetSDK(dic) Event:dic];
//    }
//    
//     char* GetUserData(const char *json)
//    {
//       NSDictionary* dic=CreateDictionary(json);
//        NSString* out= [GetSDK(dic) GetUserData:dic];
//        return GetChar([out UTF8String]);
//    }
//    
//    
//    
//     char* GetFeatures(const char *json)
//    {
//		 NSDictionary* dic=CreateDictionary(json);
//        NSString* out= [GetSDK(dic) GetFeatures];
//        NSLog(@"Platform Config:%@      Char:%s",out,[out UTF8String]);
//        
//        return GetChar([out UTF8String]) ;
//    }
//}
//
//
//
//
