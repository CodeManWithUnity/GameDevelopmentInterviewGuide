#import <Foundation/Foundation.h>
#import "StringTool.h"

#import "DataManager.h"
#import "XDUnityInteraction.h"






#pragma mark Plug-in Function

extern "C"
{
   
    void XD_Handle_SetRegisted(const char *key,bool b) {
        [XDUnityInteraction SetRegisted:CreateNSString(key) Value:b];
    }
	
    

    void XD_Handle_Request(const char *key,int tid,const char *json,bool ui_thread) {
        NSLog(@"XD_Handle_Request Json=%s",json);
		NSDictionary* dic=CreateDictionary(json);
        [XDUnityInteraction ProcessRequest:dic  Reciever:CreateNSString(key) Task:tid];
    }
 	
}




