
#ifndef StringTool_h
#define StringTool_h

static NSString* CreateNSString (const char* string) {
    return [NSString stringWithUTF8String:(string ? string : "")];
}

static NSDictionary* CreateDictionary(const char* json)
{
    NSError* error;
    NSData* data=  [CreateNSString(json) dataUsingEncoding:NSASCIIStringEncoding];
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data
                                                    options:NSJSONReadingAllowFragments
                                                      error:&error];
    
    if (jsonObject != nil && error == nil){
        return jsonObject;
    }else{
        return nil;
    }
}
static NSDictionary* CreateDictionaryWithNS(NSString* json)
{
    NSError* error;
    NSData* data=  [json dataUsingEncoding:NSASCIIStringEncoding];
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data
                                                    options:NSJSONReadingAllowFragments
                                                      error:&error];
    
    if (jsonObject != nil && error == nil){
        return jsonObject;
    }else{
        return nil;
    }
}


static NSString* DictionaryToJson(NSDictionary* par)
{
    if(par!=nil)
    {
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:par
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        NSString *json = [[NSString alloc] initWithData:jsonData
                                               encoding:NSUTF8StringEncoding];
        return json;
    }
    else
    {
        return @"";
    }
    
}
#endif
