//
//  PlatformPlugin.m
//  Unity-iPhone
//
//  Created by aaa on 16/1/8.
//
//

#import <Foundation/Foundation.h>
#import "DataManager.h"
#include "XDUnityInteraction.h"
#include "XDUnityHandle.h"
#include "EventManager.h"
#import <objc/runtime.h>
#include "StringTool.h"
#include "XDUnityHandleError.h"

@implementation XDUnityInteraction

NSMutableDictionary* handles;

//+(void)AutoRegist:(EventManager*) evt
//{
//	Class p=[XDUnityHandle class];
//    int numClasses=objc_getClassList(NULL,0 );
//    Class* classes=NULL;
//    classes=(Class*)malloc(sizeof(Class)*numClasses);
//    numClasses=objc_getClassList(classes, numClasses);
//    handles=[[NSMutableDictionary alloc] initWithCapacity:5];
//
//    for(int i=0;i<numClasses;++i)
//    {
//        Class superClass=classes[i];
//        do{
//            superClass=class_getSuperclass(superClass);
//        }
//        while(superClass&&superClass!=p);
//        if(superClass==nil){continue;}
//        XDUnityHandle* l=[[classes[i] alloc] init] ;
//        [l Regist:evt];
//
//        [XDUnityInteraction Regist:[l GetReciever] Handle:l];
//    }
//    free(classes);
//}
+(void)initialize
{
    handles=[[NSMutableDictionary alloc] initWithCapacity:5];
}
+(void)Regist:(NSString*) reciever Handle:(XDUnityHandle*) handler
{
  
 [handles setObject:handler forKey:reciever];

}
+(void)SetRegisted:(NSString*) reciever Value:(bool)b
{
	XDUnityHandle* l=[handles objectForKey:reciever] ;
	if(l!=nil)
	{
	[l SetRegisted:b];
	}
}
+(void)ProcessRequest:(NSDictionary*)dic Reciever:(NSString*)reciever Task:(int) task_id
{
	XDUnityHandle* l=[handles objectForKey:reciever] ;
	//NSDictionary* dic=CreateDictionary(ps);
	if(l!=nil)
	{
		[l ProcessRequest:dic Task:task_id];
	}
    else{
//        NSDictionary* res=[XDUnityHandle TransData:nil Task:task_id Reciever:reciever Error:@"NotArriviable"];
//        [XDUnityHandle SendToUnityInter:res];
        XDUnityHandleError(reciever,task_id,@"NotArriviable");
    }
}
@end
