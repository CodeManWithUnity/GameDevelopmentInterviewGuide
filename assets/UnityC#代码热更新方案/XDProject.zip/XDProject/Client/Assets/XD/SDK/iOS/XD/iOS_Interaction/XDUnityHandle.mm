#include "XDAppListener.h"
#import <objc/runtime.h>
#include "AbstractClass.h"
#include "XDUnityHandle.h"
#include "StringTool.h"
@implementation XDUnityHandle


-(id) init
{
    if( (self = [super init]) )
    {
   
    }
    self.list_result=[[NSMutableArray alloc] initWithCapacity:5];
    return self;
}
-(void)Regist:(EventManager *)evt
{
    // AbstractMethodNotImplemented();
}
-(void) ProcessRequest:(NSDictionary *)json Task:(int)task_id
{
    
}


-(NSString*) GetReciever
{
//	 AbstractMethodNotImplemented();
    return @"";
}
+(void)SendToUnityInter:(NSDictionary*) dic_all
{
    
     NSString* json=DictionaryToJson(dic_all);
     NSLog(@"UnitySend ,Json=%@",json);
    UnitySendMessage("XDUnityHandle","OnResponse",[json UTF8String]);
    NSLog(@"UnitySend Over-------------------------");
    
}
-(void)SendToUnity:(NSDictionary*) dic Task:(int)task_id
{
	NSDictionary* result=[XDUnityHandle TransData:dic Task:task_id Reciever:[self GetReciever] Error:nil];
	if(![self registed])
	{
		[[self list_result] addObject:result];
		
		if(![self in_task])
		{
			[self CheckRegist];
			self.in_task=true;
		}
	}
	else
	{
		[XDUnityHandle SendToUnityInter:result];
	}
}
-(void)CheckRegist
{
	if([self registed])
	{
		[self SendToUnityAll];
	}
	else		
	{
		[self performSelector:@selector(CheckRegist) withObject:nil afterDelay:1];
	}
}
-(void)SendToUnityAll
{
	
	 for(int i=0;i<[[self list_result] count];++i)
	 {
		NSDictionary* dic=[[self list_result] objectAtIndex:i];
		[XDUnityHandle SendToUnityInter:dic];
	 }
	 [[self list_result] removeAllObjects];
}
+(NSDictionary*)TransData: (NSDictionary*) dic Task:(int)task_id Reciever:(NSString*)reciever Error:(NSString*)error
{
    NSMutableDictionary* res=[[NSMutableDictionary alloc] initWithCapacity:5];
    
    [res setObject:reciever forKey:@"receiver"];
    [res setObject:[NSNumber numberWithInt:task_id] forKey:@"task_id"];
    if(dic!=nil)[res setObject:dic forKey:@"result"];
        if(error!=nil)[res setObject:error forKey:@"error"];
    return res;
//	return [[NSDictionary alloc] initWithObjectsAndKeys:@"receiver",reciever,@"result",dic,@"task_id",task_id,nil];
}

-(void) SetRegisted:(bool)b
{
    self.registed=b;
}
@end
