#include "DataManager.h"
#include "EventManager.h"
#include "XDAppListener.h"
#include "CollectionTool.h"
//#import <NPPlatform/NPSDKHelper.h>
#import <NPPlatform/NEOnlineHelper.h>

@interface NUAppListener : XDAppListener<NEOnlineInitDelegate>

@end
@implementation NUAppListener

-(void) onInitResponse:(int)index :(NSString *)msg
{
    NSLog(@"onInitResponse=%@,%d",msg,index);
}
-(void)Regist:(EventManager *)evt
{
  
//    [NEOnlineHelper ini:self];
    [evt RegistEvent:AE_didFinishLaunchingWithOptions Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
        UIApplication* app=[DataManager Get:@"Application"];
        NSDictionary* launchOptions=GetArray(arr, 0);//[arr objectAtIndex:0];
        [[NEOnlineHelper Instance] application:app didFinishLaunchingWithOptions: launchOptions];
    }];
    [evt RegistEvent:AE_applicationWillEnterForeground Fun:^(NSArray* arr){
        UIApplication* app=[DataManager Get:@"Application"];
        [[NEOnlineHelper Instance] applicationWillEnterForeground:app];
    }];
    [evt RegistEvent:AE_applicationDidEnterBackground Fun:^(NSArray* arr){
        UIApplication* app=[DataManager Get:@"Application"];
        
        [[NEOnlineHelper Instance] applicationDidEnterBackground:app ];
    }];
    [evt RegistEvent:AE_handleOpenURL Fun:^(NSArray* arr){
        UIApplication* app=[DataManager Get:@"Application"];
        NSURL* url=GetArray(arr, 0);//[arr objectAtIndex:0];
        [[NEOnlineHelper Instance] application:app handleOpenURL: url];
    }];

    [evt RegistEvent:AE_openURL2 Fun:^(NSArray* arr){
        UIApplication* app=(UIApplication*)[DataManager Get:@"Application"];
        NSURL* url=GetArray(arr, 0);//[arr objectAtIndex:0];
        NSDictionary<NSString*,id> *options = GetArray(arr, 1);//[arr objectAtIndex:1];
        NSString* sourceApplication = options[UIApplicationOpenURLOptionsSourceApplicationKey];
        id annotation = options[UIApplicationOpenURLOptionsAnnotationKey];
        [[NEOnlineHelper Instance] application:app openURL: url sourceApplication:sourceApplication annotation:annotation];
    }];
	
    [evt RegistEvent:AE_openURL3 Fun:^(NSArray* arr){
        UIApplication* app=(UIApplication*)[DataManager Get:@"Application"];
        NSURL* url=GetArray(arr, 0);//[arr objectAtIndex:0];
        NSString* sourceApplication=GetArray(arr, 1);//[arr objectAtIndex:1];
        id annotation=GetArray(arr, 2);//[arr objectAtIndex:2];
        [[NEOnlineHelper Instance] application:app openURL: url sourceApplication:sourceApplication annotation:annotation];
    }];
    [evt RegistEvent:AE_willTerminate Fun:^(NSArray* arr){
            UIApplication* app=(UIApplication*)[DataManager Get:@"Application"];
           [[NEOnlineHelper Instance] applicationWillTerminate:app];
       }];
}


@end
//void CreateListner(EventManager* evt)
//{
//
////    [evt RegistEvent:AE_didFinishLaunchingWithOptions Fun:[[NPLaunch alloc] init]];
////    [evt RegistEvent:AE_applicationWillEnterBackground Fun:[[NPWillEnterBackground alloc] init]];
////     [evt RegistEvent:AE_applicationDidEnterBackground Fun:[[NPDidEnterBackground alloc]init]];
////    [evt RegistEvent:AE_handleOpenURL Fun:[[NPHandUrl alloc] init]];
////    [evt RegistEvent:AE_openURL3 Fun:[[NPHandUrl3 alloc]init]];
//}
