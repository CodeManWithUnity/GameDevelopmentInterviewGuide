#import "SDKBase.h"
#import <Foundation/Foundation.h>
#import "SDKData.h"
@implementation  SDKBase

 -(id) init
 {
     if( (self = [super init]) )
     {
     dic = [[NSMutableDictionary alloc] init];
     }
     return self;
 }

-(void) Regist:(NSString*)request Fun:(on_sdk_event)fun
{
	[dic setObject:fun forKey:request];
	
}

-(void) Post:(int)task_id Request:(NSString*)request Param:(NSDictionary*)param ;
{
    [SDKData AddData:param];
	on_sdk_event e=(on_sdk_event)[dic objectForKey:request];
    NSLog(@"Request=%@,task=%d,dic=%@",request,task_id,dic);
      if(e!=nil)
	  {
		e(task_id,param);
	  }
       
}
-(void)InitEvent
{
    
}
@end

