

#ifndef XDUnityInteraction_h
#define XDUnityInteraction_h
#import <Foundation/Foundation.h>
#include "EventManager.h"
#include "XDUnityHandle.h"


@interface XDUnityInteraction: NSObject

+(void)SetRegisted:(NSString*) reciever Value:(bool) b;
+(void)ProcessRequest:(NSDictionary*)dic Reciever:(NSString*)reciever Task:(int) task_id;
//+(void)AutoRegist:(EventManager*) evt;
+(void)Regist:(NSString*) reciever Handle:(XDUnityHandle*) handler;
@end
#endif
