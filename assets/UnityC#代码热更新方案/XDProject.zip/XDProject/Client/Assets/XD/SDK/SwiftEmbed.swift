//
//  SwiftEmbed.swift
//  Unity-iPhone
//
//  Created by tatsuya.pan on 2021/1/26.
//
//  Create an empty swift file for embedding swift runtime

import Foundation