//
//  CollectionTool.h
//  Unity-iPhone
//
//  Created by nesh on 2020/1/21.
//

#ifndef CollectionTool_h
#define CollectionTool_h

static id GetArray(NSArray* arr,int index)
{
    if(arr==nil)
    {
        return nil;
    }
    if(index<0||index>=[arr count])
    {
        return nil;
    }
    return [arr objectAtIndex:index];
}


#endif /* CollectionTool_h */
