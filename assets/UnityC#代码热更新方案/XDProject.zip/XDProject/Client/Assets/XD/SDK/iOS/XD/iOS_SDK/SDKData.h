#ifndef SDKData_h
#define SDKData_h


@interface SDKData :NSObject
+(void) initialize;
+(void)Set:(NSString*) key Value:(NSObject*) value;
+(id)Get:(NSString*) key;
+(void) AddData:(NSDictionary*)dic;

@end





#endif
