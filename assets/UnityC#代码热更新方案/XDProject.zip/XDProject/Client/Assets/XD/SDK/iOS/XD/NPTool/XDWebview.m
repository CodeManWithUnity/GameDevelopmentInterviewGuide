

#include "CollectionTool.h"
#include "XDAppListener.h"
#include "XDUnityHandle.h"
#include "URLScheme.h"
#include "XDWebview.h"
#include "XDUnityHandleError.h"

#import <NPTools/NPToolsHelper.h>
@implementation XDWebview

-(NSString*) GetReciever
{
    return @"Webview";
}
int curr_task_id;
-(void)ProcessRequest:(NSDictionary*) dic Task:(int)task_id
{
	NSString* url=[dic objectForKey:@"url"];
	NSString* nav_color=[dic objectForKey:@"nav_color"];
	// You can adopt our default UI style by simply setting url and rotateEnable.
	

	NSNumber*  back_enable=[dic objectForKey:@"back_enable"];
	NSNumber*  title_enable=[dic objectForKey:@"title_enable"];
	NSNumber*  orientation=[dic objectForKey:@"orientation"];
	NSNumber*  rotate_enable=[dic objectForKey:@"rotate_enable"];
	NSString* linkstyle=[dic objectForKey:@"linkstyle"];
	// You can also adopt a self-defined UI style by setting properties of NPToolsHelper instance before showing the target url.
	NPWebviewHelper *wvHelper = [NPWebviewHelper Instance];
	wvHelper.ScreenOrientation = [orientation intValue] ;
	wvHelper.TitleEnable = [title_enable intValue]==1;
	wvHelper.BackEnable = [back_enable intValue]==1;
	//wvHelper.LinkStyle = [linkstyle isEqualToString:@"OUT"]?1:0;
	wvHelper.NavigationColor = nav_color;
	 
	[wvHelper show:url withRotateEnable:[rotate_enable intValue]==1];
	NSMutableDictionary* map = [NSMutableDictionary dictionary];
	[map setObject:@"success" forKey:@"result"];
   
    [self SendToUnity :map Task:task_id];
}

-(void)Regist:(EventManager*) evt
{
	
}
@end
