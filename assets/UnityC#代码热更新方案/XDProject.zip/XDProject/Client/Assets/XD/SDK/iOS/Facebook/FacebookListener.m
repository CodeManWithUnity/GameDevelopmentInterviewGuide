#include "DataManager.h"
#include "EventManager.h"
#include "XDAppListener.h"
#include "CollectionTool.h"
#import "UnityAppController.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>



@interface FacebookListener : XDAppListener

@end
@implementation FacebookListener

-(void)Regist:(EventManager *)evt
{
    [evt RegistEvent:AE_didFinishLaunchingWithOptions Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
        UIApplication* app=[DataManager Get:@"Application"];
      NSDictionary * launchOptions=GetArray(arr, 0);//[arr objectAtIndex:0];
      
       [[FBSDKApplicationDelegate sharedInstance] application:app
    didFinishLaunchingWithOptions:launchOptions];
    }];
 [evt RegistEvent:AE_openURL2 Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
         UIApplication* app=[DataManager Get:@"Application"];
         NSURL *url =GetArray(arr, 0);
         NSDictionary<UIApplicationOpenURLOptionsKey,id> *options=GetArray(arr, 1);
       BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:app
        openURL:url
            sourceApplication:options[UIApplicationOpenURLOptionsSourceApplicationKey]
            annotation:options[UIApplicationOpenURLOptionsAnnotationKey]
            ];
    }];

        

}


@end
