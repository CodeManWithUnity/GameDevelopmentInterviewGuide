//
//  PlatformPlugin.m
//  Unity-iPhone
//
//  Created by aaa on 16/1/8.
//
//

#import <Foundation/Foundation.h>
#import "DataManager.h"

@implementation DataManager


static NSMutableDictionary* dic_data;
+(void) initialize {  
   dic_data= [[NSMutableDictionary alloc] init];
}
+(void)Set:(NSString*) key Value:(NSObject*) value
{
  [dic_data setObject:value forKey:key];
}
+(id)Get:(NSString*) key
{
	return [dic_data objectForKey:key];
}

@end
