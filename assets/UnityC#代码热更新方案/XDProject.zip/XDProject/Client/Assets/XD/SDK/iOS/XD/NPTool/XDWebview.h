#ifndef XDWEBVIEW_h
#define XDWEBVIEW_h

#include "XDUnityHandle.h"


@interface XDWebview:XDUnityHandle

@end
#endif
