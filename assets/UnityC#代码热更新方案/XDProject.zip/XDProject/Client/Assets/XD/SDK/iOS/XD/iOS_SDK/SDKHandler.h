#ifndef SDKHandler_h
#define SDKHandler_h

#include "XDUnityHandle.h"
#include "SDKBase.h"

static  NSString* SDKRequest_Init=@"Init";
static  NSString* SDKRequest_CreateProduct=@"CreateProduct";
static  NSString* SDKRequest_Purchase=@"Purchase";
static  NSString* SDKRequest_MoreGame=@"MoreGame";
static  NSString* SDKRequest_Exit=@"Exit";
static  NSString* SDKRequest_Quit=@"Quit";
static  NSString* SDKRequest_Logout=@"Logout";
static  NSString* SDKRequest_Login=@"Login";
static  NSString* SDKRequest_UserCenter=@"UserCenter";
static  NSString* SDKRequest_Event=@"Event";
//static  NSString* SDKRequest_Features=@"Features";
static  NSString* SDKRequest_RoleData=@"RoleData";


static  NSString* SDKResponse_Init=@"Init";
static  NSString* SDKResponse_Login=@"Login";
static  NSString* SDKResponse_SwitchAccount=@"SwitchAccount";
static  NSString* SDKResponse_CreateProduct=@"CreateProduct";
static  NSString* SDKResponse_Purchase=@"Purchase";
static NSString* SDKResponse_Logout=@"Logout";
static NSString* SDKResponse_Exit=@"Exit";
static  NSString* SDKResponse_Event=@"Event";
//static  NSString* SDKResponse_Features=@"Features";


static  NSString* SDKResult_Success=@"Success";
static  NSString* SDKResult_Fail=@"Fail";
static  NSString* SDKResult_Error=@"Error";
static  NSString* SDKResult_Cancel=@"Cancel";



@interface SDKHandler:XDUnityHandle
+(instancetype) instance;
-(void) SendSDKEvent:(int) task_id Response:(NSString*)evt SDK:(SDKBase*) sdk Result:(NSString*) res Msg:(NSString*)message Param:(NSDictionary*) param ;
@end
#endif
