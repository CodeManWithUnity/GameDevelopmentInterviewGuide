//
//  XDBoot.h
//  Unity-iPhone
//
//  Created by aaa on 2020/7/16.
//

#ifndef XDBoot_h
#define XDBoot_h
#include "EventManager.h"
#include "DataManager.h"
#include "XDAppListener.h"
#import "UnityAppController.h"
#include "SDKBase.h"
#include "XDUnityHandle.h"
#include "XDUnityInteraction.h"
static NSMutableArray* CreateListeners(NSArray* classes,EventManager* evt)
{
       
    NSMutableArray* array=[[NSMutableArray alloc] initWithCapacity:classes.count];
    
        for(int i=0;i<classes.count;++i)
        {
            NSString* class_name=[classes objectAtIndex:i];
            Class c=NSClassFromString(class_name);
            XDAppListener* l=[[c alloc] init] ;
            [l Regist:evt];
            [array addObject:l];
        }
    return array;
}
static NSMutableArray* CreateSDKS(NSArray* classes)
{
       
    NSMutableArray* array=[[NSMutableArray alloc] initWithCapacity:classes.count];
    
        for(int i=0;i<classes.count;++i)
        {
            NSString* class_name=[classes objectAtIndex:i];
            Class c=NSClassFromString(class_name);
            SDKBase* l=[[c alloc] init] ;
            [l InitEvent];
            [array addObject:l];
        }
    [DataManager Set:@"xd_sdk" Value:array];
    return array;
}
static NSMutableArray* CreateHandles(NSArray* classes,EventManager* evt)
{
       
    NSMutableArray* array=[[NSMutableArray alloc] initWithCapacity:classes.count];
    
        for(int i=0;i<classes.count;++i)
        {
            NSString* class_name=[classes objectAtIndex:i];
            Class c=NSClassFromString(class_name);
            XDUnityHandle* l=[[c alloc] init] ;
            [l Regist:evt];
            [XDUnityInteraction Regist:[l GetReciever] Handle:l];
            [array addObject:l];
        }
    return array;
}
static void XDBoot(UnityAppController* app)
{
    EventManager* evt=[[EventManager alloc] init];
    [DataManager Set:@"Event" Value:evt];
    EventManager* evt_app=[[EventManager alloc] init];
    [DataManager Set:@"EventApp" Value:evt_app];
    [DataManager Set:@"Application" Value:app];
  
//    NSString* filePath=[[NSBundle mainBundle]pathForResource:@"XDBoot" ofType:@"plist"];
//    NSMutableDictionary* data=[[NSMutableDictionary alloc]initWithContentsOfFile:filePath];
    NSDictionary* data=[[NSBundle mainBundle] infoDictionary];
    NSArray* data_listenter=[data objectForKey:@"xd_app_listeners"];
    NSArray* data_sdk=[data objectForKey:@"xd_app_sdks"];
    NSArray* data_handlers=[data objectForKey:@"xd_app_handles"];
    CreateListeners(data_listenter,evt_app);
    CreateSDKS(data_sdk);
    CreateHandles(data_handlers, evt_app);
}

#endif /* XDBoot_h */
