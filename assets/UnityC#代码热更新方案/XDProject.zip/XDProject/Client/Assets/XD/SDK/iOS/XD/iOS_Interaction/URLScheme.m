

#include "CollectionTool.h"
#include "XDAppListener.h"
#include "XDUnityHandle.h"
#include "URLScheme.h"
@implementation URLScheme

-(NSString*) GetReciever
{
    return @"URLScheme";
}
-(void)ProcessRequest:(NSDictionary*) json Task:(int)task_id
{
}

-(void)Regist:(EventManager*) evt
{
	[evt RegistEvent:AE_openURL Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
        NSURL* url=GetArray(arr,0);
        [self RecieveURL:url];
    }];
	[evt RegistEvent:AE_openURL2 Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
          NSURL* url=GetArray(arr,0);
       [self RecieveURL:url];
    }];
	[evt RegistEvent:AE_openURL3 Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
          NSURL* url=GetArray(arr,0);
      
       [self RecieveURL:url];
    }];
	[evt RegistEvent:AE_handleOpenURL Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
          NSURL* url=GetArray(arr,0);
       [self RecieveURL:url];
    }];
}


-(void) RecieveURL:(NSURL *)url
{
   
    NSLog(@"Scheme=%@,host=%@,port=%@,path=%@,query=%@",[url scheme],[url host],[url port],[url path],[url query]);
    NSArray *pairs = [[url query] componentsSeparatedByString:@"&"];
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    
	 [params setObject:[url scheme] forKey:@"scheme"];
    [params setObject:[url host] forKey:@"host"];
	if([url port]!=nil)
	 [params setObject:[url port] forKey:@"port"];
    [params setObject:[url path] forKey:@"path"];
    for (NSString *pair in pairs) {
        NSArray *kv = [pair componentsSeparatedByString:@"="];
        if (kv.count == 2) {
            NSString *val =[[kv objectAtIndex:1]  stringByRemovingPercentEncoding];
            [params setObject:val forKey:[kv objectAtIndex:0]];
        }
    }
  
   [self SendToUnity:params  Task:-1];

    
}
@end
