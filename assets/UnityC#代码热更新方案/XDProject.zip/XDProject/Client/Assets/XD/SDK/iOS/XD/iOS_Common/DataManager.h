
#ifndef DataManager_h
#define DataManager_h
#import <Foundation/Foundation.h>


@interface DataManager: NSObject



+(void) initialize;
+(void)Set:(NSString*) key Value:(NSObject*) value;
+(id)Get:(NSString*) key;

@end
#endif
