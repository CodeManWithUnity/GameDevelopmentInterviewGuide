#import <UIKit/UIKit.h>

#import "UnityAppController.h"

#include "PluginBase/AppDelegateListener.h"


#include "DataManager.h"
#include "EventManager.h"
#include "XDAppListener.h"
#include "XDBoot.h"


@interface XDAppController : UnityAppController

@property	EventManager* evt_app;

- (void)shouldAttachRenderDelegate;
@end

@implementation XDAppController





- (id)init
{
	if( (self = [super init]) )
	{		
        XDBoot(self);
        self.evt_app=[DataManager Get:@"EventApp"];
	}
	return self;
}

- (void)shouldAttachRenderDelegate
{
    [super shouldAttachRenderDelegate];
 //   [pc shouldAttachRenderDelegate];
   
	[self.evt_app CallEvent:AE_shouldAttachRenderDelegate Params:nil];
}


//#if !UNITY_TVOS
//- (void)application:(UIApplication*)application didReceiveLocalNotification:(UILocalNotification*)notification
//{
//    [super application:application didReceiveLocalNotification:notification];
//
//    [pc application:application didReceiveLocalNotification:notification];
//}
//#endif
//
//- (void)application:(UIApplication*)application didReceiveRemoteNotification:(NSDictionary*)userInfo
//{
//    [super application:application didReceiveRemoteNotification:userInfo];
//    [pc application:application didReceiveRemoteNotification:userInfo];
//}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
	[super application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
//    [pc application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
	[self.evt_app CallEvent:AE_didRegisterForRemoteNotificationsWithDeviceToken Params:[NSArray arrayWithObjects: deviceToken,nil]];
}


- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	[super application:application didFailToRegisterForRemoteNotificationsWithError:error];
   // [pc application:application didFailToRegisterForRemoteNotificationsWithError:error];
	[self.evt_app CallEvent:AE_didFailToRegisterForRemoteNotificationsWithError Params:[NSArray arrayWithObjects:error,nil]];
}

//- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation
//{
//    BOOL s=[super application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
//    BOOL isRun=[pc application:application openURL:url sourceApplication:sourceApplication annotation:annotation];
//    if(isRun)
//    {
//        return YES;
//    }
//
//    return s;
//}

- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url options:(NSDictionary<NSString*,id>*)options
{
//	BOOL s=[super application:application openURL:url options:options];
    NSLog(@"OpenURL:%@",url );
	[self.evt_app CallEvent:AE_openURL2 Params:[NSArray arrayWithObjects:url,options,nil]];
    return YES;
}


- (BOOL)application:(UIApplication*)application openURL:(NSURL*)url sourceApplication:(NSString*)sourceApplication annotation:(id)annotation
{
//	BOOL s=[super application:application openURL:url options:options];
    NSLog(@"OpenURL:%@",url );
	[self.evt_app CallEvent:AE_openURL3 Params:[NSArray arrayWithObjects:url,sourceApplication,annotation,nil]];
    return YES;
}
- (BOOL)application:(UIApplication*)application handleOpenURL:(NSURL*)url 
{
//	BOOL s=[super application:application openURL:url options:options];
    NSLog(@"OpenURL:%@",url );
	[self.evt_app CallEvent:AE_handleOpenURL Params:[NSArray arrayWithObjects:url,nil]];
    return YES;
}

//- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
//{
//    BOOL s=[super application:application handleOpenURL:url];
//    [pc application:application handleOpenURL:url];
//    return YES;
//}
//
//- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray * __nullable restorableObjects))restorationHandler NS_AVAILABLE_IOS(8_0)
//{
////    BOOL s=[super application:application continueUserActivity:userActivity restorationHandler:restorationHandler ];
////    [pc application:application handleOpenURL:userActivity.webpageURL];
//	[self.evt_app CallEvent:AE_continueUserActivity Params:[NSArray arrayWithObjects:userActivity,restorationHandler,nil]];
//    return YES;
//}
-(BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler
{
    [self.evt_app CallEvent:AE_continueUserActivity Params:[NSArray arrayWithObjects:userActivity,restorationHandler,nil]];
    return YES;
}


- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions
{
    BOOL s=[super application:application didFinishLaunchingWithOptions:launchOptions];
 //   [pc application:application didFinishLaunchingWithOptions:launchOptions];
    NSArray* array=[NSArray arrayWithObjects:launchOptions,nil];
    NSLog(@"Test array=%@,params=%@",array,launchOptions);
	[self.evt_app CallEvent:AE_didFinishLaunchingWithOptions Params:[NSArray arrayWithObjects:launchOptions,nil]];
	return s;
}


- (void)applicationWillEnterForeground:(UIApplication*)application
{
	[super applicationWillEnterForeground:application];
//	 [pc applicationWillEnterForeground:application];
	 [self.evt_app CallEvent:AE_applicationWillEnterForeground Params:nil];
}
- (void)applicationDidEnterForeground:(UIApplication*)application
{
	[super applicationWillEnterForeground:application];
//	 [pc applicationWillEnterForeground:application];
	 [self.evt_app CallEvent:AE_applicationDidEnterForeground Params:nil];
}
- (void)applicationWillEnterBackground:(UIApplication*)application
{
	[super applicationWillEnterForeground:application];
//	 [pc applicationWillEnterForeground:application];
	 [self.evt_app CallEvent:AE_applicationWillEnterBackground Params:nil];
}

- (void)applicationDidEnterBackground:(UIApplication*)application
{
	[super applicationWillEnterForeground:application];
//	 [pc applicationWillEnterForeground:application];
	 [self.evt_app CallEvent:AE_applicationDidEnterBackground Params:nil];
}

- (void)didReceiveRemoteNotification:(NSNotification*)notification {
    [self.evt_app CallEvent:AE_didReceiveRemoteNotification Params:[NSArray arrayWithObjects:notification,nil]];
}

// LifeCycleListener protocol

- (void)didFinishLaunching:(NSNotification*)notification {
    [self.evt_app CallEvent:AE_didFinishLaunching Params:[NSArray arrayWithObjects:notification,nil]];
}

-(void)didBecomeActive:(NSNotification*)notification {
  [self.evt_app CallEvent:AE_didBecomeActive Params:[NSArray arrayWithObjects:notification,nil]];

}

- (void)willResignActive:(NSNotification*)notification {
     [self.evt_app CallEvent:AE_willResignActive Params:[NSArray arrayWithObjects:notification,nil]];

}

- (void)didEnterBackground:(NSNotification*)notification {
    [self.evt_app CallEvent:AE_didEnterBackground Params:[NSArray arrayWithObjects:notification,nil]];

}

- (void)willEnterForeground:(NSNotification*)notification {
   [self.evt_app CallEvent:AE_willEnterForeground Params:[NSArray arrayWithObjects:notification,nil]];

    
}

- (void)willTerminate:(NSNotification*)notification {
   [self.evt_app CallEvent:AE_willTerminate Params:[NSArray arrayWithObjects:notification,nil]];

   
}



@end

IMPL_APP_CONTROLLER_SUBCLASS(XDAppController)
