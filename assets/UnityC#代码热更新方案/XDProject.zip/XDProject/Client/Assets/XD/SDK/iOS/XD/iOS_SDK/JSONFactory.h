#ifndef JSONFactory_h
#define JSONFactory_h
#include "SDKData.h"
#include "DataManager.h"
static const NSString* Result_Code=@"Result_Code";
static const NSString* Message=@"Message";
static const NSString* Param=@"Param";
static const NSString* Login_Type=@"Login_Type";
static const NSString* Login_Token=@"Login_Token";
static const NSString* User_Name=@"User_Name";
static const NSString* Purchase_Receipt=@"Purchase_Receipt";
static const NSString* Purchase_Type=@"Purchase_Type";
static const NSString* Purchase_Str=@"Purchase_Str";
static const NSString* Purchase_EX=@"Purchase_EX";
static const NSString* Event_ID=@"Event_ID";
static const NSString* Event_Type=@"Event_Type";
static const NSString* Event_EX=@"Event_EX";

	 static const int RES_CODE_NO_ERROR=1;
	 static const int RES_CODE_INIT_ERROR=2;
	
	 static const int RES_CODE_LOGIN_ERROR=3;
	 static const int RES_CODE_LOGIN_CANEL=4;
	
	 static const int RES_CODE_PAY_ERROR=4;
	 static const int RES_CODE_PAY_CANEL=5;

NSDictionary* GetConfig(SDKBase* sdk) {
    NSString* cn=[NSString stringWithFormat:@"%@_config",NSStringFromClass([sdk class])];
    return [SDKData Get:cn];
}


NSDictionary* GetMap(SDKBase* sdk, NSString* map_name) {
    NSDictionary* config = GetConfig(sdk);
    NSDictionary* map = [config  objectForKey:map_name];
    
    NSMutableDictionary* new_map = [NSMutableDictionary dictionary];
    
    NSArray *keys= [map allKeys];
    
    for (int i = 0; i < [keys count]; i++)
    {
        id key = [keys objectAtIndex: i];
        id value = [map objectForKey: key];
        NSLog (@"Key: %@ for value: %@",key, value);
        
        if ([value hasPrefix:@"${"] && [value hasSuffix:@"}"]) {
            id new_value=[SDKData Get:value ];
            if(new_value!=nil)[new_map setObject:new_value forKey:key];
            
        } else if ([value hasPrefix:@"#{"] && [value hasSuffix:@"}"]) {
            id new_value = [config  objectForKey: [value substringWithRange:NSMakeRange(2,[value length]- 3)]];
             if(new_value!=nil)[new_map setObject:new_value forKey:key];
        }
        else
        {
            [new_map setObject:value forKey:key];
        }
    }
    //        Map map_value=DataManager.Get("map_value");
    
    return new_map;
}
void CombineMap(NSDictionary* source,NSMutableDictionary* target ) {
    NSArray *keys= [source allKeys];
    
    for (int i = 0; i < [keys count]; i++)
    {
        id key = [keys objectAtIndex: i];
        id value = [source objectForKey: key];
        [target setObject:value forKey:key];
    }
}
//public  static  void ReplaceMap(Map config,Map target ) {
//    Map<String, Object> t= target;
//    //        Map map_value=DataManager.Get("map_value");
//    for (Map.Entry<String, Object> e : t.entrySet()) {
//        if (e.getValue() instanceof String) {
//            String value = (String) e.getValue();
//            if (value.startsWith("${") && value.endsWith("}")) {
//                //                    Object new_value = sdk.ParseValue(value);
//                Object new_value=DataManager.Get(value);
//                target.put(e.getKey(), new_value);
//            } else if (value.startsWith("#{") && value.endsWith("}")) {
//                Object new_value = config.get(value.substring(2, value.length() - 1));
//                target.put(e.getKey(), new_value);
//            }
//        }
//    }
//}
NSDictionary* GetMapLogin(SDKBase* sdk) {
    return GetMap(sdk, @"login_map");
}

NSDictionary* GetMapPurchase(SDKBase* sdk) {
    return GetMap(sdk, @"purchase_map");
}

//    
//    NSMutableDictionary* InitSucess(NSString* msg)
//    {
//        NSMutableDictionary* map = [NSMutableDictionary dictionary];
//        [map setObject:[NSNumber numberWithInt:RES_CODE_NO_ERROR] forKey:Result_Code];
//        [map setObject:msg forKey: Message];
//        return map;
//    }
//    
//    NSMutableDictionary* InitFail(NSString* msg)
//    {
//        NSMutableDictionary* map = [NSMutableDictionary dictionary];
//        [map setObject:[NSNumber numberWithInt:RES_CODE_INIT_ERROR] forKey:Result_Code];
//        [map setObject:msg forKey: Message];
//        return map;
//    }
	
	NSMutableDictionary* LoginToken(SDKBase* sdk)
	{
		NSMutableDictionary* map = [NSMutableDictionary dictionary];
		[map setObject:[NSNumber numberWithInt:RES_CODE_NO_ERROR] forKey:Result_Code];
        [map setObject:GetMapLogin(sdk) forKey:Param];

		return map;
	}

	

//    NSMutableDictionary* Logout(int error ,NSString* msg)
//    {
//        NSMutableDictionary* map = [NSMutableDictionary dictionary];
//        [map setObject:[NSNumber numberWithInt:error] forKey:Result_Code];
//        [map setObject:msg forKey:Message];
//
//        return map;
//    }

	
	NSMutableDictionary* PaySucess(SDKBase* sdk)
	{
		NSMutableDictionary* map = [NSMutableDictionary dictionary];
		[map setObject:[NSNumber numberWithInt:RES_CODE_NO_ERROR] forKey:Result_Code];
	   [map setObject:GetMapPurchase(sdk) forKey:Param];

		return map;
	}
	
	NSMutableDictionary* MessageResult(int error ,NSString* msg)
	{
		NSMutableDictionary* map = [NSMutableDictionary dictionary];
		[map setObject:[NSNumber numberWithInt:error] forKey:Result_Code];
		[map setObject:msg forKey:Message];

		return map;
	}
#endif
