//
//  PlatformPlugin.m
//  Unity-iPhone
//
//  Created by aaa on 16/1/8.
//
//

#import <Foundation/Foundation.h>
#import "EventManager.h"
#import "DataManager.h"
@implementation EventManager

 -(id) init
 {
     if( (self = [super init]) )
     {
     dic = [[NSMutableDictionary alloc] init];
     }
     return self;
 }

- (NSMutableArray*) GetFunList:(NSString*)t
{
    NSMutableArray* array=(NSMutableArray*)[dic objectForKey:t];
  	if (array==nil)
            {
           array=[[NSMutableArray alloc]init];
               [dic setObject:array forKey:t];
            }
            return array;
        }
//   - (void) RegistEvent:(NSString*) evt  Fun:(id<OnEventDelegate>) fun
//   {
//       NSMutableArray* list =[self GetFunList:evt];
//       if(![list containsObject:fun])
//       {
//                [list addObject:fun];
//       }
//   }
//- (void) RemoveEvent:(NSString*) evt  Fun:(id<OnEventDelegate>) fun
//   {
//       NSMutableArray* list = [self GetFunList:evt];
//       if([list containsObject:fun])
//                [list removeObject:fun];
//   }
- (void) RegistEvent:(NSString*) evt  Fun:(on_event) fun
{
    NSMutableArray* list =[self GetFunList:evt];
    if(![list containsObject:fun])
    {
        [list addObject:fun];
    }
}
- (void) RemoveEvent:(NSString*) evt  Fun:(on_event) fun
{
    NSMutableArray* list = [self GetFunList:evt];
    if([list containsObject:fun])
        [list removeObject:fun];
}
- (void) CallEvent:(NSString* )evt Params: (NSArray*) params
   {
     NSMutableArray* list = [self GetFunList:evt];
//      for(id<OnEventDelegate> e in list)
//        {
//         [e Fun:params];
//        }
       for(on_event e in list)
       {
           e(params);
       }
   }

@end
