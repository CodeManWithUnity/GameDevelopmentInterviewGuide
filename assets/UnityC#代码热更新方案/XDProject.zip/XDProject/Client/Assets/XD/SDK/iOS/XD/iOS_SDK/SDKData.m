//
//  SDKData.m
//  Unity-iPhone
//
//  Created by nesh on 2020/3/2.
//
#include "SDKData.h"
#import <Foundation/Foundation.h>
@implementation SDKData
static NSMutableDictionary* dic_sdk;
+(void) initialize {
    dic_sdk= [[NSMutableDictionary alloc] init];
}
+(void)Set:(NSString*) key Value:(NSObject*) value
{
    [dic_sdk setObject:value forKey:key];
}
+(id)Get:(NSString*) key
{
    return [dic_sdk objectForKey:key];
}
+(void)AddData:(NSDictionary *)dic
{
    NSLog(@"Add Data=%@",dic);
    if(dic!=nil&&![dic isEqual:[NSNull null]]&&dic.count>0){
        for(NSString* key in dic)
        {
            id value=[dic objectForKey:key];
            [dic_sdk setObject:value forKey:key];
        }
    }
}
@end
