#ifndef XDAppListener_h
#define XDAppListener_h
#include "EventManager.h"
static NSString* AE_shouldAttachRenderDelegate=@"shouldAttachRenderDelegate";
static NSString* AE_didRegisterForRemoteNotificationsWithDeviceToken=@"didRegisterForRemoteNotificationsWithDeviceToken";
static NSString* AE_didFailToRegisterForRemoteNotificationsWithError=@"didFailToRegisterForRemoteNotificationsWithError";
static NSString* AE_openURL=@"openURL";
static NSString* AE_openURL2=@"openURL2";
static NSString* AE_openURL3=@"openURL3";
static NSString* AE_handleOpenURL=@"handleOpenURL";
static NSString* AE_continueUserActivity=@"continueUserActivity";
static NSString* AE_didFinishLaunchingWithOptions=@"didFinishLaunchingWithOptions";
static NSString* AE_applicationWillEnterForeground=@"applicationWillEnterForeground";
static NSString* AE_applicationDidEnterForeground=@"applicationDidEnterForeground";
static NSString* AE_applicationWillEnterBackground=@"applicationWillEnterBackground";
static NSString* AE_applicationDidEnterBackground=@"applicationDidEnterBackground";

static NSString* AE_didReceiveRemoteNotification=@"didReceiveRemoteNotification";
static NSString* AE_didFinishLaunching=@"didFinishLaunching";
static NSString* AE_didBecomeActive=@"didBecomeActive";
static NSString* AE_willResignActive=@"willResignActive";
static NSString* AE_didEnterBackground=@"didEnterBackground";
static NSString* AE_willEnterForeground=@"willEnterForeground";
static NSString* AE_willTerminate=@"willTerminate";

@interface XDAppListener:NSObject

-(void)Regist:(EventManager*) evt;
//+(void)SerachListners:(EventManager*) evt;
@end




#endif

