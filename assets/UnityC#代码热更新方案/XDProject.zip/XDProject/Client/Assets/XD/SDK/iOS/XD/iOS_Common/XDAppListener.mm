#include "XDAppListener.h"
#import <objc/runtime.h>


@implementation XDAppListener

static NSMutableArray *listeners;
-(void)Regist:(EventManager *)evt
{
    
}
//+(void)SerachListners:(EventManager*) evt Classes:(NSArray*)array
//{
//	  Class p=[XDAppListener class];
//    int numClasses=objc_getClassList(NULL,0 );
//    Class* classes=NULL;
//    classes=(Class*)malloc(sizeof(Class)*numClasses);
//    numClasses=objc_getClassList(classes, numClasses);
//    listeners=[[NSMutableArray alloc] initWithCapacity:5];
//
//    for(int i=0;i<numClasses;++i)
//    {
//        Class superClass=classes[i];
//        do{
//            superClass=class_getSuperclass(superClass);
//        }
//        while(superClass&&superClass!=p);
//        if(superClass==nil){continue;}
//         XDAppListener* l=[[classes[i] alloc] init] ;
//        [l CreateListner:evt];
//        [listeners addObject:l];
//    }
//    free(classes);
//}
@end
