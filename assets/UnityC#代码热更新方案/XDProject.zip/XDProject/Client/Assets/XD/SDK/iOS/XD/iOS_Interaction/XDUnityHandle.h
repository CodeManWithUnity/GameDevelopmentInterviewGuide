#ifndef XDUnityHandle_h
#define XDUnityHandle_h
#include "EventManager.h"


@interface XDUnityHandle:NSObject
@property bool registed;
@property bool in_task;
@property NSMutableArray *list_result;

-(void)Regist:(EventManager*) evt;
-(NSString*) GetReciever;
-(void)ProcessRequest:(NSDictionary*) json Task:(int)task_id;
-(void)SendToUnity:(NSDictionary*) dic Task:(int)task_id;
-(void) SetRegisted:(bool)b;
+(NSDictionary*)TransData: (NSDictionary*) dic Task:(int)task_id Reciever:(NSString*)reciever Error:(NSString*)error;
+(void)SendToUnityInter:(NSDictionary*) dic_all;
@end




#endif

