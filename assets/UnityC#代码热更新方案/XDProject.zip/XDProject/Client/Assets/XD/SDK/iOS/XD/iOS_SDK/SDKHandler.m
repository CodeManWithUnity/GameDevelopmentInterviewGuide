
#include "XDUnityHandle.h"
#include "SDKHandler.h"
#include "DataManager.h"

@implementation SDKHandler

static NSMutableArray *sdks;

static SDKHandler* _instance;
+(instancetype)instance
{
    return _instance;
}
-(id) init
{
    if( (self = [super init]) )
    {
        _instance=self;
    }
    return self;
}
	static SDKBase* GetSDK(NSDictionary* dic)
    {
        NSArray* sdks= [DataManager Get:@"xd_sdk"];
        NSNumber* p=[dic objectForKey:@"sdk"];
        int pi=[p intValue];
		
        NSLog(@"sdk count=%lu,p=%d",sdks.count,pi);
        if(pi<0)
        {
            return sdks[0];
        }
        return sdks[pi];
    }
-(NSString*) GetReciever
{
    return @"SDKHandler";
}
-(void)ProcessRequest:(NSDictionary*) dic Task:(int)task_id
{
	NSString* event_str=[dic objectForKey:@"event"];
	NSDictionary* param = [dic objectForKey:@"param"];;
    SDKBase* sdk=GetSDK(dic);
    [sdk Post:task_id Request:event_str Param:param];
}
-(void) SendSDKEvent:(int) task_id Response:(NSString*)evt SDK:(SDKBase*) sdk Result:(NSString*) res Msg:(NSString*)message Param:(NSDictionary*) param 
{
	NSMutableDictionary* map = [NSMutableDictionary dictionary];
	[map setObject:res forKey:@"SDK_Result"];
    [map setObject:message forKey:@"Message"];
	[map setObject:evt forKey:@"SDK_Event"];
    [map setObject:NSStringFromClass([sdk class]) forKey:@"SDK_Class"];
    if(param!=nil) {
		[map setObject:param forKey:@"SDK_Param"];
    }
    [self SendToUnity :map Task:task_id];
}


@end
