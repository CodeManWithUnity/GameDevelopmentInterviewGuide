#ifndef URLScheme_h
#define URLScheme_h

#include "XDUnityHandle.h"

@interface URLScheme:XDUnityHandle

@end
#endif
