

#include "CollectionTool.h"
#include "XDAppListener.h"
#include "XDUnityHandle.h"
#include "URLScheme.h"
#include "SKUQuery.h"
#include <StoreKit/StoreKit.h>
#include "XDUnityHandleError.h"
@implementation SKUQuery

-(NSString*) GetReciever
{
    return @"SKUQuery";
}
int curr_task_id;
-(void)ProcessRequest:(NSDictionary*) json Task:(int)task_id
{
	curr_task_id=task_id;
 	NSArray* produtIds = [json objectForKey:@"products"];;
  
    if([SKPaymentQueue canMakePayments])
    {
   NSLog(@"requestProductsData=%@",produtIds);
 
    NSLog(@"requestProductsData aArray=%@",produtIds );
   NSSet* productSet = [NSSet setWithArray:produtIds];
//     NSSet* productSet = [NSSet setWithObject:@"boltrend.flo.tc.ios.diamond5"];
      NSLog(@"requestProductsData productSet=%@",productSet );
   SKProductsRequest* req = [[SKProductsRequest alloc] initWithProductIdentifiers:productSet];
   req.delegate = self;
   [req start];
   NSLog(@"Products request start");
    }
}

-(void)Regist:(EventManager*) evt
{
	
}

-(void)productsRequest:(SKProductsRequest*)request didReceiveResponse:(SKProductsResponse*)response
{
   NSLog(@"Products request response");

   if(response == nil){
//       UnitySendMessage([self.gameObjectName UTF8String],[self.productsCallback UTF8String],[@"" UTF8String]);
       XDUnityHandleError([self GetReciever], curr_task_id, @"response error");
//       [self setupFailed:@"Products request response nil"];
       return;
   }

   for(NSString* identifier in response.invalidProductIdentifiers){
       NSLog(@"product %@ invalid", identifier);
   }


   if(response.products.count == 0){
//       UnitySendMessage([self.gameObjectName UTF8String],[self.productsCallback UTF8String],[@"" UTF8String]);
       XDUnityHandleError([self GetReciever], curr_task_id, @"No valid products");
//       [self setupFailed:@"No valid products"];
       return;
   }
   NSMutableDictionary * totalProducts = [[NSMutableDictionary alloc] init];
   int i = 0;
   for(SKProduct* p in response.products){
       i++;
     //  NSString* productID = p.productIdentifier;
//       NSString* name = p.localizedTitle;

       NSNumberFormatter* fmt = [[NSNumberFormatter alloc] init];
       [fmt setFormatterBehavior:NSNumberFormatterBehavior10_4];
       [fmt setNumberStyle:NSNumberFormatterCurrencyStyle];
       [fmt setLocale:p.priceLocale];
       NSString* price = [fmt stringFromNumber:p.price];
       double amount = [p.price doubleValue]*100;
       NSString *amountS = [NSString stringWithFormat:@"%f",amount];
       NSDecimalNumber *amountN = [NSDecimalNumber decimalNumberWithString:amountS];
//       NSString* currencyCode = [p.priceLocale objectForKey:NSLocaleCurrencyCode];

       NSMutableDictionary *dicItem = [[NSMutableDictionary alloc] init];
       [dicItem setValue:price forKey:@"price"];
       [dicItem setValue:[amountN stringValue]  forKey:@"price_amount_micros"];
       [dicItem setValue:p.productIdentifier forKey:@"productId"];
       [dicItem setValue:p.localizedTitle forKey:@"title"];
       [dicItem setValue:p.localizedDescription forKey:@"description"];
       [dicItem setValue:[p.priceLocale objectForKey:NSLocaleCurrencyCode] forKey:@"price_currency_code"];
       NSString* ps = [NSString stringWithFormat:@"product%d",i];
//       NSString* jsD = @"";
//       NSError *error = nil;
//       NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dicItem options:NSJSONWritingPrettyPrinted error:&error];
//       if(error){
//           NSLog(@"jsonData ->%@",error);
//       }else{
//           jsD = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
//           NSLog(@"jsD:%@",jsD);
//       }
       [totalProducts setValue:dicItem forKey:ps];
   }
  // NSError *error = nil;
 //  NSData *jsonData = [NSJSONSerialization dataWithJSONObject:totalProducts options:NSJSONWritingPrettyPrinted error:&error];
 //  if(error){
 //      NSLog(@"jsonData ->%@",error);
 //  }

//   NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
 //  NSLog(@"jsonstring ->%@",jsonString);
 //   UnitySendMessage([self.gameObjectName UTF8String],[self.productsCallback UTF8String],[jsonString UTF8String]);
	[self SendToUnity :totalProducts Task:curr_task_id];
}

-(void)request:(SKRequest *)request didFailWithError:(NSError *)error
{
   NSLog(@"request error:code=%ld description=%@", [error code], [error localizedDescription]);
   NSString *str = [NSString stringWithFormat:@"%@",[error localizedDescription]];
//    UnitySendMessage([self.gameObjectName UTF8String],[self.productsCallback UTF8String],[@"" UTF8String]);
//   [self setupFailed:str];
    XDUnityHandleError([self GetReciever], curr_task_id, str);
}

@end
