#include "SDKBase.h"

#include "UnitySDKListener.h"
#include "CollectionTool.h"
//#import <NPPlatform/NPSDKHelper.h>
#import <NPPlatform/BotrendPayInfoHelper.h>
#import <NPPlatform/NEOnlineHelper.h>
#include "SDKData.h"
#include "SDKHandler.h"
@interface NUSDK:SDKBase<NEOnlineLoginDelegate,NEOnlinePayResultDelegate>
@end

@implementation NUSDK
//-(void)LoginDelay
//{
//    NSDictionary* t=[NSDictionary dictionaryWithObjectsAndKeys:IKey_Login_Type, @1, nil];
//    [self Login:t];
//}
-(void)CheckInited:(int)task_id
{
   
    init_task_id=task_id;
    NSString* inited=[[NEOnlineHelper Instance] getData:@"isInited" :@""];
    if([inited isEqualToString:@"true"]||true)
//    if([NEOnlineHelper isInited])
    {
		[[SDKHandler instance] SendSDKEvent:task_id Response:SDKResponse_Init SDK:self Result:SDKResult_Success Msg:@"" Param: nil];
		
        //UnitySendInitOver(@"");
        // [self performSelector:@selector(LoginDelay) withObject:nil afterDelay:5];
    }
    else
    {
        NSLog(@"NPSDKHelper Not Inited");
      //  UnitySendInitOver(@"");
        [self performSelector:@selector(CheckInitedNext) withObject:nil afterDelay:5];
    }
}
int init_task_id;
-(void)CheckInitedNext
{
    [self CheckInited:init_task_id];
//    [[SDKHandler instance] SendSDKEvent:init_task_id Response:SDKResponse_Init SDK:self Result:SDKResult_Success Msg:@"" Param: nil];
}

//-(void)InitApp:(NSDictionary*)dic
//{
//    [self CheckInited];
// 
//}
//Login
-(void)onLoginSuccess:(NEOnlineUser *)user :(NSString *)remain
{
    if([remain isEqualToString:@"switch_account"])
    {
        [SDKData Set:@"${nu_user_id}" Value:user.channelUserId ];
                  [SDKData Set:@"${nu_token}" Value:user.token];
                 [SDKData Set:@"${nu_channel_id}" Value:user.channelId];
                 NSMutableDictionary* map = [NSMutableDictionary dictionary];
                 [map setObject:user.channelUserId forKey:@"nu_user_id"];
                 [map setObject:user.token forKey:@"nu_token"];
               [map setObject:user.channelId forKey:@"nu_channel_id"];
                 [[SDKHandler instance] SendSDKEvent:login_task_id Response:SDKResponse_SwitchAccount SDK:self Result:SDKResult_Success  Msg:@"" Param: map];
                 login_task_id=-1;
    }
    else if([remain isEqualToString:@"CustomerLogin"])
    {
        
    }
    else
    {
        
          [SDKData Set:@"${nu_user_id}" Value:user.channelUserId ];
           [SDKData Set:@"${nu_token}" Value:user.token];
          [SDKData Set:@"${nu_channel_id}" Value:user.channelId];
          NSMutableDictionary* map = [NSMutableDictionary dictionary];
          [map setObject:user.channelUserId forKey:@"nu_user_id"];
          [map setObject:user.token forKey:@"nu_token"];
        [map setObject:user.channelId forKey:@"nu_channel_id"];
          [[SDKHandler instance] SendSDKEvent:login_task_id Response:SDKResponse_Login SDK:self Result:SDKResult_Success  Msg:@"" Param: map];
          login_task_id=-1;
    }
}

-(void)onLoginFailed:(NSString *)reason :(NSString *)remain
{
    if([remain isEqualToString:@"closeLoginUI"])
    {
     [[SDKHandler instance] SendSDKEvent:login_task_id Response:SDKResponse_Login SDK:self Result:SDKResult_Cancel  Msg:reason Param:nil];
    }
    else{
         [[SDKHandler instance] SendSDKEvent:login_task_id Response:SDKResponse_Login SDK:self Result:SDKResult_Fail  Msg:reason Param:nil];
    }
}
-(void)onLogout:(NSString *)remain
{
     [[SDKHandler instance] SendSDKEvent:-1 Response:SDKResponse_Logout SDK:self Result:SDKResult_Success  Msg:remain Param:nil];
}

-(void)onSuccess:(NSString *)msg
{
    NSMutableDictionary* map = [NSMutableDictionary dictionary];
             [map setObject:tcd forKey:@"nu_tcd"];
     [[SDKHandler instance] SendSDKEvent:purchase_task_id Response:SDKResponse_Purchase SDK:self Result:SDKResult_Success  Msg:msg Param:map];
}
-(void)onFailed:(NSString *)msg
{
     [[SDKHandler instance] SendSDKEvent:purchase_task_id Response:SDKResponse_Purchase SDK:self Result:SDKResult_Fail  Msg:msg Param:nil];
}
NSString* tcd;
-(void) onOderNo:(NSString *)msg
{
    tcd=msg;
}
//Pay
int purchase_task_id;
	
	
//end
// -(void) Login:(NSDictionary*)dic
// {
	// int type=[dic objectForKey:IKey_Login_Type];
	// if(type==10)
	// {
		// [NPSDKHelper switchAccount];
	// }
	// else
	// {
		// [NPSDKHelper login:self];
	// }
// }
// -(void) ShowUserCenter
// {
	// [NPSDKHelper showUserCenter];
// }
// -(void) Logout:(NSDictionary*)dic
// {
// }
// -(NSString*) PurchasePre:(NSDictionary*)dic
// {
    // return @"";
// }
-(void) Purchase:(NSDictionary*)dic
{
	
	NSNumber* number =[dic objectForKey:IKey_Product_Price];
  
    [SDKData Set:@"${nu_purchase_id}" Value:[dic objectForKey:IKey_Purchase_ID]];
	
	NSString* productDesc =[dic objectForKey:IKey_Product_Description];
	
//    BotrendPayInfoHelper* payinfo=[BotrendPayInfoHelper instance];
//	payinfo.roleId=@"";
//	payinfo.roleName=@"";
//	payinfo.serverId=@"";
//    payinfo.serverName=@"";
//	payinfo.orderId=[dic objectForKey:IKey_Purchase_ID];
    NSString* productId=[dic objectForKey:IKey_Product_ID];
	NSString* productName=[dic objectForKey:IKey_Product_Name];
	NSString* currencyType=[dic objectForKey:IKey_Currency];
	int productPrice=[number intValue];
    NSNumber* count=[dic objectForKey:IKey_Purchase_Count];
	int productCount=[count intValue];
    NSString* callbackInfo=[dic objectForKey:IKey_Purchase_Info];
    NSString* callbackURL=[dic objectForKey:IKey_Purchase_URL];
//	payinfo.orderType=0;
//	[NPSDKHelper purchase: payinfo withCallback:self];
    [[NEOnlineHelper Instance]pay:productPrice :productName :productId :currencyType :productCount :callbackInfo :callbackURL :self ];

}
int login_task_id;
-(void)InitEvent
{
	 [[NEOnlineHelper Instance]setLoginListener:self];
	[self Regist:SDKRequest_Init Fun:^(int task_id,NSDictionary* param){
        init_task_id=task_id;
        [self CheckInited:task_id];
	}];
	[self Regist:SDKRequest_Login Fun:^(int task_id,NSDictionary* param){
		login_task_id=task_id;
		
        [[NEOnlineHelper Instance] login:@"login"];
//			[NPSDKHelper login:self];
		
	}];
	[self Regist:SDKRequest_CreateProduct Fun:^(int task_id,NSDictionary* param){
		NSString* item_id=[param objectForKey:@"Purchase_Item_ID"];
        NSLog(@"create production %@",item_id);
		  [SDKData Set:@"nu_purchase_item_id" Value:item_id];
		
          NSMutableDictionary* map = [NSMutableDictionary dictionary];
		[map setObject:item_id forKey:@"nu_purchase_item_id"];  
		 [[SDKHandler instance] SendSDKEvent:task_id Response:SDKResponse_CreateProduct  SDK:self Result:SDKResult_Success  Msg:@"" Param:map];
          
	}];
	[self Regist:SDKRequest_Purchase Fun:^(int task_id,NSDictionary* param){
		purchase_task_id=task_id;
		[self Purchase:param];
          
	}];
	[self Regist:SDKRequest_UserCenter Fun:^(int task_id,NSDictionary* param){
        [[NEOnlineHelper Instance] setData:@"userCenter" :@""];
          
	}];
    [self Regist:SDKResponse_Logout Fun:^(int task_id,NSDictionary* param){
          [[NEOnlineHelper Instance] logout:@"logout"];
          
    }];
    [self Regist:SDKRequest_RoleData Fun:^(int task_id,NSDictionary* param){
        
        NSString* role_id=[param objectForKey:@"Role_ID"];
        NSString* role_name=[param objectForKey:@"Role_Name"];
        NSString* role_level=[param objectForKey:@"Role_Level"];
        NSString* role_zone_id=[param objectForKey:@"Role_Zone_ID"];
        NSString* role_zone_name=[param objectForKey:@"Role_Zone_Name"];
        [[NEOnlineHelper Instance] setRoleData:role_id :role_name :role_level :role_zone_id :role_zone_name];
          
    }];
}




@end
