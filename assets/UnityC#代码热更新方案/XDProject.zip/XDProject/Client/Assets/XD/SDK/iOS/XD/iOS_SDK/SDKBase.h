
#ifndef SDKBase_h
#define SDKBase_h




static const NSString* IKey_Gameobject=@"Gameobject";
static const NSString* IKey_App_ID=@"App_ID";
static const NSString* IKey_App_Key=@"App_Key";
static const NSString* IKey_App_Name=@"App_Name";
static const NSString* IKey_App_Ex=@"App_Ex";
static const NSString* IKey_Login_Type=@"Login_Type";
static const NSString* IKey_Login_Notify=@"Login_Notify";
static const NSString* IKey_Purchase_ID=@"Purchase_ID";
static const NSString* IKey_Purchase_EX=@"Purchase_EX";
static const NSString* IKey_Purchase_Count=@"Purchase_Count";
static const NSString* IKey_Purchase_Amount=@"Purchase_Amount";
static const NSString* IKey_Purchase_URL=@"Purchase_URL";
static const NSString* IKey_Purchase_Info=@"Purchase_Info";
static const NSString* IKey_Pay_Type=@"Pay_Type";
static const NSString* IKey_Currency=@"Currency";
//static const NSString* IKey_Pay_Notify=@"Pay_Notify";
static const NSString* IKey_Product_ID=@"Product_ID";
static const NSString* IKey_Product_Price=@"Product_Price";
static const NSString* IKey_Product_Name=@"Product_Name";
static const NSString* IKey_Product_Description=@"Product_Description";
static const NSString* IKey_User_ID=@"User_ID";
static const NSString* IKey_User_Name=@"User_Name";
static const NSString* IKey_User_EX=@"User_EX";
static const NSString* IKey_Event_ID=@"Event_ID";
static const NSString* IKey_Event_Type=@"Event_Type";
static const NSString* IKey_Event_EX=@"Event_EX";
static const NSString* IKey_Server_ID=@"Server_ID";
static const NSString* IKey_User_Config=@"User_Config";
static const NSString* IKey_Release=@"Release";
static const NSString* IKey_App_Agent = @"Channelid";
static const NSString* IKey_Platform_Configs = @"Platform_Configs";
static const NSString* IKey_Platform= @"Platform";

static const NSString* OKey_AcountType=@"AcountType";
static const NSString* OKey_NickName=@"NickName";
static const NSString* OKey_MoreGame=@"MoreGame";
static const NSString* OKey_BackToExit=@"BackToExit";
static const NSString* OKey_BackToLogout=@"BackToLogout";
static const NSString* OKey_Exit=@"Exit";
static const NSString* OKey_MusicEnable=@"MusicEnable";
static const NSString* OKey_Pay_Lock=@"Pay_Lock";
static const NSString* OKey_Pay_Str=@"Pay_Str";
static const NSString* OKey_Pay_EX=@"Pay_EX";
static const NSString* OKey_Event_ID=@"Event_ID";
static const NSString* OKey_Event_Type=@"Event_Type";
static const NSString* OKey_Event_EX=@"Event_EX";
static const NSString* OKey_Pay_Type=@"Pay_Type";

  
//static const int RES_CODE_NO_ERROR=1;
//static const int RES_CODE_INIT_ERROR=2;
//    
//static const int RES_CODE_LOGIN_ERROR=3;
//static const int RES_CODE_LOGIN_CANEL=4;
//    
//static const int RES_CODE_PAY_ERROR=4;
//static const int RES_CODE_PAY_CANEL=5;

static const int CONFIG_TRUE=1;
static const int CONFIG_FALSE=0;
	
static const int CONFIG_ACCOUNT_NONE=0;
static const int CONFIG_ACCOUNT_DIRECT=1;
static const int CONFIG_ACCOUNT_SINGLE=2;
static const int CONFIG_ACCOUNT_FULL=3;
static const int CONFIG_ACCOUNT_MSDK=4;
static const int CONFIG_ACCOUNT_YJ=5;
static const int CONFIG_ACCOUNT_YJ_Single=6;

static const int CONFIG_PAY_DIRECT=0;
static const int CONFIG_PAY_YJ=1;
static const int CONFIG_PAY_IPAY=2;
	
static const int Event_Login_Sucess = 1;
static const int Event_Login_Error = 2;
static const int Event_Share = 3;
static const int Event_URL = 4;

typedef void (^on_sdk_event)(int ,NSDictionary*);

@interface SDKBase:NSObject
{
    NSMutableDictionary* dic;
}
-(void)InitEvent;
-(void) Post:(int)task_id Request:(NSString*)request Param:(NSDictionary*)dic ;
-(void) Regist:(NSString*)request Fun:(on_sdk_event)dic;

@end
#endif
