//
//  AppsflyListener.m
//  Unity-iPhone
//
//  Created by aaa on 2020/9/23.
//


#import "AppDelegateListener.h"
#import "AppsFlyeriOSWrapper.h"
#include "XDAppListener.h"
#include "DataManager.h"
#include "EventManager.h"

#include "CollectionTool.h"
#import "UnityAppController.h"
#if __has_include(<AppsFlyerLib/AppsFlyerLib.h>)
#import <AppsFlyerLib/AppsFlyerLib.h>
#else
#import "AppsFlyerLib.h"
#endif
#import <objc/message.h>
#include "AppsflyListener.h"

typedef void (*bypassDidFinishLaunchingWithOption)(id, SEL, NSInteger);

@implementation AppsflyListener

- (instancetype)init
{
    self = [super init];
    if (self) {
        id swizzleFlag = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"AppsFlyerShouldSwizzle"];
        BOOL shouldSwizzle = swizzleFlag ? [swizzleFlag boolValue] : NO;
        
        if(!shouldSwizzle){
            UnityRegisterAppDelegateListener(self);
        }
    }
    return self;
}
- (void)onOpenURL:(NSNotification*)notification {
  
    NSURL *url = notification.userInfo[@"url"];
    NSString *sourceApplication = notification.userInfo[@"sourceApplication"];
    
    if (sourceApplication == nil) {
        sourceApplication = @"";
    }
    
    if (url != nil) {
        //[[AppsFlyerTracker sharedTracker] handleOpenURL:url sourceApplication:sourceApplication withAnnotation:nil];
		 [[AppsFlyerLib shared] handleOpenURL:url sourceApplication:sourceApplication withAnnotation:nil];
    }
    
}
-(void)Regist:(EventManager *)evt
{
    [evt RegistEvent:AE_continueUserActivity Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
        UIApplication* app=[DataManager Get:@"Application"];
       NSUserActivity* userActivity=GetArray(arr, 0);//[arr objectAtIndex:0];
       id restorationHandler=GetArray(arr, 1);
        // [[AppsFlyerTracker sharedTracker] continueUserActivity:userActivity restorationHandler:restorationHandler];
		  [[AppsFlyerLib shared] continueUserActivity:userActivity restorationHandler:restorationHandler];
    }];
     [evt RegistEvent:AE_didReceiveRemoteNotification Fun:^(NSArray* arr){
         NSNotification* notification=GetArray(arr, 0);
          
           // [[AppsFlyerTracker sharedTracker] handlePushNotification:notification.userInfo];
			 [[AppsFlyerLib shared] handlePushNotification:notification.userInfo];
        }];
        
    
    [evt RegistEvent:AE_didFinishLaunching Fun:^(NSArray* arr){
        NSLog(@"Arr=%@",arr);
        UIApplication* app=[DataManager Get:@"Application"];
       NSNotification* notification=GetArray(arr, 0);
	   
	   

    if (_AppsFlyerdelegate == nil) {
        _AppsFlyerdelegate = [[AppsFlyeriOSWarpper alloc] init];
    }

    [[AppsFlyerLib shared] setDelegate:_AppsFlyerdelegate];
     SEL SKSel = NSSelectorFromString(@"__willResolveSKRules:");
    id AppsFlyer = [AppsFlyerLib shared];
    if ([AppsFlyer respondsToSelector:SKSel]) {
        bypassDidFinishLaunchingWithOption msgSend = (bypassDidFinishLaunchingWithOption)objc_msgSend;
        msgSend(AppsFlyer, SKSel, 2);
    }
	
        
        if (notification.userInfo[@"url"]) {
           [self onOpenURL:notification];
        }
    }];
    
    [evt RegistEvent:AE_didBecomeActive Fun:^(NSArray* arr){
        NSNotification* notification=GetArray(arr, 0);
        UIApplication* app=[DataManager Get:@"Application"];
        NSLog(@"got didBecomeActive(out) = %@", notification.userInfo);
		if (self.didEnteredBackGround == YES&& AppsFlyeriOSWarpper.didCallStart == YES) {
			[[AppsFlyerLib shared] start];
			self.didEnteredBackGround = NO;
		}
    }];
   
   
      [evt RegistEvent:AE_openURL2 Fun:^(NSArray* arr){
        NSURL* url=GetArray(arr, 0);//[arr objectAtIndex:0];
        NSDictionary* options=GetArray(arr, 1);//[arr objectAtIndex:1];
       
        //  [[AppsFlyerTracker sharedTracker] handleOpenUrl:url options:options];
		    [[AppsFlyerLib shared] handleOpenUrl:url options:options];
    }];
     // [evt RegistEvent:AE_willResignActive Fun:^(NSArray* arr){
		// NSNotification* notification=GetArray(arr, 0);
       // if([AppsFlyerTracker sharedTracker].isDebug){
        // NSLog(@"got willResignActive = %@", notification.userInfo);
       // }
    // }];
     [evt RegistEvent:AE_didEnterBackground Fun:^(NSArray* arr){
        NSNotification* notification=GetArray(arr, 0);
    NSLog(@"got didEnterBackground = %@", notification.userInfo);
    self.didEnteredBackGround = YES;
  
        }];
 // [evt RegistEvent:AE_willEnterForeground Fun:^(NSArray* arr){
        // NSNotification* notification=GetArray(arr, 0);
       // if([AppsFlyerTracker sharedTracker].isDebug){
        // NSLog(@"got willEnterForeground = %@", notification.userInfo);
       // }
    // }];

    // [evt RegistEvent:AE_willTerminate Fun:^(NSArray* arr){
    // NSNotification* notification=GetArray(arr, 0);
       // if([AppsFlyerTracker sharedTracker].isDebug){
        // NSLog(@"got willTerminate = %@", notification.userInfo);
        // }
    // }];



}


@end

