#ifndef SKUQUERY_h
#define SKUQUERY_h

#include "XDUnityHandle.h"
#include <StoreKit/StoreKit.h>

@interface SKUQuery:XDUnityHandle<SKProductsRequestDelegate>

@end
#endif
