
#ifndef EventManager_h
#define EventManager_h
#import <Foundation/Foundation.h>

typedef void (^on_event)(NSArray*);
//@protocol  OnEventDelegate
//-(void)Fun:(NSArray*) objs;
//@end

@interface EventManager: NSObject
{
    NSMutableDictionary* dic;
}
//- (void) RegistEvent:(NSString*) evt  Fun:(id<OnEventDelegate>) fun;
//- (void) RemoveEvent:(NSString*) evt  Fun:(id<OnEventDelegate>) fun;
- (void) RegistEvent:(NSString*) evt  Fun:(on_event) fun;
- (void) RemoveEvent:(NSString*) evt  Fun:(on_event) fun;
- (void) CallEvent:(NSString* )evt Params :(NSArray*) objs;
    
@end
#endif
