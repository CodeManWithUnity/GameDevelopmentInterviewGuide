//
//  AppsflyListener.h
//  Unity-iPhone
//
//  Created by aaa on 2020/9/24.
//

#ifndef AppsflyListener_h
#define AppsflyListener_h
#import "AppDelegateListener.h"
#include "XDAppListener.h"
#include "DataManager.h"
#include "EventManager.h"

#include "CollectionTool.h"
#import "UnityAppController.h"


@interface AppsflyListener : XDAppListener<AppDelegateListener>
@property BOOL didEnteredBackGround;
@end

#endif /* AppsflyListener_h */
