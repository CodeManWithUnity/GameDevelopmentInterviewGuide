using System;
using System.Collections.Generic;
using System.IO;
using XD.tool;
using Debug = UnityEngine.Debug;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;
using System.Threading;
using System.Collections;

namespace XD.tool
{
    public static class XDZip
    {
        public const string Tag = "XDZip";
        public partial class FileData
        {
            public string entry;
            //public string path;

            public FileData(string entry)
            {
                this.entry = entry;
                //this.path = path;
            }
        }
        public static IEnumerator ExtractData(byte[] data, string password, string dir, Action<List<FileData>> complete)
        {
            List<FileData> list = new List<FileData>();
            bool end = false;
            string path_dir = PathUnity.GetPersistentWrite(dir);
            //ThreadStart start = new ThreadStart();
            Thread thread = new Thread(() => { ExtractThread(data, password, path_dir, list); end = true; });
            thread.Start();
            while (!end)
            {
                yield return new UnityEngine.WaitForSeconds(0.1f);
            }
            complete.Invoke(list);
        }

        private static void ExtractThread(byte[] data, string password, string path_dir, List<FileData> list)
        {
            try
            {

                if (!Directory.Exists(path_dir))
                {
                    Directory.CreateDirectory(path_dir);

                }
                byte[] bytes = new byte[4096];

                using (MemoryStream ms = new MemoryStream(data))
                {
                    ZipFile zipfile = new ZipFile(ms);
                    if (!string.IsNullOrEmpty(password))
                    {
                        zipfile.Password = password;
                    }
                    Thread.Sleep(10);
                    foreach (ZipEntry entry in zipfile)
                    {
                        string path = $"{path_dir}/{entry.Name}";
                        if (entry.IsDirectory)
                        {
                            Directory.CreateDirectory(path);
                            continue;
                        }

                        using (Stream zipInputStream = zipfile.GetInputStream(entry))
                        {
                            if(XD.tool.Debug.IsTagEnable("ZipArchieve"))Debug.Log(()=>$"ExtractThread File={entry.Name}",Tag);

                            list.Add(new FileData(entry.Name));
                            using (FileStream fileStream = File.Create(path))
                            {
                                StreamUtils.Copy(zipInputStream, fileStream, bytes);
                                //while (true)
                                //{

                                //    int count = zipInputStream.Read(bytes, 0, bytes.Length);
                                //    if (count > 0)
                                //    {
                                //        fileStream.Write(bytes, 0, count);
                                //    }
                                //    else
                                //    {
                                //        break;
                                //    }
                                //}
                            }


                        }

                    }
                }
                string file_list = $"{path_dir}/flist";
                using (FileStream fileStream = File.Create(file_list))
                {
                    using (StreamWriter sw = new StreamWriter(fileStream))
                    {
                        CollectionTool.ForAsc<FileData>(list, (index, file) =>
                         {
                             sw.WriteLine(file.entry);
                         });
                    }
                }
            }
            catch (Exception e)
            {
                if(XD.tool.Debug.IsTagEnable("LogError"))Debug.LogError(()=>$"Exception={e.Message}", "LogError");
            }
        }

        public static List<FileData> GetFileDatas(string path_dir)
        {
            List<FileData> list = new List<FileData>();
            string file_list = PathUnity.GetPersistentWrite($"{path_dir}/flist");
            using (FileStream fileStream = File.OpenRead(file_list))
            {
                using (StreamReader sw = new StreamReader(fileStream))
                {
                  
                    while(!sw.EndOfStream)
                    {
                        string line = sw.ReadLine();
                        list.Add(new FileData(line));
                    }
                }
            }
            return list;
        }

        
        public static  void Archieve(string target,string soruce,string password,int level)
        {
            FileEX.DirCheckAndCreate(target);
            if(File.Exists(target))
            {
                File.Delete(target);
            }
            using (ZipOutputStream zipOutputStream = new ZipOutputStream(File.Open(target, FileMode.Create)))
            {
                if (!string.IsNullOrEmpty(password))
                {
                    zipOutputStream.Password = password;
                }
                zipOutputStream.SetLevel(level);
                if (Directory.Exists(soruce))
                {
                    string[] files = Directory.GetFiles(soruce);
                    foreach (string filename in files)
                    {
                        using (FileStream newstream = File.OpenRead(filename))
                        {

                            byte[] setbuffer = new byte[newstream.Length];
                            newstream.Read(setbuffer, 0, setbuffer.Length);
                            ZipEntry newEntry = new ZipEntry(Path.GetFileName(filename));
                            newEntry.DateTime = DateTime.Now;
                            newEntry.Size = setbuffer.Length;
                            zipOutputStream.PutNextEntry(newEntry);
                            zipOutputStream.Write(setbuffer, 0, setbuffer.Length);
                        }
                    }
                }
            }
        }
    }

    public static class XDZipDownload
    {
        public static string Tag = "XDZipDownload";
        public static bool use_down = true;
        public static IEnumerator Download(string url,string extract_dir,string password)
        {
            bool isnew = false;
           
           
         
            if (use_down)
            {
                string per_path = "";
                string zip_temp = $"{extract_dir}_z";
                byte[] data = null;
                yield return DownloadRequest.Request(url, zip_temp, (path, b) => { per_path = path; isnew = b; }, null, true);
                if (isnew)
                {
                    yield return UrlRequest.RequestE(per_path, (d) =>
                    {
                        data = d;
                        if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"LoadMaster url Over={data.Length}", Tag);
                    });
                    yield return XDZip.ExtractData(data, password, extract_dir, (l) =>
                    {
                        if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"LoadMaster ExtractData Over={l.Count}", Tag);
                    });
                }
            }
            else
            {
                string version = "";
                string verion_save_path = $"{extract_dir}/{Path.GetFileName(url)}_ver";
                yield return URLVersion.Request($"{url}_ver", verion_save_path, (b, s) => { isnew = b; version = s; });
                if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"isnew={isnew},version={version}", Tag);
                if (isnew)
                {

                    byte[] data = null;
                    if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"Download url={url}", Tag);
                    yield return UrlRequest.RequestE(url, (d) =>
                    {
                        data = d;
                        if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"LoadMaster url Over={data.Length}", Tag);
                    });
                    yield return XDZip.ExtractData(data, password, extract_dir, (l) =>
                    {
                        if (XD.tool.Debug.IsTagEnable("ZipArchieve")) Debug.Log(() => $"LoadMaster ExtractData Over={l.Count}", Tag);
                    });
                    URLVersion.WriteVersion(verion_save_path, version);
                }
            }


        }
    }

}