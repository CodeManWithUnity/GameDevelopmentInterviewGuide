﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.tool;

namespace XD.Analytics
{
    public static class Bugly
    {
       
        internal static void Init(IDictionary dictionary, EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {
#if UNITY_EDITOR
            string buglyAppID="";
#elif UNITY_ANDROID
            string buglyAppID = CollectionTool.GetValue<string>(dictionary, "bugly_app_id_andorid");
#elif UNITY_IOS
            string buglyAppID = CollectionTool.GetValue<string>(dictionary, "bugly_app_id_ios");
#endif

            if (string.IsNullOrEmpty(buglyAppID)) return;
            BuglyAgent.ConfigDebugMode(false);
            BuglyAgent.InitWithAppId(buglyAppID);
            LogSeverity log_level = CollectionTool.GetValue<LogSeverity>(dictionary, "bugly_report_level");
            BuglyAgent.ConfigAutoReportLogLevel(log_level);//默认使用Exception等级
            BuglyAgent.EnableExceptionHandler();

            broadcast.RegistDelegate(XDAnalytics.Event.Login, OnLogin);
        }

        private static void OnLogin(IDictionary obj)
        {
            string user_id = CollectionTool.GetValue<string>(obj, "user_id");
            if(string.IsNullOrEmpty(user_id))
            {
                return;
            }
            BuglyAgent.SetUserId(user_id);
        }
    }
}
