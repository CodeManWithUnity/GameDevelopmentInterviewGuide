
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using XD.tool;
//using DataManager = XD.tool.DataManager;
using Debug = XD.tool.Debug;
using XD.Unity;
namespace XD.Analytics
{
    public static class NuAnalytics
    {

        private static CommonUnityHandle handle = new CommonUnityHandle("NuAnalytics");



        internal static void Init(IDictionary dic, EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {




            broadcast.RegistDelegate(XDAnalytics.Event.CreateRole, OnCreateRole);
            broadcast.RegistDelegate(XDAnalytics.Event.SetRole, OnSetRole);
            broadcast.RegistDelegate(XDAnalytics.Event.Login, OnLogin);
            broadcast.RegistDelegate(XDAnalytics.Event.SignUp, OnSignUp);
            broadcast.RegistDelegate(XDAnalytics.Event.SelectContent, OnSelectContent);
            broadcast.RegistDelegate(XDAnalytics.Event.Share, OnShare);
            broadcast.RegistDelegate(XDAnalytics.Event.Consume, OnConsume);
            broadcast.RegistDelegate(XDAnalytics.Event.TutorialBegin, OnTutorialBegin);
            broadcast.RegistDelegate(XDAnalytics.Event.TutorialComplete, OnTutorialComplete);
            broadcast.RegistDelegate(XDAnalytics.Event.Achievement, OnAchievement);
            broadcast.RegistDelegate(XDAnalytics.Event.JoinGroup, OnJoinGroup);
            broadcast.RegistDelegate(XDAnalytics.Event.LevelUp, OnLevelUp);
            broadcast.RegistDelegate(XDAnalytics.Event.LevelScore, OnScore);
            broadcast.RegistDelegate(XDAnalytics.Event.PurchaseSucess, OnPurchase);




        }

        private static void OnCreateRole(IDictionary obj)
        {
            LogEvent("CreateRole", obj);
        }
        private static void OnSetRole(IDictionary obj)
        {
            LogEvent("SetRole", obj);
        }
        private static void OnPurchase(IDictionary val)
        {
            //LogEvent(FirebaseAnalytics.EventEcommercePurchase,
            //     //new Parameter(FirebaseAnalytics.ParameterCoupon, CollectionTool.GetValue<int>(val, "product_type")),
            //      new Parameter(FirebaseAnalytics.ParameterCurrency, CollectionTool.GetValue<string>(val, "currency")),
            //    new Parameter(FirebaseAnalytics.ParameterValue, CollectionTool.GetValue<float>(val, "amount"))

            //    );
        }

        public static void LogEvent(string name, IDictionary param)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>() { { "event", name }, { "param", param } };
            handle.Request(dic, true);
        }

        private static void OnScore(IDictionary val)
        {
        }

        private static void OnLevelUp(IDictionary val)
        {
            LogEvent("LevelUp", val);

        }

        private static void OnJoinGroup(IDictionary val)
        {

        }

        private static void OnAchievement(IDictionary val)
        {

        }

        private static void OnTutorialComplete(IDictionary val)
        {

        }

        private static void OnTutorialBegin(IDictionary val)
        {

        }

        private static void OnConsume(IDictionary val)
        {

        }

        private static void OnShare(IDictionary val)
        {
        }

        private static void OnSelectContent(IDictionary val)
        {
        }

        private static void OnSignUp(IDictionary val)
        {

        }

        private static void OnLogin(IDictionary val)
        {

        }






    }



}