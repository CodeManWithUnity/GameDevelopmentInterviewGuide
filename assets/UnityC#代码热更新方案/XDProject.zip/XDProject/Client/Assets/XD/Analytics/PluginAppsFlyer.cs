using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.Analytics;
using XD.tool;
using Debug = XD.tool.Debug;
using System.Linq;
#if USE_APPSFLYER
using AppsFlyerSDK;
#endif

namespace XD.Analytics
{
    public static class PluginAppsFlyer
    {
#if USE_APPSFLYER
        internal static void Init(IDictionary dic, EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {
            broadcast.RegistDelegate(XDAnalytics.Event.SignUp, OnSignUp);
            broadcast.RegistDelegate(XDAnalytics.Event.TutorialComplete, OnToturialComplete);
            broadcast.RegistDelegate(XDAnalytics.Event.PurchaseSucess, OnPurachaseSucess);
            broadcast.RegistDelegate(XDAnalytics.Event.PurchaseStart, OnPurachaseStart);
           
            broadcast.RegistDelegate(XDAnalytics.Event.LevelUp, OnLevelUp);
            broadcast.RegistDelegate(XDAnalytics.Event.LevelScore, OnLevelScore);
            broadcast.RegistDelegate(XDAnalytics.Event.Consume, OnConsume);
            broadcast.RegistDelegate(XDAnalytics.Event.Login, OnLogin);
            broadcast.RegistDelegate(XDAnalytics.Event.Achievement, OnAchievement);
            broadcast.RegistDelegate(XDAnalytics.Event.Share, OnShare);
            broadcast.RegistDelegate(XDAnalytics.Event.Custom, OnCustorm);
          
            XD.Mono.UpdateManager.Regist(Update,0);

            var appsflyer_key = CollectionTool.GetValue<string>(dic, "appsflyer_dev_key");
            var appsflyer_id = CollectionTool.GetValue<string>(dic, "appsflyer_id");
            Debug.Log($"AppsFlyer SetKey={appsflyer_key}");
            GameObject go = new GameObject("AppsFlyerTrackerCallbacks");
            var tracker = go.AddComponent<AppsFlyerObjectScript>();
            tracker.isDebug = false;
            tracker.devKey = appsflyer_key;
            tracker.appID = appsflyer_id;
#if UNITY_IOS
            tracker.getConversionData = true;
#endif

#if UNITY_IOS
            //    //      UnityEngine.iOS.NotificationServices.RegisterForNotifications(UnityEngine.iOS.NotificationType.Alert | UnityEngine.iOS.NotificationType.Badge | UnityEngine.iOS.NotificationType.Sound);
#elif UNITY_ANDROID
            AppsFlyerAndroid.setCollectAndroidID(true);
            AppsFlyerAndroid.setCollectIMEI(true);
#endif
        }
      
       
       
      

        private static void OnCustorm(IDictionary obj)
        {
            string cutorm = CollectionTool.GetValue<string>(obj,"event");
            float amount = CollectionTool.GetValue<float>(obj, "amount");
            Dictionary<string, string> dic = new Dictionary<string, string>();
            CollectionTool.ForAsc(obj, (key, value) => CollectionTool.Add(dic, key.ToString(), value.ToString()));
            CollectionTool.Add(dic, AFInAppEvents.REVENUE, amount.ToString("f2"));
            LogEvent(cutorm, dic);
        }

        private static void OnShare(IDictionary val)
        {
            LogEvent(AFInAppEvents.SHARE, new Dictionary<string, string>()
            {
               {AFInAppEvents.DESCRIPTION,CollectionTool.GetValue<string>(val,"share_id")},
            });
        }

        private static void OnLogin(IDictionary val)
        {
            LogEvent(AFInAppEvents.LOGIN, new Dictionary<string, string>()
            {

            });
        }

        private static void OnAchievement(IDictionary val)
        {
            LogEvent(AFInAppEvents.ACHIEVEMENT_UNLOCKED, new Dictionary<string, string>()
            {
                { AFInAppEvents.DESCRIPTION,CollectionTool.GetValue<string>(val,"achievement_id")},
            });
        }

        private static void OnConsume(IDictionary val)
        {
            LogEvent(AFInAppEvents.SPENT_CREDIT, new Dictionary<string, string>()
            {
             { AFInAppEvents.PRICE,CollectionTool.GetValue<int>(val,"amount").ToString()},
             { AFInAppEvents.CONTENT_TYPE,CollectionTool.GetValue<string>(val,"item_type")},
                { AFInAppEvents.CONTENT_ID,CollectionTool.GetValue<string>(val,"item_id")},
            });
        }

        private static void OnLevelScore(IDictionary val)
        {
            LogEvent(AFInAppEvents.RATE, new Dictionary<string, string>()
            { 
               { AFInAppEvents.RATING_VALUE,CollectionTool.GetValue<int>(val,"score").ToString()},
               { AFInAppEvents.CONTENT_TYPE,CollectionTool.GetValue<string>(val,"level_type")},
               { AFInAppEvents.CONTENT_ID,CollectionTool.GetValue<string>(val,"level_id")},
               { AFInAppEvents.MAX_RATING_VALUE,CollectionTool.GetValue<int>(val,"score_max").ToString()},
             });
        }

        private static void OnToturialComplete(IDictionary val)
        {
            LogEvent(AFInAppEvents.TUTORIAL_COMPLETION, new Dictionary<string, string>()
            {
            });
        }

        private static void OnSignUp(IDictionary val)
        {
            LogEvent(AFInAppEvents.COMPLETE_REGISTRATION, new Dictionary<string, string>()
            {
                { AFInAppEvents.REGSITRATION_METHOD,CollectionTool.GetValue<string>(val,"method")},
            });
        }

        private static void OnPurachaseStart(IDictionary val)
        {
            LogEvent(AFInAppEvents.ADD_TO_CART, new Dictionary<string, string>()
            {
               { AFInAppEvents.PRICE,(CollectionTool.GetValue<int>(val,"amount")*0.01f).ToString()},
               { AFInAppEvents.CONTENT_TYPE,CollectionTool.GetValue<string>(val,"product_type")},
               { AFInAppEvents.CONTENT_ID,CollectionTool.GetValue<string>(val,"product_id")},
               { AFInAppEvents.CURRENCY,CollectionTool.GetValue<string>(val,"currency")}
            });
        }

        private static void OnLevelUp(IDictionary val)
        {
            LogEvent(AFInAppEvents.LEVEL_ACHIEVED, new Dictionary<string, string>()
            {
               { AFInAppEvents.LEVEL,CollectionTool.GetValue<string>(val,"level")},
            });
        }



      

        private static void OnPurachaseSucess(IDictionary val)
        {
            LogEvent(AFInAppEvents.PURCHASE, new Dictionary<string, string>()
            {
                { AFInAppEvents.CONTENT_ID,CollectionTool.GetValue<string>(val,"product_id")},
                { AFInAppEvents.CONTENT_TYPE,CollectionTool.GetValue<string>(val,"product_type")},
                { AFInAppEvents.REVENUE,(CollectionTool.GetValue<float>(val,"amount")).ToString("f2")},
                { AFInAppEvents.CURRENCY,CollectionTool.GetValue<string>(val,"currency")}
            });
        }

        public static void LogEvent(string eventName, Dictionary<string, string> eventValues)
        {
            if (eventValues == null)
            {
                eventValues = new Dictionary<string, string>();
            }
            Debug.Log($"Appflayers LogAppEvent={eventName}");
            AppsFlyer.sendEvent(eventName, eventValues);
        }

        //private static Dictionary<string,string> TransDic(IDictionary dic)
        //{
        //    if(dic==null)
        //    {
        //        return null;
        //    }
        //    Dictionary<string, string> d = new Dictionary<string, string>();
        //    foreach(KeyValuePair<object,object>  pair in dic)
        //    {
        //        if(pair.Key!=null&&pair.Value!=null)
        //        d.Add(pair.Key.ToString(), pair.Value.ToString());
        //    }
        //    return d;
        //}
        private static string last_token;
        private static bool token_sent = false;
        private static void Update(float obj)
        {
#if UNITY_ANDROID
            string token = XD.tool.DataManager.Get<string>("notification_token");
            if (last_token != token)
            {
                last_token = token;
                AppsFlyerAndroid.updateServerUninstallToken(token);

            }
#elif UNITY_IOS
        if(!token_sent)
        {
            byte[] token = UnityEngine.iOS.NotificationServices.deviceToken;
            if(token!=null)
            {
                AppsFlyeriOS.registerUninstall(token);
                token_sent = true;

            }
        }
#endif
        }
#else
            internal static void Init(IDictionary dic, EventBoardcast<XDAnalytics.Event,  Action<IDictionary>> broadcast)
        {

        }
#endif
    }

}