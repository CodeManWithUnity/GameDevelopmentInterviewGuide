#if USE_FIREBASE
using Firebase;
using Firebase.Analytics;
using Firebase.Crashlytics;
#endif
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using XD.tool;
//using DataManager = XD.tool.DataManager;
using Debug = XD.tool.Debug;
namespace XD.Analytics
{
    public static class PluginFirebase
    {
#if USE_FIREBASE
        public partial class ParameterProxy
        {
            internal Parameter p;
            private int v;

           
            public ParameterProxy(string parameterName, string parameterValue)
            {
                p = new Parameter(parameterName, parameterValue);
            }
            public ParameterProxy(string parameterName, long parameterValue)
            {
                p = new Parameter(parameterName, parameterValue);
            }
            public ParameterProxy(string parameterName, double parameterValue)
            {
                p = new Parameter(parameterName, parameterValue);
            }
        }


        //[System.NonSerialized]
        private static DependencyStatus dependencyStatus= DependencyStatus.UnavailableDisabled;
        public delegate void OnFirebase(DependencyStatus result);
        private static event OnFirebase event_func;
        private static bool started = false;
        // Use this for initialization
       

        internal static void Init(IDictionary dic,EventBoardcast<XDAnalytics.Event,Action<IDictionary>> broadcast)
        {
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("-------------------------------FirebaseBoot Start=");
            FirebaseApp.CheckAndFixDependenciesAsync().ContinueWith((task) =>
            {
                var result = task.Result;
                if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("-------------------------------FirebaseApp Result=" + result);
                if (result == DependencyStatus.Available)
                {
                    FirebaseAnalytics.SetAnalyticsCollectionEnabled(true);
                    //FirebaseAnalytics.SetMinimumSessionDuration(new TimeSpan(0, 0, 10));
                    FirebaseAnalytics.SetSessionTimeoutDuration(new TimeSpan(0, 30, 0));

                    Crashlytics.IsCrashlyticsCollectionEnabled = true;
                    Firebase.Messaging.FirebaseMessaging.TokenReceived += OnTokenReceived;
                    Firebase.Messaging.FirebaseMessaging.MessageReceived += OnMessageReceived;
                    broadcast.RegistDelegate(XDAnalytics.Event.Login, OnLogin);
                    broadcast.RegistDelegate(XDAnalytics.Event.SignUp, OnSignUp);
                    broadcast.RegistDelegate(XDAnalytics.Event.SelectContent, OnSelectContent);
                    broadcast.RegistDelegate(XDAnalytics.Event.Share, OnShare);
                    broadcast.RegistDelegate(XDAnalytics.Event.Consume, OnConsume);
                    broadcast.RegistDelegate(XDAnalytics.Event.TutorialBegin, OnTutorialBegin);
                    broadcast.RegistDelegate(XDAnalytics.Event.TutorialComplete, OnTutorialComplete);
                    broadcast.RegistDelegate(XDAnalytics.Event.Achievement, OnAchievement);
                    broadcast.RegistDelegate(XDAnalytics.Event.JoinGroup, OnJoinGroup);
                    broadcast.RegistDelegate(XDAnalytics.Event.LevelUp, OnLevelUp);
                    broadcast.RegistDelegate(XDAnalytics.Event.LevelScore, OnScore);
                    broadcast.RegistDelegate(XDAnalytics.Event.PurchaseSucess, OnPurchase);
                    broadcast.RegistDelegate(XDAnalytics.Event.Custom, OnCustom);
                   
                   
                }
                else
                {
                    XD.tool.DataManager.Set("notification_token", "");
                    XD.tool.DataManager.Set("notification_token_received", false);

                }
                if (event_func != null)
                {
                    event_func(result);
                }
                event_func = null;
                started = true;
                dependencyStatus = result;
            });
        
        }

        private static void OnCustom(IDictionary obj)
        {
            string cutorm = CollectionTool.GetValue<string>(obj, "event");
          
            ParameterProxy[] pp = new ParameterProxy[obj.Count];
            int index = 0;
            CollectionTool.ForAsc(obj, (key, value) => pp[index++]=new ParameterProxy(key.ToString(),value.ToString()));

            LogEvent(cutorm, pp);
        }
       
      
        private static void OnPurchase(IDictionary val)
        {
            //LogEvent(FirebaseAnalytics.EventEcommercePurchase,
            //      new ParameterProxy(FirebaseAnalytics.ParameterCoupon, CollectionTool.GetValue<int>(val, "product_type")),
            //      new ParameterProxy(FirebaseAnalytics.ParameterCurrency, CollectionTool.GetValue<string>(val, "currency")),
            //    new ParameterProxy(FirebaseAnalytics.ParameterValue, CollectionTool.GetValue<float>(val, "amount"))

            //    );
        }

        public static void LogEvent(string name, params ParameterProxy[] proxys)
        {
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log($"LogEvent={name},ParameterProxys={proxys.Length}，dependencyStatus={dependencyStatus}");
            if (dependencyStatus == DependencyStatus.Available)
            {
                Parameter[] parameters = null;
                if(proxys!=null)
                {
                    parameters = new Parameter[proxys.Length];
                    for(int i=0;i<proxys.Length;++i)
                    {
                        parameters[i] = proxys[i].p;
                    }
                }
                FirebaseAnalytics.LogEvent(name, parameters);
            }
        }
        private static void OnAttribution(IDictionary obj)
        {
            int level = CollectionTool.GetValue<int>(obj, "value");
            LogEvent("Attribution", new ParameterProxy(FirebaseAnalytics.ParameterScore,level));
        }
        private static void OnScore(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventPostScore,
                 new ParameterProxy(FirebaseAnalytics.ParameterScore, CollectionTool.GetValue<int>(val, "score")),
                  new ParameterProxy(FirebaseAnalytics.ParameterLevel, CollectionTool.GetValue<string>(val, "level_id")),
                new ParameterProxy(FirebaseAnalytics.ParameterCharacter, CollectionTool.GetValue<string>(val, "user_id"))
                );
        }

        private static void OnLevelUp(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventLevelUp,
                new ParameterProxy(FirebaseAnalytics.ParameterLevel, CollectionTool.GetValue<int>(val, "level")),
                new ParameterProxy(FirebaseAnalytics.ParameterCharacter, CollectionTool.GetValue<string>(val, "user_id"))
                );
        }

        private static void OnJoinGroup(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventJoinGroup,
                new ParameterProxy(FirebaseAnalytics.ParameterGroupId, CollectionTool.GetValue<string>(val, "group_id")));
        }

        private static void OnAchievement(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventUnlockAchievement,
                new ParameterProxy(FirebaseAnalytics.ParameterAchievementId,CollectionTool.GetValue<string>(val,"achievement_id")));
        }

        private static void OnTutorialComplete(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventTutorialComplete);
        }

        private static void OnTutorialBegin(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventTutorialBegin);
        }

        private static void OnConsume(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventSpendVirtualCurrency,
                new ParameterProxy(FirebaseAnalytics.ParameterItemName, CollectionTool.GetValue<string>(val, "item_id")),
                new ParameterProxy(FirebaseAnalytics.ParameterVirtualCurrencyName, CollectionTool.GetValue<string>(val, "item_type")),
                new ParameterProxy(FirebaseAnalytics.ParameterValue, CollectionTool.GetValue<int>(val, "amount")*0.01f)
                ) ;
        }

        private static void OnShare(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventShare,
               new ParameterProxy(FirebaseAnalytics.ParameterContentType, CollectionTool.GetValue<string>(val, "content_type")),
               new ParameterProxy(FirebaseAnalytics.ParameterItemId, CollectionTool.GetValue<string>(val, "content_id")));
        }

        private static void OnSelectContent(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventSelectContent,
                new ParameterProxy(FirebaseAnalytics.ParameterContentType, CollectionTool.GetValue<string>(val, "content_type")),
                new ParameterProxy(FirebaseAnalytics.ParameterItemId, CollectionTool.GetValue<string>(val, "content_id")));
        }

        private static void OnSignUp(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventSignUp);
        }

        private static void OnLogin(IDictionary val)
        {
            LogEvent(FirebaseAnalytics.EventLogin);
        }

        public static void OnTokenReceived(object sender, Firebase.Messaging.TokenReceivedEventArgs token)
        {
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("Received Registration Token: " + token.Token);           
            XD.tool.DataManager.Set("notification_token", token.Token);
            XD.tool.DataManager.Set("notification_token_received", true);
        }

        public static void OnMessageReceived(object sender, Firebase.Messaging.MessageReceivedEventArgs e)
        {
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("Received a new message from: " + e.Message.From);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("json : " + JsonUtility.ToJson(e, true));
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("json : " + JsonUtility.ToJson(e.Message, true));
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.To);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.TimeToLive);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Link);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Priority);
            if(XD.tool.Debug.IsTagEnable("LogError"))Debug.Log(e.Message.ErrorDescription);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.MessageId);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.ToString());
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.MessageType);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.RawData);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Data);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("json : " + JsonUtility.ToJson(e.Message.Data, true));
            foreach (var iter in e.Message.Data)
            {
                if(XD.tool.Debug.IsTagEnable("PluginFirebase"))UnityEngine.Debug.Log(iter.Key + " : " + iter.Value);
            }


            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log("json : " + JsonUtility.ToJson(e.Message.Notification, true));
            if (e.Message.Notification == null)
            {
                if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.LogWarning("Notification is null");
                return;
            }
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Notification.Title);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Notification.Body);
            if(XD.tool.Debug.IsTagEnable("PluginFirebase"))Debug.Log(e.Message.Notification.Icon);
        }

        public static void CheckAvailable(OnFirebase func)
        {
            if (started)
            {
                func(dependencyStatus);
            }
            else
            {
                event_func += func;
            }
        }
#else
        internal static void Init(IDictionary dic,EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {           
            XD.tool.DataManager.Set("notification_token", "");
            XD.tool.DataManager.Set("notification_token_received", true);
        }
#endif

    }



}