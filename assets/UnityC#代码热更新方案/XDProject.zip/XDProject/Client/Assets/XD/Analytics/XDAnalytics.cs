using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.Mono;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Analytics
{
    public static class XDAnalytics
    {
        public static string Tag = "XDAnalytics";
        public enum Event
        {
            Start,
            Pause,
            Resume,
            SignUp,
            Login,
            Logout,
            TutorialBegin,
            TutorialComplete,
            LevelUp,
            JoinGroup,
            SelectContent,
            Achievement,
            Share,
            Consume,
            PurchaseStart,
            PurchaseSucess,
            PurchaseCancel,
            LevelScore,
            Log,
            CreateRole,
            SetRole,
            Quit,
            Attribution,
            Custom
        }



        private static EventBoardcast<Event, Action<IDictionary>> broadcast;
        //private static XDAnalytics analytics = null;

        public static void Create(string text)
        {
            broadcast = new EventBoardcast<Event, Action<IDictionary>>();
            //TextAsset txt = (TextAsset)Resources.Load("config_analytics");
            //if (txt == null)
            //{
            //    return;
            //}
            if (string.IsNullOrEmpty(text))
            {
                return;
            }

            IDictionary dictionary = Config.ReadText(text);
            //Settings setting = new Settings(text);

#if !UNITY_EDITOR
            PluginFacebook.Init(dictionary, broadcast);
            PluginFirebase.Init(dictionary, broadcast);
            PluginAppsFlyer.Init(dictionary, broadcast);
#endif
            NuAnalytics.Init(dictionary, broadcast);
            Bugly.Init(dictionary, broadcast);
            XD.Mono.LifecycleManager.Regist(OnLifeCycle,0);
            broadcast.Broadcast(Event.Start, null);
        }

        private static void OnLifeCycle(LifecycleManager.Status obj)
        {
           if(obj== LifecycleManager.Status.Pause)
            {
                broadcast.Broadcast(Event.Pause, null);
            }
           else if(obj== LifecycleManager.Status.Resume)
            {
                broadcast.Broadcast(Event.Resume, null);
            }
            else if (obj == LifecycleManager.Status.Quit)
            {
                broadcast.Broadcast(Event.Quit, null);
            }
        }
        public static void Attribution(int value)
        {
            Analytics(Event.Attribution, new Dictionary<string, object>() {
                   { "value", value},                 
                });
        }

        public static void Consume(int amount, string item_type, string item_id)
        {
            Analytics(Event.Consume, new Dictionary<string, object>() {
                   { "amount", amount},
                    { "item_type",item_type},
                    {"item_id",item_id}
                });
        }
        public static void Share(string share_id)
        {
            Analytics(Event.Share, new Dictionary<string, object>() {
                   { "share_id", share_id},
                });
        }
        public static void JoinGroup( string group_id)
        {
            Analytics(Event.JoinGroup, new Dictionary<string, object>() {
                   { "group", group_id},                   
                });
        }
        public static void Log(string evt)
        {
            Analytics(Event.Log, new Dictionary<string, object>() { { "event", evt } });
        }
        public static void Login(string user_id)
        {
            Analytics(Event.Login, new Dictionary<string, object>() {             
                 { "user_id" ,user_id},              
            });
        }
        public static void TutorialBegin()
        {
            Analytics(Event.TutorialBegin, null);
        }

        public static void TutorialComplete()
        {
            Analytics(Event.TutorialComplete, null);
        }
        public static void Achievement(string achievement_id)
        {
            Analytics(Event.Achievement, new Dictionary<string, object>() {
                        {"achievement_id",achievement_id }
                    });
        }
        public static void LevelScore(string user_id, string level_id, string level_type, int score, int score_max)
        {
            Analytics(Event.LevelScore, new Dictionary<string, object>() {
                { "level_id" ,level_id},
                { "level_type" ,level_type},
                 { "user_id" ,user_id},
                { "score",score},
                { "score_max",score_max}
            });
        }
        public static void LevelUp(string user_id, int level)
        {
            Analytics(Event.LevelUp, new Dictionary<string, object>() {
                { "level" ,level.ToString()},
                 { "user_id" ,user_id},
                });
        }
        public static void CreateRole(string user_id,string user_name, int level,string zone_id,string zone_name)
        {
            Analytics(Event.CreateRole, new Dictionary<string, object>() {
               { "user_id" ,user_id},
                 { "user_name" ,user_name},
                { "level",level.ToString()},
                { "zone_id",zone_id},
                { "zone_name",zone_name}
                });
        }
        public static void SetRole(string user_id, string user_name, int level, string zone_id, string zone_name)
        {
            Analytics(Event.CreateRole, new Dictionary<string, object>() {
                { "user_id" ,user_id},
                 { "user_name" ,user_name},
                { "level",level.ToString()},
                { "zone_id",zone_id},
                { "zone_name",zone_name}
                });
        }
        public static void SignUp(string method,string server_id,string server_name)
        {
            Analytics(Event.SignUp, new Dictionary<string, object>()
                {
                    { "method",method},
                      { "server_id",server_id},
                        { "server_name",server_name}
                    }
                     );
        }
        public static void PurchaseStart(int amount, string product_type, string product_id, string currency)
        {
            Analytics(Event.PurchaseStart, new Dictionary<string, object>() {
                {"amount", amount*0.01f},
                {"product_type",product_type },
                { "product_id", product_id},
                { "currency",currency}
            });
        }
        public static void PurchaseCancel(int amount, string product_type, string product_id, string currency, string purchase_id)
        {
            Analytics(Event.PurchaseCancel, new Dictionary<string, object>() {
                {"amount", amount*0.01f},
                {"product_type",product_type },
                { "product_id", product_id},
                { "currency",currency},
                 {"purchase_info", purchase_id },
            });
        }
        public static void PurchaseSucess(int amount, string product_type, string product_id, string currency, string purchase_info, int purchase_num)
        {
            Analytics(Event.PurchaseSucess, new Dictionary<string, object>() {
                 {"amount", amount*0.01f},
                {"product_type",product_type },
                { "product_id", product_id},
                { "currency",currency},
                 {"purchase_info", purchase_info },
                  {"purchase_num", purchase_num },
            });
        }
        public static void SelectContent(string content_type,string content_id)
        {
            Analytics( Event.SelectContent,new Dictionary<string, object>() {
                { "content_type",content_type},
                { "content_id",content_id}
            });       
        }

        public static void Analytics(Event evt, IDictionary dic)
        {
            if(XD.tool.Debug.IsTagEnable("XDAnalytics"))Debug.Log(() => $"Analytics Evt={evt}, dic={(dic != null ? CollectionTool.Print(dic) : "")}", Tag);
            //broadcast.Broadcast(evt, (dele)=>dele.Invoke( dic));
            broadcast.Broadcast(evt,InvokeAction(dic));
        }
        private static IDictionary curr_dic;
        private static Action<Action<IDictionary>> InvokeAction(IDictionary dic)
        {
            curr_dic = dic;
            return InvokeAction2;
        }

        private static void InvokeAction2(Action<IDictionary> dele)
        {
            dele.Invoke(curr_dic);
        }

        public static void RegistErrorHandler(Func<string> func)
        {
            BuglyAgent.SetLogCallbackExtrasHandler2(func);
        }
        public static void RemoveErrorHandler()
        {
            BuglyAgent.SetLogCallbackExtrasHandler2(null);
        }
        // Use this for initialization




        //void OnApplicationPause(bool pauseStatus)
        //{
        //    if (pauseStatus)
        //    {
        //        Analytics(Event.Pause, null);
        //    }
        //    else
        //    {
        //        Analytics(Event.Resume, null);
        //    }
        //}
        //private List<System.Action<float>> list_update = new List<Action<float>>();
        //internal void AddUpdate(System.Action<float> update)
        //{
        //    list_update.Add(update);
        //}
        //void Update()
        //{
        //    if(list_update!=null)
        //    {
        //        for(int i=list_update.Count-1;i>=0;--i)
        //        {
        //            list_update[i](Time.deltaTime);
        //        }
        //    }
        //}

    }
}