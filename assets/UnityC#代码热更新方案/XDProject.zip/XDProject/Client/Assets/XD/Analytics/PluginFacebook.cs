#if USE_FACEBOOK
using Facebook.Unity;
#endif
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Analytics
{
    public static class PluginFacebook
    {

#if USE_FACEBOOK

        private static bool inited_call=false;
        private static bool fb_inited = false;
        //private static EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast;
        internal static void Init(IDictionary dic, EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {
            //PluginFacebook.broadcast = broadcast;
            InitSDK();
            broadcast.RegistDelegate(XDAnalytics.Event.Resume, OnResume);

            broadcast.RegistDelegate(XDAnalytics.Event.LevelUp, OnLevelUp);
            broadcast.RegistDelegate(XDAnalytics.Event.SignUp, OnSignUp);
           
            broadcast.RegistDelegate(XDAnalytics.Event.TutorialComplete, OnTutrialComplete);
            broadcast.RegistDelegate(XDAnalytics.Event.PurchaseStart, OnPuchaseStart);
            broadcast.RegistDelegate(XDAnalytics.Event.PurchaseSucess, OnPuchaseSucess);
           
            broadcast.RegistDelegate(XDAnalytics.Event.LevelScore, OnScore);
            broadcast.RegistDelegate(XDAnalytics.Event.Achievement, OnAchievement);
            broadcast.RegistDelegate(XDAnalytics.Event.Consume, OnConsume);           
            broadcast.RegistDelegate(XDAnalytics.Event.Custom, OnCustom);
           

        }
       
      

        private static void OnCustom(IDictionary obj)
        {
            string cutorm = CollectionTool.GetValue<string>(obj, "event");
            float amount = CollectionTool.GetValue<float>(obj, "amount");
            
            Dictionary<string, object> dic = new Dictionary<string, object>();
            CollectionTool.ForAsc(obj, (key, value) => CollectionTool.Add(dic, key.ToString(), value.ToString()));


            LogEvent(cutorm, true, amount, dic);
        }

      

        private static void InitSDK()
        {
            if(XD.tool.Debug.IsTagEnable("PluginFacebook"))Debug.Log($"--------------------FB Init={FB.IsInitialized}");
            if (FB.IsInitialized)
            {
                FB.ActivateApp();
            }
            else
            {
                if (!inited_call)
                {
                    FB.Init(() =>
                    {
                        if(XD.tool.Debug.IsTagEnable("PluginFacebook"))Debug.Log("--------------------FB Init Over");
                        FB.ActivateApp();
                        LogEvent(AppEventName.ActivatedApp);
                        if(!fb_inited)
                        {
                          
                        }
                        fb_inited = true;
                    });
                    inited_call = true;
                }
            }
        }


        private static void OnPuchaseStart(IDictionary val)
        {
            LogEvent(AppEventName.AddedToCart,true, CollectionTool.GetValue<float>(val, "amount"), new Dictionary<string, object>() {
                { AppEventParameterName.ContentType,CollectionTool.GetValue<string>(val,"product_type")},
                { AppEventParameterName.ContentID,CollectionTool.GetValue<string>(val,"product_id")},               
                { AppEventParameterName.Currency,CollectionTool.GetValue<string>(val,"currency")}
            });
        }

        private static void OnConsume(IDictionary val)
        {
            LogEvent(AppEventName.SpentCredits,true, CollectionTool.GetValue<int>(val, "amount"), new Dictionary<string, object>()
            {
                { AppEventParameterName.ContentType,CollectionTool.GetValue<string>(val,"item_type")},
                { AppEventParameterName.ContentID,CollectionTool.GetValue<string>(val,"item_id")},             

            });
        }

        private static void OnAchievement(IDictionary val)
        {
            LogEvent(AppEventName.UnlockedAchievement,false, 0f, new Dictionary<string, object>()
            {
                { AppEventParameterName.Description,CollectionTool.GetValue<string>(val,"achievement_id")},           
            });
        }

        private static void OnScore(IDictionary val)
        {
            LogEvent(AppEventName.Rated,true, CollectionTool.GetValue<int>(val, "score"), new Dictionary<string, object>()
            {
                { AppEventParameterName.ContentType,CollectionTool.GetValue<string>(val,"level_type")},
                { AppEventParameterName.ContentID,CollectionTool.GetValue<string>(val,"level_id")},
                { AppEventParameterName.MaxRatingValue,CollectionTool.GetValue<int>(val,"score_max")},
               
            });
        }
       

        private static void OnPuchaseSucess(IDictionary val)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>() {
                { AppEventParameterName.ContentType,CollectionTool.GetValue<string>(val,"product_type")},
                { AppEventParameterName.ContentID,CollectionTool.GetValue<string>(val,"product_id")},
                { AppEventParameterName.NumItems,CollectionTool.GetValue<int>(val,"purchase_num")},
                { AppEventParameterName.PaymentInfoAvailable,CollectionTool.GetValue<string>(val,"purchase_info")},
                { AppEventParameterName.Currency,CollectionTool.GetValue<string>(val,"currency")}
            };
            FB.LogPurchase(CollectionTool.GetValue<float>(val, "amount"), CollectionTool.GetValue<string>(val, "currency"), parameters);
            //LogAppEvent(AppEventName.Purchased,CollectionTool.GetValue<float>(val,"amount"), dic);
        }
      
        private static void OnTutrialComplete(IDictionary val)
        {
            LogEvent(AppEventName.CompletedTutorial);
        }

        private static void OnSignUp(IDictionary val)
        {
            LogEvent(AppEventName.CompletedRegistration,false,0f,new Dictionary<string, object>() {
                { AppEventParameterName.Currency,CollectionTool.GetValue<string>(val, "currency")},
                { AppEventParameterName.RegistrationMethod,CollectionTool.GetValue<string>(val, "method")}
            });
        }

        private static void OnLevelUp(IDictionary val)
        {
            LogEvent(AppEventName.AchievedLevel,true,1.0f, new Dictionary<string, object> (){ { AppEventParameterName.Level, CollectionTool.GetValue<int>(val, "level") } });
        }

        private static void OnResume(IDictionary val)
        {
            InitSDK();
        }
        public static void LogEvent(string logEvent,bool valueable=false, float valueToSum=0f , Dictionary<string, object> parameters = null)
        {
            if(!fb_inited)
            {
                return;
            }
            if(parameters==null)
            {
                parameters = new Dictionary<string, object>();
            }
            if(XD.tool.Debug.IsTagEnable("PluginFacebook"))Debug.Log($"FB LogAppEvent={logEvent}, parameters={parameters}, str={CollectionTool.Print(parameters)}");
            float? v = null ;
            if(valueable)
            {
                v = valueToSum;
            }
            FB.LogAppEvent(logEvent,v, parameters);

        }

#else
        internal static void Init(IDictionary dic, EventBoardcast<XDAnalytics.Event, Action<IDictionary>> broadcast)
        {

        }
#endif
    }
}