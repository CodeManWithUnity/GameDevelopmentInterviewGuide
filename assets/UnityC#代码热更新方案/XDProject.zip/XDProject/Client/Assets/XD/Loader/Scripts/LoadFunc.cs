﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XD.Hook;
using XD.Localization.Runtime;
using XD.Mono;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public  static partial class LoaderFunc 
    {
        private const string Tag = "LoadFunc";
        private const float wait_duration = 0.1f;
        private static int end_flag = -1;
        public static IEnumerator LoadEnumerator(int index, IEnumerator action)
        {
            end_flag &= ~(1 << index);
            Debug.Log(() => $"StartLoadIndex={index} End flag={Convert.ToString(end_flag, 2)},end={end_flag}", Tag);

            yield return action;

            end_flag |= 1 << index;
            Debug.Log(() => $"EndLoadIndex={index} End flag={Convert.ToString(end_flag, 2)},end={end_flag}", Tag);
        }

        public static bool IsLoading()
        {
            return end_flag != -1;
        }
        public static IEnumerator RequestLoc(bool force_load=true)
        {
            XD.Localization.Runtime.Localization.Lang = Settings.Get("lang");
            XD.Localization.Runtime.Localization.LoadLocalResources();
            yield return new WaitForSeconds(wait_duration);
            //string www_loc = ServerRedirect.Get("asset_loc");
            //if (!string.IsNullOrEmpty(www_loc))
            //{

            //    //Debug.Log($"Request Localization clock={Time.time}");
            //    yield return XD.Localization.Runtime.LocalizationDownload.instance.LoadAssetBundles(www_loc);
            //    yield return new WaitForSeconds(wait_duration);
            //}
            string loc_zip = Settings.Get("loc_zip");
            if (!string.IsNullOrEmpty(loc_zip))
            {
                string url_loc_zip = $"{loc_zip}/{XD.Localization.Runtime.Localization.Lang}.zip";
                string zip_dir = "Boltrend/XDLocalization";

                //bool isnew = false;
                //string version = "";
                //string verion_save_path = $"{zip_dir}/mver";
                //yield return URLVersion.Request($"{url_loc_zip}_ver", verion_save_path, (b, s) => { isnew = b; version = s; });
                //Debug.Log(() => $"isnew={isnew},version={version}", Tag);
                //if (isnew)
                //{
                //    string password = Localization.Runtime.Localization.Zip_Password;
                //    byte[] data = null;
                //    Debug.Log(() => $"LoadMaster url={url_loc_zip}", Tag);
                //    yield return UrlRequest.RequestE(url_loc_zip, (d) =>
                //    {
                //        data = d;
                //        Debug.Log(() => $"LoadMaster url Over={data.Length}", Tag);
                //    });
                //    yield return XDZip.ExtractData(data, password, zip_dir, (l) =>
                //    {
                //        Debug.Log(() => $"LoadMaster ExtractData Over={l.Count}", Tag);
                //    });
                //    URLVersion.WriteVersion(verion_save_path, version);
                //}
                yield return XDZipDownload.Download(url_loc_zip, zip_dir, Localization.Runtime.Localization.Zip_Password);
                yield return Localization.Runtime.Localization.LoadZipResources(zip_dir);



            }
            XDPluginHookRoot.RegistGlobalEvent(UpdateLabel,1);
#if UNITY_EDITOR
            XDPluginHookRoot.RegistGlobalEvent(ResetShader,0);
#endif
            yield return new WaitForSeconds(wait_duration);

        }

        private static void ResetShader(GameObject obj)
        {
            List<Material> list = new List<Material>();

            ResetObjs<Renderer>(list, obj, (c) => c.materials);
            ResetObjs<Image>(list, obj, (c) => new Material[] { c.material });
            ResetObjs<ParticleSystemRenderer>(list, obj, (c) => {
                List<Material> ms = new List<Material>();
                ms.Add(c.trailMaterial);
                
                return ms.ToArray();
            });
#if LOCALIZATION_UGUI_PRO
            ResetObjs<TMPro.TextMeshProUGUI>(list, obj, (c) => c.fontMaterials);
#endif

            for (int i = 0; i < list.Count; i++)
            {
                Shader s = list[i].shader;
                s = Shader.Find(s.name);
                if(!s.isSupported)
                {
                    Debug.LogError(() => $"Shader {s.name} Is Not Supported On {list[i]}", "ResetShader");
                }
                list[i].shader = s;
            }
        }
        private static void ResetObjs<T>(List<Material> list, GameObject go, System.Func<T, Material[]> get) where T : Component
        {
            T[] objs = go.GetComponentsInChildren<T>(true);// Resources.FindObjectsOfTypeAll<T>();
            //T[] objs = root.GetComponentsInChildren<T>(true);
            int length2 = objs.Length;

            for (int i = 0; i < length2; i++)
            {
                if (objs[i] != null && !string.IsNullOrEmpty(objs[i].gameObject.scene.name))
                {
                    try
                    {
                        Material[] mats = get(objs[i]);

                        if (mats != null)
                        {
                            for (int j = 0; j < mats.Length; ++j)
                            {
                                Material m = mats[j];
                                if (m != null && !list.Contains(m)) list.Add(m);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Debug.Log($"ResetObjs Error={objs[i].name}");
                    }
                }
            }
        }

        public static void UpdateLabel(GameObject obj)
        {
            LocalizationLabel[] labels = obj.GetComponentsInChildren<LocalizationLabel>(true);
            CollectionTool.ForAsc<LocalizationLabel>(labels, (index, v) =>
            {
                v.UpdateLabel(false);
            });

        }
        private static string curr_hook_ver = "";
        public static IEnumerator RequestHook(bool force_load = true)
        {
            XDHookManager.Format format = XDHookManager.Format.Json;
            string hook_url = Settings.Get("hook");
            string hook_url_j = Settings.Get("hook_j");
            if(!string.IsNullOrEmpty( hook_url_j))
            {
                hook_url = hook_url_j;
                format = XDHookManager.Format.Json;
            }else
            {
                format = XDHookManager.Format.Xml;
            }
            byte[] hook_data = null;
            if (!string.IsNullOrEmpty(hook_url))
            {
                //string[] sp = hook_urls.Split(',');
                //for (int i = 0; i < sp.Length; ++i)
                {
                    //string hook_url = sp[i];

                    //yield return UrlRequest.RequestE(ServerRedirect.Get("dydata"), (data) => dydata = data);
                    bool hook_direct = Settings.Get("hook_direct") == "true";
                    bool new_version = false;
                    string per_path = "";
                    if (hook_direct)
                    {

                        per_path = hook_url;
                        if (!string.IsNullOrEmpty(hook_url))
                        {
                            string version = "";
                            yield return UrlRequest.RequestE($"{per_path}_ver", (data) => { if (data != null) version = System.Text.Encoding.UTF8.GetString(data); });
                            new_version = version != curr_hook_ver;
                            curr_hook_ver = version;
                        }
                    }
                    else
                    { 
                        string save_file = System.IO.Path.GetFileName(hook_url);                     
                       
                        yield return DownloadRequest.Request(hook_url, $"Boltrend/XDDownload/{save_file}", (path, is_new) =>
                        {
                            per_path = path;
                            new_version = is_new;
                        }, null, true);
                    }
                    Debug.Log(() => $"RequestHook={force_load},{new_version}", Tag);
                    if (!force_load && !new_version)
                    {
                        yield break;
                    }
                    yield return UrlRequest.RequestE(per_path, (data) => { hook_data = data; }, 3, 5);
                }               
            }
            if(hook_data==null)
            {
                string local = PathUnity.GetStreamingRead("Data/hook_j");
                format = XDHookManager.Format.Json;
                yield return UrlRequest.RequestE(local, (data) => { hook_data = data; });
            }
            if (hook_data != null)
            {
                XDHookManager.Clear();
                //yield return new WaitForSeconds(wait_duration);
                //hook_data = XDCryptor.Decrypt(hook_data);
                //yield return new WaitForSeconds(wait_duration);
                //string text = System.Text.Encoding.UTF8.GetString(hook_data);
                //yield return new WaitForSeconds(wait_duration);
                //hook_data = null;

                //yield return new WaitForSeconds(wait_duration);
                //XDHookManager.LoadSettings(text);
                //yield return new WaitForSeconds(wait_duration);
                yield return CoroutineManager.EnumeratorWithThread(() =>
                {
                    hook_data = XDCryptor.Decrypt(hook_data);
                   
                    XDHookManager.LoadSettings(hook_data, format);
                    hook_data = null;
                });

            }
        }
        public static IEnumerator RequestSDK()
        {
            if(ServerRedirect.GetStatus()!= ServerRedirect.Status.Sucess)
            {
                yield break;
            }
            Debug.Log(() => $"Request SDK clock={Time.time}", Tag);
            string config_sdk = "";
            yield return ServerRedirect.LoadSettings("config_sdk", (text) =>
            {
                config_sdk = text;
            });
            yield return new WaitForSeconds(wait_duration);
            yield return XD.sdk.SDKProcess.CreateSDK(config_sdk, null);
            yield return new WaitForSeconds(wait_duration);
        }
       
#if USE_HOT
        private static wxb.RefType ref_app;
        private static string curr_data_ver = "";
        public static IEnumerator RequestHotFix(bool force_load = true)
        {
            string dy_url = Settings.Get("dydata");
            byte[] dydata = null;
            string dy_config = "";
            if (!string.IsNullOrEmpty(dy_url))
            {
                bool dydata_direct = Settings.Get("dydata_direct") == "true";

                string dy_config_url = Settings.Get("dyconfig");
              
                string dydata_per_path = "";
                string dyconfig_per_path = "";
                bool has_new_data = true;
                if (dydata_direct)
                {
                    dyconfig_per_path = dy_config_url;
                    dydata_per_path = dy_url;
                    if (!string.IsNullOrEmpty(dy_url))
                    {
                        string version = "";
                        yield return UrlRequest.RequestE($"{dy_url}_ver", (data) => { if (data != null) version = System.Text.Encoding.UTF8.GetString(data); });
                        has_new_data = version != curr_data_ver;
                        curr_data_ver = version;
                    }

                }
                else
                {
                    if (!string.IsNullOrEmpty(dy_url))
                    {
                        yield return DownloadRequest.Request(dy_url, "Boltrend/XDDownload/dydata", (path, is_new) => { dydata_per_path = path; has_new_data = is_new; }, null, true);
                        Debug.Log(() => $"RequestHotFix={force_load},{has_new_data}", Tag);
                        //yield return UrlRequest.RequestE(dy_config_url,  (data) =>  dy_config = System.Text.UTF8Encoding.UTF8.GetString(data));
                    }
                    yield return DownloadRequest.Request(dy_config_url, "Boltrend/XDDownload/dydata_config", (path, is_new) => dyconfig_per_path = path, null, true);
                }

                if (!force_load && !has_new_data)
                {
                    yield break;
                }

                //yield return UrlRequest.RequestE(ServerRedirect.Get("dydata"), (data) => dydata = data);


                yield return UrlRequest.RequestE(dydata_per_path, (data) => { dydata = data; });
                yield return UrlRequest.RequestE(dyconfig_per_path, (data) => { dy_config = System.Text.UTF8Encoding.UTF8.GetString(data); });
            }
            if (dydata == null)
            {
#if !UNITY_EDITOR
                string local = PathUnity.GetStreamingRead("Data/dydata");
                yield return UrlRequest.RequestE(local, (data) => { dydata = data; });
#endif
            }
            yield return new WaitForSeconds(wait_duration);
           
            yield return new WaitForSeconds(wait_duration);
            if (ref_app != null)
            {
                //RefType refType_r = new RefType("Hot.HotAppInitialize");
                IEnumerator e_r = (IEnumerator)ref_app.TryInvokeMethodReturn("Release");
                ref_app = null;
                yield return e_r;
            }
            UnityEngine.RuntimePlatform rp = GetCurrentPlatform();
            yield return CoroutineManager.EnumeratorWithThread(() => Init(dydata, dy_config, rp));
            dydata = null;
            ref_app = new wxb.RefType("Hot.HotAppInitialize");
            IEnumerator e = (IEnumerator)ref_app.TryInvokeMethodReturn("Initialize");
            if (e != null)
            {
                yield return e;
            }
        }
#endif
        public static IEnumerator RequestExcute(Action<string> action)
        {

            yield return ServerRedirect.LoadSettings("config_excute", (text) => { action(text); });
            yield return new WaitForSeconds(wait_duration);


            //Debug.Log(() => $"Request Excute clock={Time.time}", Tag);
        }

        public static IEnumerator RequestAnalytics()
        {
            if(ServerRedirect.GetStatus()!= ServerRedirect.Status.Sucess)
            {
                yield break;
            }
            Debug.Log(() => $"Request Analytics clock={Time.time}", Tag);
            string config_analytics = "";
            yield return ServerRedirect.LoadSettings("config_analytics", (text) => { config_analytics = text; });
            yield return new WaitForSeconds(wait_duration);
            XD.Analytics.XDAnalytics.Create(config_analytics);
            yield return new WaitForSeconds(wait_duration);
        }
    }
}