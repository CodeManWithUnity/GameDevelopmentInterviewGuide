using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using XD.Mono;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public partial class Loader : MonoBehaviour
    {
       
       
        public static string Tag = "XDLoader";

        public partial class WaitForAnimation : CustomYieldInstruction
        {
            private Animator m_Animator;
            private int m_LastStateHash;
            private int m_LayerNo;

            public WaitForAnimation(Animator animator, int layerNo)
            {
                Init(animator, layerNo, animator.GetCurrentAnimatorStateInfo(layerNo).fullPathHash);
            }

            void Init(Animator animator, int layerNo, int hash)
            {
                m_Animator = animator;
                m_LastStateHash = hash;
                m_LayerNo = layerNo;
            }

            public override bool keepWaiting
            {
                get
                {
                    if (m_Animator == null || !m_Animator.isActiveAndEnabled)
                    {
                        return false;
                    }
                    var currentAnimatorState = m_Animator.GetCurrentAnimatorStateInfo(m_LayerNo);
                    return currentAnimatorState.fullPathHash == m_LastStateHash && (currentAnimatorState.normalizedTime < 1);
                }
            }
        }
        private static Coroutine c;
        private bool next_scene = true;
        // Use this for initialization
        void Start()
        {
            XD.tool.Settings.Clear();
            //XD.tool.Debug.SetTag(Tag, true);
            //XD.tool.Debug.SetTag(ServerRedirect.Tag, true);
            //XD.tool.Debug.SetTag(Settings.Tag, true);
            //XD.tool.Debug.SetTag(UrlRequest.Tag, true);
            //XD.tool.Debug.SetTag("ErrorCheck", true);
            debug_dialog.SetActive(false);
            debug_info.SetActive(false);
            //XD.tool.Settings.Set("server_info", "");
            PlayAnim();
            //aboard.gameObject.SetActive(logo_type == LogoType.Aboard);
            //internel.gameObject.SetActive(logo_type == LogoType.Internel);
            CollectionTool.ForAsc<Button>(debug_buttons, (i, btn) =>
            {
                btn.onClick.AddListener(() => CheckDebug(i));

            });
            close_btn.onClick.AddListener(() =>
            {
#if UNITY_EDITOR
                AsyncOperation sync = SceneManager.LoadSceneAsync(0);
#else
                Application.Quit();
#endif

            });
            debug_info_check.onClick.AddListener(() => { next_scene = true; });

            c = StartCoroutine(InitNetease());

        }

        private const float wait_duration = 0.1f;
       
        //public IEnumerator LoadThread(int index, Action action)
        //{
        //    end_flag &= ~(1 << index);

        //    yield return CoroutineManager.EnumeratorWithThread(action);

        //    end_flag |= 1 << index;
        //}
       
        public IEnumerator InitNetease()
        {
            int loadindex = 0;
            //yield return new WaitForSeconds(10f);
            yield return new WaitForSeconds(wait_duration);
            ServerRedirect.ResetStatus();
            CoroutineManager.GetInstance().StopAllCoroutines();
            XD.tool.XDInitialize.Excute();
            string path_local = PathUnity.GetStreamingRead("settings/local.ini");
            yield return UrlRequest.RequestE(path_local, (data) =>
            {
                string text = System.Text.Encoding.UTF8.GetString(data);
                XD.tool.Settings.Load(text);
            });
            ConfigLog();
            Debug.Log(()=>$"InitNetease clock={Time.time}", Tag);
            //XD.tool.DownloadRequest.dir_path = "Boltrend/XDDownload";
            XD.tool.DataManager.InitSet("default");
            Debug.Log(()=>$"Request Server clock={Time.time}", Tag);
            List<string> list = null;
            yield return ServerRedirect.RequestList((l) => { list = l; });
            yield return ServerRedirect.Request();
            if (ServerRedirect.IsDebugable())
            {
                string debug_server = ServerRedirect.GetDebugServer();
                if (!string.IsNullOrEmpty(debug_server))
                {                   
                    string selected = "";
                   
                    if (debug_server.ToLower() == "list")
                    {
                        yield return DebugServerList(list, debug_server, (s) => selected = s);
                    }
                    else
                    {
                        selected = debug_server;
                    }
                    yield return ServerRedirect.Request(selected,false);
                }
            }
          
            int cheat_index = XD.tool.Settings.Get<int>("debug_index");
            if(cheat_index>0&&cheat_index<Cheat_Words.Length)
            {
                cheat = new CheatCheck(Cheat_Words[cheat_index]);
            }
            DownloadRequest.use_url_request = XD.tool.Settings.Get("download_request_simple")=="true";
            DownloadRequest.use_url_request_varify = XD.tool.Settings.Get("download_request_varify") == "true";

            ConfigLog();
            ShowServerInfo();
            //yield return ServerRedirect.LoadSettings();

#if UNITY_ANDROID&&!UNITY_EDITOR
            IDictionary dic_permission = null;
            yield return ServerRedirect.LoadSettings("permission",(str)=> dic_permission=Config.ReadText(str));
            if (dic_permission != null)
            {
                yield return PermissionTool.RequestPermission(dic_permission);
            }
#endif
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, ServerRedirect.LoadSettings()));
            //if(XD.tool.Debug.IsTagEnable("Loader"))Debug.Log(() => $"Request Server Over clock={Time.time}", Tag);
            //yield return new WaitForSeconds(wait_duration);

            //yield return new WaitForSeconds(wait_duration);
#if USE_HOT
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestHotFix()));
#endif
            //yield return new WaitForSeconds(wait_duration);
            Debug.Log(()=>$"Request DyData clock={Time.time}", Tag);
           
            //XDHotFix.Init(dydata);
                     
            yield return new WaitForSeconds(wait_duration);
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestHook()));
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestLoc()));
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestSDK()));
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestAnalytics()));
            string excute = "";
            StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestExcute((text)=>excute=text)));
            while (LoaderFunc.IsLoading())
            {
                //Debug.Log(() => $"LoadIndex={loadindex} End flag={Convert.ToString( end_flag,2)}",Tag);
                yield return new WaitForSeconds(wait_duration);
            }
            Debug.Log(() => $"Request Excute Start={Time.time}", Tag);
            yield return Excute(excute);
            Debug.Log(() => $"Request Excute Over={Time.time}", Tag);
            while (!is_anim_end || !next_scene)
            {
                //Debug.Log(() => $"LoadIndex={loadindex} End flag={Convert.ToString( end_flag,2)}",Tag);
                yield return new WaitForSeconds(wait_duration);
            }
            Debug.Log(()=>$"Request AllOver clock={Time.time}", Tag);
            //while (clock>0)
            //{
            //    yield return new WaitForSeconds(0.1f);
            //}
           
            //yield return new WaitForSeconds(wait_duration);

            //if (LogoType.Aboard == logo_type)
            //{
            //    yield return new WaitForAnimation(aboard, 0);
            //}
            //else
            //{
            //    yield return new WaitForAnimation(internel, 0);
            //}
           
            //while()
            //{
            //    yield return new WaitForSeconds(wait_duration);
            //}
            if (cheat_time > 0f)
            {
                yield return new WaitUntil(() =>
                {
                    cheat_time -= Time.deltaTime;
                    return cheat_time < 0f;
                });
            }
            Debug.Log(() => $"Loader LoadScene Start={Time.time}", Tag);
            int start_scene = Settings.Get<int>("Startup_Scene");
            if(start_scene==0)
            {
                start_scene = 1;
            }
            AsyncOperation sync = SceneManager.LoadSceneAsync(start_scene);
            yield return sync;

            Debug.Log(()=>$"Loader LoadScene Over={Time.time}", Tag);
           
        }

      

        private static bool CheckEnd()
        {

            return false;
        }

        private static IEnumerator Excute(string param)
        {
            if (string.IsNullOrEmpty(param))
            {
                yield  break;
            }
           
            string[] sp = param.Split('\n');
            for (int i = 0; i < sp.Length; ++i)
            {
                yield return ExcuteSingle(sp[i].Trim());
               
            }
        }
        private static IEnumerator ExcuteSingle(string param)
        {
           
            Debug.Log(() => $"ExcuteSingle={param}", Tag);
            if (string.IsNullOrEmpty(param))
            {
                yield break;
            }

            string[] sp = param.Split(':');
            string excute_assembly = sp[0];
            string excute_class = sp[1];
            string excute_function = sp[2];


            IEnumerator e= ReflectionTool.ExcuteStatic<IEnumerator>(excute_assembly, excute_class, excute_function);
            if(e!=null)
            {
                yield return e;
            }
            yield return new WaitForSeconds(wait_duration);
        }

  

    }
}