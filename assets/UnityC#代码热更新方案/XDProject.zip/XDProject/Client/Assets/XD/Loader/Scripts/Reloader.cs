﻿using System.Collections;
using UnityEngine;
using XD.Mono;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public static class Reloader
    {
        public const string Tag = "Reloader";
        // Start is called before the first frame update
        public static void Start(bool force_load)
        {
            CoroutineManager.GetInstance().StartCoroutine(Excute(force_load));           
        }

        private static IEnumerator Excute(bool force_load)
        {
            Debug.LogWarning(() => $"Reloader Excute Start", Tag);
            int loadindex = 0;
            CoroutineManager.GetInstance().StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, ServerRedirect.LoadSettings()));
#if USE_HOT
            CoroutineManager.GetInstance().StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestHotFix(force_load)));
#endif
            //yield return new WaitForSeconds(wait_duration);

            CoroutineManager.GetInstance().StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestHook(force_load)));
            CoroutineManager.GetInstance().StartCoroutine(LoaderFunc.LoadEnumerator(loadindex++, LoaderFunc.RequestLoc(force_load)));
            while(LoaderFunc.IsLoading())
            {
                yield return new WaitForSeconds(0.1f);
            }

            //yield return SceneManager.UnloadSceneAsync("reloader");
            yield return new WaitForSeconds(0.1f);
            ReloadOver();
        }
        public static void ReloadOver()
        {
            //SceneChangeTask sceneChangeTask = XD.tool.DataManager.Get<SceneChangeTask>("scene_change_task");
            //SceneChangeInfo scene_change = XD.tool.DataManager.Get<SceneChangeInfo>("scene_change_info");

            //sceneChangeTask.LoadScene(scene_change);
            //Debug.LogWarning(() => $"Reloader Excute Over", Tag);
        }
    }
}
