using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XD.tool;
using XD.Xml;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public partial class Loader : MonoBehaviour
    {
        // Start is called before the first frame update
        [SerializeField]
        private Image logo;
        [SerializeField]
        private Image bg;
        private class RXMLFrame:RxmlNode
        {
            [RxmlField]
            public string action;
            [RxmlField]
            public float delay;
            [RxmlField]
            public float duration;
        }
        private Strategy<string, RXMLFrame, IEnumerator> strategy;
        private class RxmlLogo: RxmlNode
        {
            [RxmlField]
            public RXMLFrame[] keyframe;
        }
        private const string res_dir = "Loader";
        private void PlayAnim()
        {
            strategy = new Strategy<string, RXMLFrame, IEnumerator>((v) => null);
            strategy.Regist("load", PlayLoad);
            strategy.Regist("scale", PlayScale);
            strategy.Regist("color", PlayColor);
            strategy.Regist("colorbg", PlayColorBG);
            strategy.Regist("end", PlayEnd);
            TextAsset text = Resources.Load<TextAsset>($"{res_dir}/anim");
            RxmlLogo logo = RxmlNode.SerializeXML<RxmlLogo>(text.text);
            //CollectionTool.ForAsc<RXMLFrame>(logo.keyframe, (i, key) => {
            //    StartCoroutine(PlayKeyFrame(key));
            //});
            StartCoroutine(PlayKeyFrame(logo));
        }
        private bool is_anim_end = false;
        private IEnumerator PlayEnd(RXMLFrame val)
        {
            is_anim_end = true;
            yield return null;
        }
        private const float delta_time = 0.02f;
        private const bool use_realtime = false;
        private IEnumerator PlayColor(RXMLFrame val)
        {
            Color from = val.GetAttribute<Color>("from");           
            logo.color = from;           
            if (val.duration > 0)
            {
                Color to = val.GetAttribute<Color>("to");
                Debug.Log(()=>$"PlayColor from={from} to={to},val.duration={val.duration}",Tag);
                ITweenFunction tween = new ITweenFunction();
                ITweenFunction.EaseType ease = val.GetAttribute<ITweenFunction.EaseType>("ease");
                tween.SetParam(0, 1, ease, val.duration);
                float last_time = Time.realtimeSinceStartup;
                float delta_total = 0;
                while (!tween.IsOver()&&delta_total<val.duration)
                {
                    float curr = Time.realtimeSinceStartup;
                    float real_delta = curr - last_time;
                    float delta = use_realtime? real_delta : delta_time;
                    last_time = curr;
                    delta_total += real_delta;
                    float t = tween.Update(delta);
                    Color c = Color.Lerp(from, to, t);
                    //UnityEngine.Debug.Log($"PlayAlpha t={t} c={c}");
                    logo.color = c;
                    
                    yield return new WaitForSeconds(delta_time);
                }
                Debug.Log(() => $"PlayColor delta_total={delta_total}", Tag);
            }
        }
        private IEnumerator PlayColorBG(RXMLFrame val)
        {
            Color from = val.GetAttribute<Color>("color");
            bg.color = from;
            bg.gameObject.SetActive(true);
            yield return null;
        }


        private IEnumerator PlayScale(RXMLFrame val)
        {
            Vector3 from = val.GetAttribute<Vector3>("from");
            logo.transform.localScale = from;
            if (val.duration > 0)
            {
                Vector3 to = val.GetAttribute<Vector3>("to");
                Debug.Log(()=>$"PlayScale from={from} to={to},val.duration={val.duration}",Tag);
                ITweenFunction tween = new ITweenFunction();
                ITweenFunction.EaseType ease = val.GetAttribute<ITweenFunction.EaseType>("ease");
                tween.SetParam(0, 1, ease, val.duration);
                float last_time = Time.realtimeSinceStartup;
                float delta_total = 0;
                while (!tween.IsOver() && delta_total < val.duration)
                {
                    float curr = Time.realtimeSinceStartup;
                    float real_delta = curr - last_time;
                    float delta = use_realtime ? real_delta : delta_time;
                    last_time = curr;
                    //Debug.Log(() => $"PlayScale delta={delta}", Tag);
                    delta_total += real_delta;
                    float t = tween.Update(delta);
                    Vector3 scale = Vector3.Lerp(from, to, t);
                    //UnityEngine.Debug.Log($"PlayScale t={t} scale={scale}");
                    logo.transform.localScale = scale;
                    yield return new WaitForSeconds(delta_time);
                }
                Debug.Log(() => $"PlayScale delta_total={delta_total}", Tag);
            }
            
        }

        private IEnumerator PlayLoad(RXMLFrame val)
        {
            string file = $"{res_dir}/{val.GetAttribute<string>("texture")}";
            logo.sprite = Resources.Load<Sprite>(file);
            RectTransform rect = logo.GetComponent<RectTransform>();
            if (val.HasAttribute("size"))
            {
                rect.sizeDelta = val.GetAttribute<Vector2>("size");
            }
            if(val.HasAttribute("fit"))
            {
                string size_fit = val.GetAttribute<string>("fit");
                if(size_fit== "Canvas")
                {
                    Canvas c = logo.canvas;
                    RectTransform rect_canvas = c.GetComponent<RectTransform>();
                    float size = Mathf.Max(rect_canvas.sizeDelta.x, rect_canvas.sizeDelta.y);
                    rect.sizeDelta = new Vector2(size, size);
                }
            }
            logo.gameObject.SetActive(true);
            yield return new WaitForSeconds(0.01f);
        }

        private IEnumerator PlayKeyFrame(RxmlLogo logo)
        {
            for (int i = 0; i < logo.keyframe.Length; ++i)
            {
                RXMLFrame key = logo.keyframe[i];
                if (key.delay > 0)
                {
                    yield return new WaitForSeconds(key.delay);
                }
                Debug.Log(() => $"Play Frame={i},xml={key.GetData()},Time={Time.time}", Tag);
                yield return strategy.Excute(key.action, key);
            }
            
        }
    }
}
