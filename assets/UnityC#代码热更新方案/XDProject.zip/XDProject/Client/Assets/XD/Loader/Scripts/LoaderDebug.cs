using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using wxb;
using XD.Hook;
using XD.Localization.Runtime;
using XD.Mono;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public partial class Loader : MonoBehaviour
    {
        //[SerializeField]
        //private Animator internel;
        //[SerializeField]
        //private Animator aboard;
        [SerializeField]
        private Button[] debug_buttons;
        [SerializeField]
        private GameObject debug_dialog;
        [SerializeField]
        private Button close_btn;
        [SerializeField]
        private GameObject debug_info;
        [SerializeField]
        private Text debug_info_text;
        [SerializeField]
        private Button debug_info_check;
        [SerializeField]
        private GameObject go_server_list;
        [SerializeField]
        private Dropdown drop_server_list;
        [SerializeField]
        private Button button_server_list;
        //private enum LogoType
        //{
        //    Internel,
        //    Aboard,
        //}
        //[SerializeField]
        //private LogoType logo_type;


        // Use this for initialization




        //public IEnumerator LoadThread(int index, Action action)
        //{
        //    end_flag &= ~(1 << index);

        //    yield return CoroutineManager.EnumeratorWithThread(action);

        //    end_flag |= 1 << index;
        //}



        private bool server_selected = false;
        private IEnumerator DebugServerList(List<string> list, string debug_server, Action<string> action)
        {
            go_server_list.SetActive(true);
            drop_server_list.ClearOptions();
            drop_server_list.AddOptions(list);
            int index = list.IndexOf(debug_server);
            drop_server_list.value = index >= 0 ? index : 0;
            button_server_list.onClick.AddListener(() => server_selected = true);
            while (!server_selected)
            {
                yield return null;
            }
            go_server_list.SetActive(false);
            string server = list[drop_server_list.value];
            action(server);


        }
        private void ShowServerInfo()
        {
            string server_info = Settings.Get("server_info");
            if (!string.IsNullOrEmpty(server_info))
            {
                debug_info.SetActive(true);
                if (server_info == "all")
                {
                    server_info = ServerRedirect.GetServerInfo();
                }
                debug_info_text.text = server_info;
                next_scene = false;
            }
        }
        private static int[][] Cheat_Words = new int[][] { new int[] { 0, 1, 2, 1, 2 }, new int[] { 1, 0, 2, 0, 2 }, new int[] { 0, 2, 1, 1, 2 },
                       new int[] { 0, 2, 1, 1, 2 ,1,1,2},new int[] { 1,0,2,0,0,1,2,1} };
        private CheatCheck cheat = new CheatCheck(Cheat_Words[0]);
        private float cheat_time = 0f;
        private void CheckDebug(int i)
        {

            if (ServerRedirect.IsDebugable())
            {
#if UNITY_EDITOR
                cheat_time += 1f;
#else
                cheat_time += 0.5f;
#endif
            }
            Debug.LogWarning(() => $"CheckPassword CheckDebug={i} cheat={cheat} cheat_time={cheat_time}", Tag);
            if (cheat.CheckPassword(i) && ServerRedirect.IsDebugable())
            {
                Debug.LogWarning(() => $"CheckPassword Enable={Time.time}", Tag);

                if (c != null)
                {
                    StopCoroutine(c);
                    c = null;
                }

                ServerRedirect.SetDebug();
                debug_dialog.SetActive(true);
            }



        }





        public static void ConfigLog()
        {
           
            string config = Settings.Get("log");
            Debug.Log(() => $"ConfigLog={config}", Tag);
            XD.tool.Debug.ClearTags();
            if (string.IsNullOrEmpty(config))
            {
                UnityEngine.Debug.unityLogger.logEnabled = false;
             
            }
            else
            {
                string[] sp = config.Split(':');
                UnityEngine.LogType l;
                bool res = System.Enum.TryParse<UnityEngine.LogType>(sp[0], out l);
                if (!res)
                {
                    UnityEngine.Debug.unityLogger.logEnabled = false;
                  
                    //XD.tool.Debug.SetTags(sp[1].Split(',', '|'), true);

                }
                else
                {
                    UnityEngine.Debug.unityLogger.logEnabled = true;
                    UnityEngine.Debug.unityLogger.filterLogType = l;
                    if (sp.Length > 1)
                    {                     
                        XD.tool.Debug.SetTags(sp[1].Split(',', '|'), true);
                    }
                }
            }
        }

    }
}