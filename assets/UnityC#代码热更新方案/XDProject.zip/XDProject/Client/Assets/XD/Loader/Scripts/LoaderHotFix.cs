﻿#if USE_HOT
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;
using wxb;
using XD.Hotfix;
using XD.tool;
using XD.Unity;
using AppDomain = ILRuntime.Runtime.Enviorment.AppDomain;
using Debug = XD.tool.Debug;


namespace XD.Loader
{
  
    public static partial class LoaderFunc 
    {
        public partial class DllLoader : IResLoad
        {
            private byte[] data;
            private int offset;
            private string rf;
            
            public DllLoader(byte[] data)
            {
                this.data = data;
                using (MemoryStream m = new MemoryStream(data))
                {
                    using (BinaryReader b=new BinaryReader(m))
                    {
                        int length =b.ReadInt32();
                        offset = 4 + length;
                        byte[] s = b.ReadBytes(length);
                        rf = System.Text.Encoding.UTF8.GetString(s);
                    }
                }
            }

            public Stream GetStream()
            {
                return new MemoryStream(data,offset,data.Length-offset);
            }

            public string GetXDRF()
            {
                return rf;
            }
        }
        public static void Init(byte[] data,string config, UnityEngine.RuntimePlatform rp)
        {

#if USE_HOT
            if (data != null)
            {
                data = XDCryptor.Decrypt(data);
            }
            //wxb.L.Set(null);
            DllLoader l = data != null ? new DllLoader(data) : null;
            //CrossBindingAdaptor[] cba = new CrossBindingAdaptor[] { new UnityHandleAdaptor() };
            wxb.hotMgr.Init(new XDILRegister(config), rp, l);
          
           
#else
        
#endif

        }
        public static UnityEngine.RuntimePlatform GetCurrentPlatform()
        {
#if UNITY_EDITOR
            switch (UnityEditor.EditorUserBuildSettings.activeBuildTarget)
            {
                case UnityEditor.BuildTarget.Android:
                    return UnityEngine.RuntimePlatform.Android;
                case UnityEditor.BuildTarget.iOS:
                    return UnityEngine.RuntimePlatform.IPhonePlayer;
                case UnityEditor.BuildTarget.StandaloneWindows:
                case UnityEditor.BuildTarget.StandaloneWindows64:
                    return UnityEngine.RuntimePlatform.WindowsPlayer;
            }
            return UnityEngine.Application.platform;
#else
            return UnityEngine.Application.platform;
#endif
        }
    
    }
}
#endif