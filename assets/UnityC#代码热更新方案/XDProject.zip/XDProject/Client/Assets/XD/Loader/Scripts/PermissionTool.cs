﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using XD.tool;
using XD.Unity;
using Debug = XD.tool.Debug;

namespace XD.Loader
{
    public static class PermissionTool
    {

        public static CommonUnityHandle permission;
        public static CommonUnityHandle dialog;

        public static IEnumerator RequestPermission(IDictionary dictionary)
        {
           
            if(permission==null) permission = new CommonUnityHandle("Permission");
            //UnityInteraction.Regist(permission);
            if(dialog==null) dialog = new CommonUnityHandle("Dialog");
            //UnityInteraction.Regist(dialog);
            bool permissiom_result = false;
            bool go_setting = false;
            string permission_request = CollectionTool.GetValue<string>(dictionary, "permission");
            string message= CollectionTool.GetValue<string>(dictionary, "message").Replace("\\n","\n").Replace("\\t","\t");
            string message2 = CollectionTool.GetValue<string>(dictionary, "message2").Replace("\\n", "\n").Replace("\\t", "\t");
            bool first_dialog = true;
            string help_url = CollectionTool.GetValue<string>(dictionary, "help_url");
            if (string.IsNullOrEmpty(message2))message2 = message;
            string positive = CollectionTool.GetValue<string>(dictionary, "positive");
            string neutral = CollectionTool.GetValue<string>(dictionary, "neutral");
            Debug.Log(() => $"RequestPermission {permission_request} message={message} button={positive}", Loader.Tag);
            Dictionary<string, object> check_param = new Dictionary<string, object>() { { "action", "check" }, { "permissions", permission_request } };

            Dictionary<string, object> per_param = new Dictionary<string, object>() { { "action", "request" }, { "permissions", permission_request } };
            Dictionary<string, object> dia_param = new Dictionary<string, object>() { { "message", message }, { "positive", positive },{ "neutral", neutral } ,{ "cancelable", false } };
            Dictionary<string, object> dia_param2 = new Dictionary<string, object>() { { "message", message2 }, { "positive", positive }, { "neutral", neutral }, { "cancelable", false } };

            Dictionary<string, object> setting_param = new Dictionary<string, object>() { { "action", "setting" } };
            bool has_error = false;
            yield return permission.RequestTask(check_param, (result, error) => {
                //AppResult($"Dialog Result={XD.MiniJSON.Json.Serialize(result)}");
                string str_result = CollectionTool.GetValue<string>(result, "result");
                if (str_result == "granted")
                {
                    permissiom_result = true;
                }
                has_error=!string.IsNullOrEmpty(error);;
                return true;
            });
            if(has_error)
            {
                yield break;

            }
            while (!permissiom_result)
            {
                yield return dialog.RequestTask(first_dialog?dia_param:dia_param2, (result, error) =>
                {
                    //AppResult($"Dialog Result={XD.MiniJSON.Json.Serialize(result)}");
                    string str_result = CollectionTool.GetValue<string>(result, "result");
                    if(str_result== "neutral")
                    {
                        Application.OpenURL(help_url);
                    }
                    return true;
                });
                first_dialog = false;
                if (go_setting)
                {
                    yield return permission.RequestTask(setting_param, (result, error) =>
                    {
                        string str_result = CollectionTool.GetValue<string>(result, "result");
                        if (str_result == "granted")
                        {
                            permissiom_result = true;
                        }
                        if (str_result == "request_fail")
                        {
                            go_setting = true;
                        }
                        //AppResult($"Permission Result={XD.MiniJSON.Json.Serialize(result)}");
                        return true;
                    });

                }
                yield return permission.RequestTask(per_param, (result, error) =>
                {
                    string str_result = CollectionTool.GetValue<string>(result, "result");
                    if (str_result == "granted")
                    {
                        permissiom_result = true;
                    }

                    go_setting = str_result == "request_fail";

                    //AppResult($"Permission Result={XD.MiniJSON.Json.Serialize(result)}");
                    return true;
                });
            }
        }
    }
}
