﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XD.Localization.Editor
{
    public class ParseCS : ParseBase
    {
        public ParseCS() : base()
        {
            dic_verify.Add("Debug", VerifyClear);
            dic_verify.Add("//", VerifyClear);
            dic_verify.Add("/*", VerifyClear);
            dic_verify.Add("ActivityLogger", VerifyClear);
            dic_verify.Add("Header(", VerifyClear);
            dic_verify.Add("Header (", VerifyClear);
            dic_verify.Add("MenuItem(", VerifyClear);
            dic_verify.Add("MenuItem (", VerifyClear);
            dic_verify.Add("Tooltip(", VerifyClear);
            dic_verify.Add("Tooltip (", VerifyClear);
            dic_verify.Add("Obsolete(", VerifyClear);
            dic_verify.Add("Obsolete (", VerifyClear);
            dic_verify.Add("AddComponentMenu(", VerifyClear);
            dic_verify.Add("AddComponentMenu (", VerifyClear);
            dic_verify.Add("System.Diagnostics.Conditional(", VerifyClear);
            dic_verify.Add("System.Diagnostics.Conditional (", VerifyClear);
            //dic_verify.Add("OutputLogToFile", VerifyClear);
            //dic_verify.Add(".Log(", VerifyClear);
        }

        public override bool Filter(string file)
        {
            //dic_process.Add(".cs",new ParseCS());
            //dic_process.Add(".json", new ParseCS());
            //dic_process.Add(".xml",new ParseCS());    
            return file.Contains(".cs") || file.Contains(".json") || file.Contains(".xml");
        }

        //public override ParseWord GetParse()
        //{
        //    return ParseDefault;
        //}

        public override int GetPriority()
        {
            return 10;
        }

        //public override VerifyFun GetVerify()
        //{
        //    return VerifyDefault;
        //}

        internal override LangSource Parse(string file,TextAsset src)
        {

            string[] srcs = LangCSFormat.SplitSrcs(src.text); 
            List<LangWord> list = new List<LangWord>();
            for (int i = 0; i < srcs.Length; ++i)
            {
                string line = srcs[i];
                List<LangWord> list_words = ParseDefault(line, i);
                VerifyDefault(list_words, line);
                if (list_words != null && list_words.Count > 0)
                {
                    //list.Add(new LangLine(i, list_words));
                    for(int j=0;j<list_words.Count;++j)
                    {
                        Dictionary<string, object> dic = new Dictionary<string, object>() { { "file", file }, { "line", i }, { "index", j } };
                        list_words[j].SetLocation(dic);

                    }
                    list.AddRange(list_words);
                }

            }
            return new LangSource(file,src, list,new ModifyCS(srcs));
        }
        public class ModifyCS : ModifyHandler
        {
            private string[] srcs;

            public ModifyCS(string[] srcs)
            {
                this.srcs = srcs;
            }

            public string ExcuteKey(LangFile f)
            {
                return f.NormalKey();
            }

            public void Modify(LangFile f, LangWord word)
            {
                //strting = string.Format("XD.Localization.Runtime.Localization.GetLocalization(\"{0}\")", f.key);
                if (word.text.StartsWith(XD.Localization.Runtime.Localization.Tag_Loc))
                {

                    //StringBuilder sb = new StringBuilder();
                    //int curr_length = 0;
                    //string str = srcs[f.line];
                    srcs[f.line] = srcs[f.line].Replace(word.text, f.key);
                    //srcs[f.line] = str;
                }
                else
                {
                    string new_string = string.Format(XD.Localization.Runtime.Localization.Func_Name, f.key);
                    //StringBuilder sb = new StringBuilder();
                    //int curr_length = 0;
                    //string str = srcs[f.line];
                    srcs[f.line] = srcs[f.line].Remove(word.start - 1, word.end - word.start + 2).Insert(word.start - 1, new_string);
                    srcs[f.line] = LangTool.FormatConst(srcs[f.line]);
                    //srcs[f.line] = str;
                }
            }

            public void Save(string file)
            {
                LangCSFormat.ModifySources(file, srcs);
            }
        }

    }


}