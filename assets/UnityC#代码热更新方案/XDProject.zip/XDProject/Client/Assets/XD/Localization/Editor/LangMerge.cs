﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using XD.Editor;
using XD.tool;

namespace XD.Localization.Editor
{
    public static class LangMerge
    {
        [MenuItem("本地化/文本/合并翻译")]
        public static void Merge()
        {
            //Debug.Log("開始時間 _" + System.DateTime.Now.ToString());
            //Debug.Log("Start Export UIPrefab Text to excel File!!");
            string file = LangMenu.OpenFile("选择原始Excel文件");
            if (string.IsNullOrEmpty(file))
            {
                return;
            }
            string file2 = LangMenu.OpenFile("选择要合并的Excel文件");
            if (string.IsNullOrEmpty(file2))
            {
                return;
            }
            bool over=XDEditorDialog.ShowDialog("是否覆盖?", "覆盖内容或者仅填充空白,", "覆盖", "填充空白");
            //LangImport imp = new LangImport(file);
            EditorCoroutineRunner.StartEditorCoroutine(MergeStart(file, file2,over));

        }

        private static IEnumerator MergeStart(string ori, string m,bool over)
        {
            EditorUtility.DisplayProgressBar($"正在启动", $"", 0);
            string log_path = $"{LangConstant.Excel_Path_Dir}/Logs/Lang_{DateTime.Now.ToString("yyyy_MM_dd_HH_mm")}.log";
            XDEditorLog.Start(log_path);
            ExcelReader er_merage = new ExcelReader(m);
            Dictionary<string, Dictionary<string, string>> merge_dic = new Dictionary<string, Dictionary<string, string>>();
            for (int i = 0; i < er_merage.GetSheetCount(); ++i)
            {
                yield return ReadMergeSheet(er_merage, i + 1, merge_dic);
            }
            ExcelReader er_ori = new ExcelReader(ori);
            for (int i = 0; i < er_ori.GetSheetCount(); ++i)
            {
                yield return WriteMergeSheet(er_ori, i + 1, merge_dic,over);
            }
            XDEditorLog.Flash();
            EditorUtility.ClearProgressBar();
        }

        private static IEnumerator WriteMergeSheet(ExcelReader er, int curr_sheet_index, Dictionary<string, Dictionary<string, string>> merge_dic,bool over)
        {
            er.SetSheet(curr_sheet_index);
            string sheet_name = er.GetSheetName();
            yield return new WaitForSeconds(0.1f);




            //LangLog.Log("Read Curr=" + i);
            int cell_index = 2;
            int total_count = er.GetCellsRows();
            while (cell_index < total_count)
            {
                string jpn = er.ReadCell(cell_index, LangType.JPN.ToString());
                Dictionary<string, string> word_dic = CollectionTool.GetValue<Dictionary<string, string>>(merge_dic, jpn);
                if (word_dic != null)
                {
                    CollectionTool.ForAsc<string, string>(word_dic, (key, value) =>
                    {
                        string v = er.ReadCell(cell_index, key);
                        if (string.IsNullOrEmpty(v)||over)
                        {
                            er.WriteCell(cell_index, key, value);
                        }
                    });


                }



                ++cell_index;
                //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
                if ((cell_index - 2) % 100 == 0)
                {
                    XDEditorLog.Log("读取数据 :" + (cell_index - 2) + "/" + (total_count - 2));
                    EditorUtility.DisplayProgressBar($"读取数据 :{sheet_name}", $"{cell_index - 2 }/ {total_count - 2}", 0);
                    yield return new WaitForSeconds(0.1f);
                }

            }
            er.Save();
            //dic_fs.Clear();
            //curr_sheet_index++;
            XDEditorLog.Log("读取表单结束:" + sheet_name);
        }

        private static IEnumerator ReadMergeSheet(ExcelReader er, int curr_sheet_index, Dictionary<string, Dictionary<string, string>> merge_dic)
        {
            er.SetSheet(curr_sheet_index);
            string sheet_name = er.GetSheetName();





            yield return new WaitForSeconds(0.1f);




            //LangLog.Log("Read Curr=" + i);
            int cell_index = 2;
            int total_count = er.GetCellsRows();
            while (cell_index < total_count)
            {
                string jpn = er.ReadCell(cell_index, LangType.JPN.ToString());
                Dictionary<string, string> word_dic = CollectionTool.GetValue<Dictionary<string, string>>(merge_dic, jpn);
                if (word_dic == null)
                {
                    word_dic = new Dictionary<string, string>();
                    merge_dic.Add(jpn, word_dic);
                }
             
                for (LangType l = LangType.JPN + 1; l < LangType.END; ++l)
                {
                    string value = er.ReadCell(cell_index, l.ToString());
                    if (!word_dic.ContainsKey(l.ToString()))
                    {
                        CollectionTool.Add(word_dic, l.ToString(), value);
                    }
                }

                ++cell_index;
                //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
                if ((cell_index - 2) % 100 == 0)
                {
                    XDEditorLog.Log("读取数据 :" + (cell_index - 2) + "/" + (total_count - 2));
                    EditorUtility.DisplayProgressBar($"读取数据 :{sheet_name}", $"{cell_index - 2 }/ {total_count - 2}", 0);
                    yield return new WaitForSeconds(0.1f);
                }

            }
            //dic_fs.Clear();
            //curr_sheet_index++;
            XDEditorLog.Log("读取表单结束:" + sheet_name);

        }
    }

}