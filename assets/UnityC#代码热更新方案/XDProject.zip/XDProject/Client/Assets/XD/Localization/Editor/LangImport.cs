﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEditor;
using XD.Editor;
using XD.tool;

namespace XD.Localization.Editor
{


    public static class LangImport
    {

        public const int Count_Read = 1000;
        public const int Count_Export = 100;
        public const int Count_Import = 100;

        private static ExcelReader er_export;
        private static ExcelReader er_source;
        private static Dictionary<LangType, StreamWriter> dic_sw;

        //public string ReadCell(int cell_index, string title)
        //{
        //    int col = GetCellsIndex(title);
        //    if (col > 0)
        //    {
        //        //                 Debug.Log("ReadCell cell_index = " + cell_index + "; col = " + col); 
        //        return cells[cell_index, col].Text;
        //    }
        //    return "";
        //}


        public static void ImportAll(string filepath, string dir_path)
        {

            //LangFunction l_create = new LangFunction(UpdateCreate, 1, "正在创建文件夹------------");


            //LangUpdate.Create(Over, new LangFunction[] { l_create });
            EditorCoroutineRunner.StartEditorCoroutine(RunImport(filepath, dir_path, () =>
            {
                AssetDatabase.ImportAsset(string.Format(LangConstant.Localization_Output_Dir, "Assets"), ImportAssetOptions.ImportRecursive | ImportAssetOptions.ForceUpdate);


            }));
        }

        public static IEnumerator RunImport(string filepath, string dir_path, Action over,string file2="")
        {
            dic_sw = new Dictionary<LangType, StreamWriter>();
            //dic_read_index = new Dictionary<string, int>();
            er_export = new ExcelReader(filepath);
            if (!string.IsNullOrEmpty(file2))
            {
                er_source = new ExcelReader(file2);
            }
            EditorUtility.DisplayProgressBar($"正在启动", $"", 0);
            string log_path = $"{LangConstant.Excel_Path_Dir}/Logs/Lang_{DateTime.Now.ToString("yyyy_MM_dd_HH_mm")}.log";
            XDEditorLog.Start(log_path);
            UpdateCreate(dir_path);
            for (int i = 0; i < er_export.GetSheetCount(); ++i)
            {
                yield return ImportSheet(i + 1, dir_path);
            }
            EditorUtility.ClearProgressBar();
            er_export = null;
            XDEditorLog.Flash();
            over?.Invoke();
        }

        private static IEnumerator ImportSheet(int curr_sheet_index, string dir_path)
        {

            //ExcelRange cells = param.Get<ExcelRange>("cells", null);
            er_export.SetSheet(curr_sheet_index);
            bool full = er_source == null;
            if (!full) er_source.SetSheet(curr_sheet_index);

            string sheet_name = er_export.GetSheetName();

            for (LangType i = LangType.JPN; i < LangType.END; ++i)
            {
                string file_path = string.Format(LangConstant.Localization_Output_File, dir_path, i,full? sheet_name:"fix");
                //FileStream file = File.Open(file_path, FileMode.OpenOrCreate);
                FileEX.DirCheckAndCreate(file_path);
                if (full)
                {
                    StreamWriter sw = File.CreateText(file_path);//new StreamWriter(file, System.Text.Encoding.Unicode);
                                                                 //dic_fs.Add(i, file);
                    dic_sw.Add(i, sw);
                }
                else
                {
                    StreamWriter sw =new StreamWriter(File.Open(file_path, FileMode.Append));//new StreamWriter(file, System.Text.Encoding.Unicode);
                                                                 //dic_fs.Add(i, file);
                    dic_sw.Add(i, sw);
                }
            }
            //param.Set("cells", cells);



            yield return new WaitForSeconds(0.1f);




            //LangLog.Log("Read Curr=" + i);
            int cell_index = 2;
            int total_count = er_export.GetCellsRows();
            while (cell_index < total_count)
            {
                string key = er_export.ReadCell(cell_index, "Key");
                //bool fix =!string.IsNullOrEmpty(er_export.ReadCell(cell_index, "Version"));
                if (!string.IsNullOrEmpty(key))
                {
                    for (LangType l = LangType.JPN; l < LangType.END; ++l)
                    {
                        string value = er_export.ReadCell(cell_index, l.ToString());
                        bool w = true;
                        if(er_source!=null)
                        {
                            string value_2= er_source.ReadCell(cell_index, l.ToString());
                            w = value != value_2||(string.IsNullOrEmpty(value_2)&&!string.IsNullOrEmpty(value));
                        }
                        if(w)
                        dic_sw[l].WriteLine(string.Format("{0}{2}{1}", key, value, XD.Localization.Runtime.Localization.Data_Split));
                    }
                }
                ++cell_index;
                //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
                if ((cell_index - 2) % 100 == 0)
                {
                    XDEditorLog.Log("读取数据 :" + (cell_index - 2) + "/" + (total_count - 2));
                    EditorUtility.DisplayProgressBar($"读取数据 :{sheet_name}", $"{cell_index - 2 }/ {total_count - 2}", 0);
                    yield return new WaitForSeconds(0.1f);
                }

            }


            foreach (StreamWriter sw in dic_sw.Values)
            {
                sw.Flush();
                sw.Close();
                
            }
           
            //foreach (FileStream sw in dic_fs.Values)
            //{
            //    sw.Flush();
            //    sw.Close();
            //}
            dic_sw.Clear();
            //dic_fs.Clear();
            //curr_sheet_index++;
            XDEditorLog.Log("读取表单结束:" + sheet_name);
            for (LangType i = LangType.JPN; i < LangType.END; ++i)
            {
                string file_path = string.Format(LangConstant.Localization_Output_File, dir_path, i, sheet_name);
                //FileStream file = File.Open(file_path, FileMode.OpenOrCreate);

                FileInfo file = new FileInfo(file_path);
                if(file.Exists&&file.Length==0L)
                {
                    file.Delete();
                }
            }

        }

        //private void ImportNext( )
        //{

        //    //l_export.param.Set("lang", lang);

        //    LangFunction l_read = new LangFunction(UpdateRead, Count_Read, "正在读取数据------------");
        //    LangLog.Log("ImportNext");

        //    LangUpdate.Create(Over, new LangFunction[] {l_read });
        //}

        private static void UpdateCreate(string dir_path)
        {
            //string dir_path = string.Format(LangConstant.Localization_Output_Dir, Application.dataPath);
            if (Directory.Exists(dir_path))
            {
                Directory.Delete(dir_path, true);
            }
            Directory.CreateDirectory(dir_path);
            for (LangType l = LangType.JPN; l < LangType.END; ++l)
            {
                Directory.CreateDirectory(dir_path + "/" + l);
            }
        }

        private static int GetCellsRows(ExcelRange cells)
        {
            int min = 1;
            int max = 100000;
            int center;
            while (min <= max)
            {
                center = (min + max) >> 1;
                string value = (string)cells[center, 1].Text;
                if (value == "#END")
                {
                    XDEditorLog.Log("获取表单总数=" + center);
                    return center;
                }
                else if (string.IsNullOrEmpty(value))
                {
                    max = center - 1;
                }
                else
                {
                    min = center + 1;
                }

            }
            XDEditorLog.Log("Out End");
            return (min + max) >> 1;
        }

        
    }
}