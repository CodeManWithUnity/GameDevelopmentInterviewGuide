﻿
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine;
using Excel;
using OfficeOpenXml;
using System;
using UnityEditor;
using System.Text.RegularExpressions;
using UnityEditor.SceneManagement;
using System.Text;
using System.IO;
using XD.Localization.Runtime;
using UnityEngine.SceneManagement;
using XD.tool;
using XD.Editor;
using XD.Editor.Finder;

namespace XD.Localization.Editor
{
  
    public class LangGameobjectTool
    {
        public static bool DoExport<T>(LangSheetBase<LangGameobject> sheet, GameObject obj, string path, Func<T, string> get, Action<T, string> set,string scene) where T : MonoBehaviour
        {
            T[] labels = obj.GetComponentsInChildren<T>(true);

            bool is_dirty = false;
            for (int j = 0; j < labels.Length; ++j)
            {
                //string str = LangTool.FilterString(labels[j].text);
                string str = get(labels[j]);
                str = LangWord.Format(str);
                LocalizationLabel l = labels[j].GetComponent<LocalizationLabel>();
                string oldkey = l != null ? l.key : "";
                if (string.IsNullOrEmpty(str) && string.IsNullOrEmpty(oldkey)|| str==LocalizationLabel.Replace_Value)
                {
                    continue;
                }
                string subpath = "", childpath = "";
                Transform root = null;
                LangGameobjectTool.GetSubPath(labels[j].transform, ref root, ref subpath, ref childpath);
                Dictionary<string, object> dic = new Dictionary<string, object>() { { "prefab", path }, { "subpath", subpath }, { "childpath", childpath }, { "scene", scene } };
              
               
                LangGameobject prefab = sheet.GetLangData(dic,str, oldkey); //GetLangPrefab(path, subpath, childpath);

              
                if(prefab!=null)
                {
                    //prefab.SetOri(str, LangType.JPN);
                    //prefab.SetLocation(dic);
                    prefab.UpdateKey();
                    if (true)
                    {
                        XDEditorLog.Log($"Prefab Label={str},dic={CollectionTool.Print(dic)}");
                        if (str != Localization.Runtime.LocalizationLabel.Replace_Value)
                        {
                            set(labels[j], Localization.Runtime.LocalizationLabel.Replace_Value);
                            is_dirty = true;
                        }
                        if (Localization.Runtime.LocalizationLabel.Attach(labels[j], prefab.key))
                        {
                            XDEditorLog.Log($"Attach={labels[j].name},prefab={prefab.key}");
                            //Localization.Runtime.LocalizationLabel.Attach(labels[j], prefab.key);
                            is_dirty = true;
                        }
                        else
                        {
                            XDEditorLog.Log($"NoAttach={labels[j].name},prefab={prefab.key}");
                        }
                    }
                }
            }
            return is_dirty;
        }
//        public static GameObject SearchChild(GameObject go, LangGameobject lg, ref LangBase.Flag flg)
//        {
//            //LangLog.Log("GetChild=" + go + "  " + lg.subpath + "  " + lg.childpath);
//            if (go == null)
//            {
//                XDEditorLog.Log("GetChild Null");
//                flg = LangBase.Flag.Lost_Source_Deleted;
//                return null;
//            }

//            if (string.IsNullOrEmpty(lg.childpath))
//            {
//                flg = LangBase.Flag.Lost_Loction_Info;
//                return go;
//            }
//            GameObject child = FindPath(go, lg.subpath, lg.childpath);
//            if (child != null)
//            {
//                LocalizationLabel loc_l = go.GetComponent<LocalizationLabel>();
//                if (loc_l != null && loc_l.key == lg.key)
//                {
//                    flg = LangBase.Flag.Fit_Key;
//                    return child;
//                }
//                flg = LangBase.Flag.Lost_Key;
//                string text = GetLabel(child);
//                text = LangWord.Format(text);
//                XDEditorLog.Log($"GetChild NoFindKey={lg.key}");
//                if (lg.lang_ori == text)
//                {
//                    flg = LangBase.Flag.No_Change;
//                    return child;
//                }
//                XDEditorLog.Log($"GetChild NoFindStr={lg.lang_ori},Label={text}");
//                flg = LangBase.Flag.Lost_Text;
//            }
//            else
//            {
//                XDEditorLog.Log($"No Child go={go}, At Path={lg.dic_location}");
//                flg = LangBase.Flag.Lost_Child;
//            }

//            LocalizationLabel[] labels = go.GetComponentsInChildren<LocalizationLabel>(true);
//            for (int i = 0; i < labels.Length; ++i)
//            {
//                if (labels[i].key == lg.key)
//                {
//                    flg = LangBase.Flag.Fit_Reloc_Key;
//                    return labels[i].gameObject;
//                }
//            }
//            XDEditorLog.Log($"GetChild NoFindKeyOther={lg.key}");
//            GameObject child2 = null;
//            SerachLabel(go,  (c, str) =>
//            {
//                if (lg.lang_ori.Equals(str)&&lg.subpath.EndsWith(c.name))
//                {
                  
//                    XDEditorLog.Log($"Fit_Reloc_Text={str}={lg.lang_ori}");
//                    child2 = c;
//                }
//            });
//            if(child2 != null)
//            {
//                flg = LangBase.Flag.Fit_Reloc_Text;
//                return child2;
//            }


//            return null;
//        }
//        public static void SerachLabel(GameObject root, Action<GameObject,string> action)
//        {
//#if LOCALIZATION_NGUI
//             SerachLabel<UILabel>(root, label => label.text,action);
             
//#endif
//#if LOCALIZATION_UGUI_PRO
//            SerachLabel<TMPro.TextMeshProUGUI>(root, label => label.text,action);
//#else
//             SerachLabel<Text>(root, label => label.text,action);             
//#endif
//        }
//        public static void SerachLabel<T>(GameObject root, Func<T,string> get, Action<GameObject,string> action)where T:Component
//        {
//            T[] t = root.GetComponentsInChildren<T>(true);
//            for(int i=0;i<t.Length;++i)
//            {
//                action(t[i].gameObject, get(t[i]));
//            }
//        }

//        private static string GetLabel(GameObject go)
//        {
//#if LOCALIZATION_NGUI
//              return GetLabel<UILabel>(go, label => label.text);
//#endif
//#if LOCALIZATION_UGUI_PRO
//            return GetLabel<TMPro.TextMeshProUGUI>(go, label => label.text);
//#else
//               return GetLabel<Text>(go, label => label.text);
//#endif
//        }

        //private static string GetLabel<T>(GameObject go, Func<T, string> p) where T : MonoBehaviour
        //{
        //    T t = go.GetComponent<T>();
        //    if(t!=null)
        //    {
        //        return p(t);
        //    }
        //    return "";
        // }

        //private static GameObject FindPath(GameObject go, string subpath, string child_path)
        //{
        //    string[] cd = child_path.Split('/');
        //    Transform p = go.transform; ;
        //    for (int i = 0; i < cd.Length; ++i)
        //    {
        //        int index = int.Parse(cd[i]);
        //        if (index < p.childCount)
        //        {
        //            p = p.GetChild(index);                  
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }
        //    string subpath2 = "", childpath2 = "";
        //    Transform root = null;
        //    GetSubPath(p, ref root, ref subpath2, ref childpath2);
        //    if (p != null && subpath2 == subpath)
        //    {
        //        return p.gameObject;
        //    }
        //    return null;
        //}

        public static void GetSubPath(Transform t, ref Transform root, ref string sub_path, ref string child_path)
        {

            if (t == null)
            {
                sub_path = "";
                child_path = "";
                return;
            }
            Transform parent = t.parent;
            if (parent == null)
            {
                root = t;
                sub_path = "";
                child_path = "";
                return;
            }
            string sub_path2 = "", child_path2 = "";
            GetSubPath(parent, ref root, ref sub_path2, ref child_path2);
            string selfname = t.name;


            sub_path = string.Format("{0}/{1}", sub_path2, selfname);

            if (string.IsNullOrEmpty(child_path2))
            {
                child_path = GetIndex(t);
            }
            else
            {
                child_path = string.Format("{0}/{1}", child_path2, GetIndex(t));
            }

        }
        private static string GetIndex(Transform t)
        {
            if (t == null)
            {
                return "";
            }
            Transform parent = t.parent;
            if (parent == null)
            {
                return "";
            }
            for (int i = 0; i < parent.childCount; ++i)
            {
                if (t == parent.GetChild(i))
                {
                    return i.ToString();
                }
            }
            return "";
        }

        internal static int Sort(LangGameobject l, LangGameobject r)
        {
            return l.key.CompareTo(r.key);
        }

        //internal static void Serach(LangGameobject t, GameObject go)
        //{
        //    LangBase.Flag flg= LangBase.Flag.None;
        //    GameObject child = SearchChild(go, t,ref flg);
        //    t.SetFlag(flg);
        //    if (child!=null)
        //    {
        //        t.is_lost = false;
        //        Transform root = null;
        //        string subpath = "", childpath = "";
        //        LangGameobjectTool.GetSubPath(child.transform, ref root, ref subpath, ref childpath);
        //        //this.subpath = subpath;
        //        //this.childpath = childpath;
        //        Dictionary<string, object> dic = new Dictionary<string, object>() { { "prefab", t.prefab }, { "subpath", subpath }, { "childpath", childpath }, { "scene", t.scene } };

        //        XDEditorLog.Log($"Serach Path={subpath},childpath={childpath}");
        //        t.SetLocation(dic);
        //    }
          
        //}
    }

    public class LangSceneSheet : LangSheetBase<LangGameobject>
    {
        public LangSceneSheet(string file) : base(file)
        {
        }

        protected override string GetSheetName()
        {
            return "Scenes";
        }

        protected override void ReadCallback(LangGameobject t)
        {
            //GameObject go = GameObject.Find(t.prefab);
            //LangGameobjectTool.Serach(t, go);
          
        }
        protected override void WriteCallback(LangGameobject t)
        {

        }
        private Dictionary<string, GameObject> dic_go = new Dictionary<string, GameObject>();
        private GameObject LoadAsset(string path)
        {
            if (dic_go.ContainsKey(path))
            {
                return dic_go[path];
            }
            else
            {
                GameObject obj = AssetDatabase.LoadAssetAtPath(path, typeof(GameObject)) as GameObject;
                dic_go.Add(path, obj);
                return obj;
            }
        }







        protected override int SortFuncEx(LangGameobject l, LangGameobject r)
        {           
            return LangGameobjectTool.Sort(l,r) ;
        }

        protected override IEnumerator UpdateExport()
        {
            Func<GameObject, string,string, bool> action = (obj, scene,root) =>
            {
                //ForeachLang((t) =>
                //{
                //    if (obj.name == t.prefab&&t.scene==scene_prefab)
                //    {
                //        LangGameobjectTool.Serach(t, obj);
                //    }                   
                //});

                bool is_dirty = false;
#if LOCALIZATION_NGUI
                is_dirty |= LangGameobjectTool.DoExport<UILabel>(this, obj, obj.name, label => label.text, (label, text) => label.text = text, scene);
#endif
#if LOCALIZATION_UGUI_PRO
                is_dirty |= LangGameobjectTool.DoExport<TMPro.TextMeshProUGUI>(this, obj, obj.name, label => label.text, (label, text) => {
                    label.SetMeshText(text);
                    label.Rebuild(CanvasUpdate.PreRender);
                }, scene);;
#else
                is_dirty |= LangGameobjectTool.DoExport<Text>(this, obj, obj.name, label => label.text, (label, text) => label.text = text, scene);
#endif
                return is_dirty;
            };

            yield return Traveral.ForeachBuildScene(action, false);
            //string curr_scene = EditorSceneManager.GetActiveScene().path;
            //EditorBuildSettingsScene[] scenes= EditorBuildSettings.scenes;
            //for(int i=0;i<scenes.Length;++i)
            //{
            //    yield return ExportScene(scenes[i].path);
            //}

            //EditorSceneManager.OpenScene(curr_scene, OpenSceneMode.Single);

        }

//        private IEnumerator ExportScene(string path)
//        {
//            XDEditorLog.Log("------------ExportScene=" + path);
//            UnityEngine.SceneManagement.Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
//            GameObject[] objs = scene.GetRootGameObjects();//.FindObjectsOfType<GameObject>();
//            List<GameObject> list_go = new List<GameObject>(objs);
//            //ForeachLang((t) =>
//            //{
//            //    GameObject go = list_go.Find((g) => g.name == t.prefab); //GameObject.Find(t.prefab);
//            //    LangGameobjectTool.Serach(t, go);
//            //}, (t) => t.scene == scene.name);

//            LangType lang = LangMenu.GetCurrLang();
//            int curr_index = 0;
//            while (curr_index < objs.Length)
//            {

//                GameObject obj = objs[curr_index];
//                bool is_dirty = false;
//#if LOCALIZATION_NGUI
//                is_dirty |= LangGameobjectTool.DoExport<UILabel>(this, obj, obj.name, label => label.text, (label, text) => label.text = text, scene.name);
//#endif
//#if LOCALIZATION_UGUI_PRO
//                is_dirty |= LangGameobjectTool.DoExport<TMPro.TextMeshProUGUI>(this, obj, obj.name, label => label.text, (label, text) => label.text = text, scene.name);
//#else
//                is_dirty |= LangGameobjectTool.DoExport<Text>(this, obj, obj.name, label => label.text, (label, text) => label.text = text, scene.name);
//#endif
         
//                if (is_dirty)
//                {
//                    EditorUtility.SetDirty(obj);
//                }
//                curr_index++;
//                yield return new WaitForSeconds(0.01f);
//            }

//            EditorSceneManager.SaveScene(scene);
//            //EditorSceneManager.UnloadScene(scene);
//        }

        private void CheckInvild(Scene scene,GameObject[] objs)
        {          
           
        }

        internal override void WriteOver()
        {

        }

     



        //protected override void UpdateImportOver(IParam p, LangFunction.State state)
        //{
        //    //if (state == LangFunction.State.Enter)
        //    //{
        //    //    EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
        //    //}
        //    if (state == LangFunction.State.Enter)
        //    {
        //        LangType lang = LangMenu.GetCurrLang();
        //        OutputLocFile(lang,string.Format( "/loc_{0}.txt", EditorSceneManager.GetActiveScene().name));
        //        //p.SetTotal(list_srcs.Count);
        //    }
        //    ////AssetDatabase.SaveAssets();
        //    //return EditorSceneManager.GetActiveScene().name;
        //}
    }


    public class LangPrefabSheet : LangSheetBase<LangGameobject>
    {
        
        public LangPrefabSheet(string file) : base(file)
        {
        }

        protected override string GetSheetName()
        {
            return "Prefabs";
        }
      
        protected override void ReadCallback(LangGameobject t)
        {
           
            ////LangLog.Log("ReadCallback=" + go + "   " + LangGameobjectTool.GetChild(go, t));
            //t.BindGameObject(LangGameobjectTool.GetChild(go, t));
            ////LangLog.Log(string.Format("读取了{0}条记录", list.Count), LangLog.Type.Log);
        }
        protected override void WriteCallback(LangGameobject t)
        {

        }


        //public LangGameobject GetLangPrefab(string path, string sub_path, string child_path)
        //{
        //    return list.Find((LangGameobject l) =>
        //    {
        //        return l.prefab == path && l.subpath == sub_path && l.childpath == child_path;
        //    });
        //}

    



        //protected override void UpdateImportOver(IParam p, LangFunction.State state)
        //{
        //    //if (state == LangFunction.State.Enter)
        //    //{
        //    //    AssetDatabase.SaveAssets();
        //    //}
        //    if (state == LangFunction.State.Enter)
        //    {
        //        LangType lang = LangMenu.GetCurrLang();
        //        OutputLocFile(lang, "/loc_prefab.txt");
        //        //p.SetTotal(list_srcs.Count);
        //    }
        //}
        protected override int SortFuncEx(LangGameobject l, LangGameobject r)
        {           
            return LangGameobjectTool.Sort(l, r);
        }
        private Dictionary<string, GameObject> dic_go = new Dictionary<string, GameObject>();
        private GameObject LoadAsset(string path)
        {
            //if(dic_go.ContainsKey(path))
            //{
            //    return dic_go[path];
            //}
            //else
            //{
                GameObject obj = AssetDatabase.LoadAssetAtPath(path, typeof(GameObject)) as GameObject;
                //dic_go.Add(path,obj);
                return obj;
            //}
        }

        //private List<GameObject> list_dirty = new List<GameObject>();

        protected override IEnumerator UpdateExport()
        {
            //ForeachLang((t) =>
            //{
            //    GameObject go = LoadAsset(t.prefab);
            //    LangGameobjectTool.Serach(t, go);
            //    //Resources.UnloadAsset(go);
            //    go = null;
            //});

            Func<GameObject, string, bool> action = (obj, scene_prefab) =>
            {
                //ForeachLang((t) =>
                //{
                //    if (t.prefab == scene_prefab)
                //    {
                //        LangGameobjectTool.Serach(t, obj);
                //    }
                //});

                bool is_dirty = false;
#if LOCALIZATION_NGUI
                            is_dirty |= LangGameobjectTool.DoExport<UILabel>(this, obj, scene_prefab, label => label.text, (label, text) => label.text = text, "");
#endif
#if LOCALIZATION_UGUI_PRO
                is_dirty |= LangGameobjectTool.DoExport<TMPro.TextMeshProUGUI>(this, obj, scene_prefab, label => label.text, (label, text) => label.SetMeshText(text),"");
#else
                            is_dirty |= LangGameobjectTool.DoExport<Text>(this, obj, scene_prefab, label => label.text, (label, text) => label.text = text, "");
#endif
                return is_dirty;
            };

            yield return Traveral.ForeachPrefab(LangConstant.Prefab_Directionay,action, false);
            //list_dirty.Clear();
//            string[] allpath = AssetDatabase.FindAssets("t:prefab", LangConstant.Prefab_Directionay);

//            XDEditorLog.Log($"Export Prefabs={allpath.Length}");
//            LangType lang = LangMenu.GetCurrLang();
//            int curr_index = 0;
//            int dirty_count = 0;
//            while (curr_index < allpath.Length)
//            {
//                System.DateTime start = System.DateTime.Now;
//                string path = AssetDatabase.GUIDToAssetPath(allpath[curr_index]);
//                //LangLog.Log($"Export Prefabs Index={curr_index},path={path}");
//                GameObject obj = LoadAsset(path);
//                bool is_dirty =false;
//#if LOCALIZATION_NGUI
//                is_dirty |= LangGameobjectTool.DoExport<UILabel>(this,obj, path, label => label.text, (label, text) => label.text = text,"");
//#endif
//#if LOCALIZATION_UGUI_PRO
//                is_dirty |= LangGameobjectTool.DoExport<TMPro.TextMeshProUGUI>(this, obj, path, label => label.text, (label, text) => label.text = text, "");
//#else
//                is_dirty |= LangGameobjectTool.DoExport<Text>(this,obj, path, label => label.text, (label, text) => label.text = text,"");              

//#endif                     
//                //list_dirty.Add(obj);
//                if (is_dirty)
//                {
//                    ++dirty_count;
//                    EditorUtility.SetDirty(obj);
                   
//                }
//                TimeSpan sp = DateTime.Now - start;
//                //LangLog.Log($"Export Prefabs Over={curr_index},path={path} TimeSpan={sp}");
//                ++curr_index;
//                // Resources.UnloadAsset(obj);
//                obj = null;
//                yield return new WaitForSeconds(0.01f);
//                if (dirty_count > 10)
//                {
//                    dirty_count = 0;
//                    AssetDatabase.SaveAssets();
//                    System.GC.Collect();
//                }

//            }
//            XDEditorLog.Log($"SaveAssets Start");
//            AssetDatabase.SaveAssets();
//            XDEditorLog.Log($"SaveAssets Over");
        }

        internal override void WriteOver()
        {
            //list_dirty.ForEach((obj) => EditorUtility.SetDirty(obj));
            //AssetDatabase.SaveAssets();
        }
    
    }


}