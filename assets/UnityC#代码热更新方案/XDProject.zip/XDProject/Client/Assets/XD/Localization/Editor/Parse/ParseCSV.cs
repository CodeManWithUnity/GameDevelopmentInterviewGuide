﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XD.Localization.Editor
{
    public class ParseCSV : ParseBase
    {
        private char[] delimiter = { ',', '\t' };
        private string[] header;
        private static List<string> list_header = new List<string>() {
            "title","body","text",
        };
        //static ParseCSV()
        //{
        //    int count = list_header.Count;
        //    for(int i=0;i< count; ++i)
        //    {
        //        list_header.Add(string.Format("\"{0}\"", list_header[i]));
        //    }
        //}
        public ParseCSV() : base()
        {

        }
        private List<LangWord> ParseCSVF(string line, int index)
        {

            string[] v = line.Split(delimiter);
            List<LangWord> words = new List<LangWord>();
            for (int i = 0; i < v.Length; ++i)
            {
                if (CheckHeader(i))
                {
                    int start = line.IndexOf(v[i]);
                    LangWord word = new LangWord(start, start + v[i].Length, v[i]);
                    words.Add(word);
                }
            }
            return words;

        }
        public bool CheckHeader(int index)
        {
            if (list_header.Contains(header[index]))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //public override ParseWord GetParse()
        //{
        //    return ParseCSVF;
        //}

        //public override VerifyFun GetVerify()
        //{
        //    return VerifyNone;
        //}

        public override int GetPriority()
        {
            return 100;
        }

        public override bool Filter(string file)
        {
            return file.EndsWith(".csv");
        }
        internal override LangSource Parse(string file, TextAsset src)
        {
            string[] srcs = src.text.Split('\n');
            List<LangWord> list = new List<LangWord>();
          

            header = srcs[0].Replace("\"", "").Split(delimiter);
            for (int i = 1; i < srcs.Length; ++i)
            {
                string line = srcs[i];
                List<LangWord> list_words = ParseCSVF(line, i);

                if (list_words != null && list_words.Count > 0)
                {
                    //list.Add(new LangLine(i, list_words));
                    for (int j = 0; j < list_words.Count; ++j)
                    {
                        Dictionary<string, object> dic = new Dictionary<string, object>() { { "file", file }, { "line", i }, { "index", j } };
                        list_words[j].SetLocation(dic);
                    }
                    list.AddRange(list_words);
                }
            }
            return new LangSource(file, src, list, new ModifyCSV(srcs));
        }
        public class ModifyCSV : ModifyHandler
        {
            private string[] srcs;

            public ModifyCSV(string[] srcs)
            {
                this.srcs = srcs;
            }

            public void Modify(LangFile f, LangWord word)
            {
                string str = srcs[f.line];

                string new_string;
                int fix = 0;

                new_string = f.key;
                str = str.Remove(word.start, word.end - word.start + fix).Insert(word.start, new_string);

                srcs[f.line] = str;
            }
            public string ExcuteKey(LangFile f)
            {
                return f.NormalKey();
            }
            public void Save(string file)
            {
                LangCSFormat.ModifySources(file, srcs);
            }
        }
    }


}