﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XD.Localization.Editor
{
    public class IParam
    {
        private Dictionary<string, object> param;
        public IParam()
        {
            param = new Dictionary<string, object>();
        }
        public TP Get<TP>(string key, TP default_value)
        {
            if (param.ContainsKey(key))
            {
                return (TP)param[key];
            }
            //Debug.Log("Get Default=" + default_value);
            return default_value;
        }

        public void Set(string key, object obj)
        {
            if (param.ContainsKey(key))
            {
                param[key] = obj;
            }
            else
            {
                param.Add(key, obj);
            }
        }

        private int step;
        private int total;
        private object obj;
        public int GetStep()
        {
            return step++;
        }
        public void SetTotal(int total)
        {
            this.total = total;
        }
        public bool IsEnd()
        {
            return step >= total;
        }
        public void SetObject(object obj)
        {
            this.obj = obj;
        }
        public T GetObject<T>()
        {
            return (T)obj;
        }
        public string Log(string desc)
        {
            if (total > 0)
            {
                return string.Format("{0}-------当前---{1}/{2}", desc, step, total);
            }
            else
            {
                return string.Format("{0}-------当前---{1}", desc, step);
            }
        }
    }
    public class LangFunction
    {

        public delegate void UpdateFunction(IParam p, State state);
        public UpdateFunction func;
        public IParam param;
        public string desc;
        public enum State
        {
            Enter,
            Run,
            Leave,
        }
        private int run_count = 1;
        public LangFunction(UpdateFunction func,int run_count, string desc)
        {
            this.func = func;
            this.run_count = run_count;
            if(run_count<1)
            {
                run_count= 1;
            }
            param = new IParam();
            this.desc = desc;
        }

        public bool Call(State state)
        {
            if(state== State.Leave)
            {
                Debug.Log("Call State Leave=" + func);
            }
            if (func != null)
            {
                int count = state == State.Run ? run_count : 1;
                for (int i = 0; i < count; ++i)
                {
                    //param.Log(desc);
                    func(param, state);
                    if( param.IsEnd())
                    {
                        return true;
                    }
                }
                return false;
            }
            return true;
        }
        public override string ToString()
        {
            return func.ToString();
        }

        internal string GetRunState()
        {
            return param.Log(desc);
        }
    }

    public class LangUpdate
    {
        private LangFunction[] curr_state;
        private int curr_state_index;

        public const long Duration_Log = 500 * 10000;
        public long clock_log = 0;

        public enum OverState
        {
            Complete,
            Exception,
            Cancel,
        }


        public static bool Is_Running = false;
        private System.Action<OverState> over;
       
        public LangUpdate(System.Action<OverState> over,  LangFunction[] states)
        {
            Debug.Log("開始時間 _" + System.DateTime.Now.ToString());
            this.over = over;
           
            UnityEditor.EditorApplication.update += Update;
            this.curr_state = states;
            this.curr_state_index = 0;
            if (curr_state_index < curr_state.Length)
            {
                curr_state[curr_state_index].Call(LangFunction.State.Enter);
            }
        }
        private void Update()
        {
            try
            {
                //for (int i = 0; i < count; ++i)
                {
                    if (curr_state != null && curr_state_index < curr_state.Length)
                    {
                        if (curr_state[curr_state_index].Call(LangFunction.State.Run))
                        {
                            Debug.Log("NextState:" + curr_state_index + "  " + curr_state.Length);
                            if (curr_state_index < curr_state.Length)
                            {
                                Debug.Log("CurrState Leave:" + curr_state_index + "  " + curr_state.Length);
                                curr_state[curr_state_index].Call(LangFunction.State.Leave);
                            }
                            curr_state_index++;
                            if (curr_state_index < curr_state.Length)
                            {
                                curr_state[curr_state_index].Call(LangFunction.State.Enter);
                            }
                        }
                    }
                    else
                    {

                        Over( OverState.Complete);
                        return;
                    }
                }
                if (curr_state != null && curr_state_index < curr_state.Length)
                {
                    long curr = System.DateTime.Now.Ticks;
                    if (curr - clock_log > Duration_Log)
                    {
                        clock_log = curr;
                        Debug.Log("运行中-----" + curr_state[curr_state_index].GetRunState() + "  " + System.DateTime.Now.ToString());
                    }
                }
            }
            catch (Exception e)
            {
                Over(OverState.Exception);
                Debug.LogError("Error:" + e);
            }
        }

        internal void Over(OverState e)
        {
            UnityEditor.EditorApplication.update -= Update;
            curr = null;
             Is_Running = false;
            if (over != null)
            {
                over(e);
            }
            Debug.Log("結束時間 _" + System.DateTime.Now.ToString());
        }
        private static LangUpdate curr ;
        internal static LangUpdate Create(System.Action<OverState> over,   LangFunction[] states)
        {
            if (Is_Running)
            {
                Debug.Log("正在运行中 请等待_" + System.DateTime.Now.ToString());
                return null;
            }
            Is_Running = true;
            return curr=new LangUpdate(over,  states);
        }
        public static void Stop()
        {
            if(curr!=null)
            {
                curr.over(OverState.Cancel);
            }
        }


    }
}