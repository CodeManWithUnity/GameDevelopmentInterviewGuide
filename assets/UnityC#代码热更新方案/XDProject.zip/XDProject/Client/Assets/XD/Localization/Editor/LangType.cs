using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using XD.Editor;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Editor
{
    public enum LangType
    {
        JPN = 0,
        CHS,
        CHT,       
        ENG,
        CHS_BS,
        END,
    }

    public static class LangConfig
    {
        //static Dictionary<Type, string[]> dic_title = new Dictionary<Type, string[]>();

        static LangConfig()
        {
            //dic_title.Add(typeof(LangFile), new string[] { "Path", "Postion", "Index" });
            //dic_title.Add(typeof(LangGameobject), new string[] { "Path", "Postion", "Index" });
        }



       
    }

    public abstract class LangBase
    {

        public enum Flag
        {
            None = 0,
            //Lost = 1 << 0,
          
            Repostion = 1 << 2,
            Lost_Source_Deleted = 1 << 3,
            Lost_Loction_Info = 1 << 4,
            Lost_Text = 1 << 5,
            Lost_Key = 1 << 6,          
            Lost_Child = 1 << 7,
            Fit_Key = 1 << 8,            
            Fit_Reloc_Key = 1 << 9,
            Fit_Reloc_Text = 1 << 10,

            Legacy = 1 << 11,
            Legacy_Reloc=1<<12,
            No_Change = 1 << 13,
            Clone = 1 << 14,           
            Append = 1 << 15,
            Modify = 1 << 16,
        }
        public static Flag Lost = Flag.Lost_Source_Deleted | Flag.Lost_Loction_Info| Flag.Lost_Text| Flag.Lost_Key;
        public Dictionary<string, object> dic_location;
        public string modified_info { get; protected set; }
        public Flag flag { get; protected set; }

        //public string[] lang_list;
        public bool is_lost;
        public string lang_ori;
        public Dictionary<string, string> lang_other;

        public string key;
        public LangBase()
        {
            lang_other = new Dictionary<string, string>();
            //lang_list = new string[(int)LangType.END];
            dic_location = new Dictionary<string, object>();
            flag = Flag.None;
        }

        public void SetLocation(Dictionary<string,object> dic)
        {
            //if(dic_location!=null&&dic_location.Count>0&& !CheckLocation(dic,dic_location))
            //{
            //    flag |= Flag.Repostion;
            //}
            dic_location = dic;
            is_lost = false;
        }

        public static bool CheckLocation(Dictionary<string,object> d1,Dictionary<string,object> d2)
        {
            if(d1==null||d2==null||d1.Count==0||d2.Count==0)
            {
                return false;
            }
            foreach (KeyValuePair<string, object> pair in d1)
            {
                if (!pair.Value.Equals(CollectionTool.GetValue<object>(d2, pair.Key)))
                {
                    return false;
                }
            }
            return true;
        }
        public static bool CheckLocation(Dictionary<string, object> d1, Dictionary<string, object> d2,string[] keys)
        {
            if (d1 == null || d2 == null || d1.Count == 0 || d2.Count == 0|| keys==null||keys.Length==0)
            {
                return false;
            }
            foreach (string key in keys)
            {
                object v1 = CollectionTool.GetValue<object>(d1, key);
                object v2 = CollectionTool.GetValue<object>(d2, key);

                if (!v1.Equals(v2))
                {
                    return false;
                }
            }
            return true;
        }





        public virtual void SetFlag(Flag f)
        {
            XDEditorLog.Log($"Change Flag={flag} To={f}");
            //XDEditorLog.Log($"Lost={CollectionTool.Print(dic_location)}");
            flag = f;
          
        }


        public void WriteCells(int cell_index, ExcelReader write)
        {
            //WriteInfo(cell_index, write);
            write.WriteCell(cell_index, "Key", key);
            write.WriteCell(cell_index, "Location", MiniJSON.Json.Serialize(dic_location));
            //cells[cell_index, lang_offset++].Value = modified_info;
            write.WriteCell(cell_index, "Modify", modified_info);
            write.WriteCell(cell_index, "Flag", FlagToString());
            write.WriteCell(cell_index, "JPN", lang_ori);
            //for (LangType i = LangType.JPN; i < LangType.END; ++i)
            //{
            //    //cells[cell_index, lang_offset ++].Value = lang_list[i];
            //    write.WriteCell(cell_index, i.ToString(), lang_list[(int)i]);
            //}
            foreach(KeyValuePair<string,string> pair in lang_other)
            {
                write.WriteCell(cell_index, pair.Key, pair.Value);

            }
        }
        public string  FlagToString()
        {
            //StringBuilder sb = new StringBuilder();
            //foreach(Flag f in Enum.GetValues(typeof (Flag)))
            //{
            //    CheckFlag(sb, f);
            //}
            ////CheckFlag(sb, Flag.Lost_Source_Deleted );
            ////CheckFlag(sb, Flag.Lost_Loction_Info);
            ////CheckFlag(sb, Flag.Lost_Key);
            ////CheckFlag(sb, Flag.Lost_Text);          
            ////CheckFlag(sb, Flag.Lost_Child);
            //return sb.ToString();
           return flag.ToString();
        }

        private void CheckFlag(StringBuilder sb, Flag f)
        {
            if ((flag & f) != Flag.None)
            {
                sb.Append(f.ToString());
                sb.Append(',');
            }
        }

        public void ReadCells(int cell_index, ExcelReader read)
        {
            string location = read.ReadCell(cell_index, "Location");
            if (string.IsNullOrEmpty(location))
            {
                dic_location = new Dictionary<string, object>();
                ReadInfo(cell_index, read);
            }
            else
            {
                dic_location = MiniJSON.Json.Deserialize(location) as Dictionary<string, object>;
            }
            //modified_info = read(cell_index, "Modify"); //(string)cells[cell_index, lang_offset++].Value;
            //is_lost = read(cell_index, "Lost") == "Lost";
            key = read.ReadCell(cell_index, "Key");
            lang_ori = read.ReadCell(cell_index, "JPN");
            //for (LangType i = LangType.JPN; i < LangType.END; ++i)
            //{
            //    lang_list[(int)i] = read.ReadCell(cell_index, i.ToString()); //(string)cells[cell_index, lang_offset ++].Value;
            //}
            lang_other = read.ReadOther(cell_index);
            SetFlag(Flag.Legacy);
        }

        //internal string ParseFlag()
        //{
        //    StringBuilder sb = new StringBuilder();
        //    if ((flag & LangBase. Lost) != Flag.None)
        //    {
        //        sb.Append("[丢失]");
        //    }
        //    if ((flag & Flag.Modify) != Flag.None)
        //    {
        //        sb.Append("[文字被修改]");
        //    }
         
        //    return sb.ToString();
        //}

        protected abstract void WriteInfo(int cell_index, ExcelReader write);
        protected abstract void ReadInfo(int cell_index,ExcelReader read);
        public void SetOri(string str, LangType lang)
        {
            if (str.StartsWith(Localization.Runtime.Localization.Tag_Loc)||str==Localization.Runtime.LocalizationLabel.Replace_Value)
            {
                return;
            }
            if(string.IsNullOrEmpty(str))
            {
                return;
            }
            //string lang_ori = lang_list[(int)lang];
            if (lang_ori != str)
            {
                if (!string.IsNullOrEmpty(lang_ori))
                {
                    flag = Flag.Modify;
                    modified_info = string.Format("旧数据:[{0}]\n新数据:[{1}]", lang_ori, str);
                }
               
            }
            lang_ori = str;
        }

        public abstract bool Compare(LangBase prefab);
      
    }





    public class LangGameobject : LangBase
    {
        public string prefab
        {
            get { return CollectionTool.GetValue<string>(dic_location, "prefab"); }
            private set { CollectionTool.Add(dic_location, "prefab", value); }
        }
        public string subpath
        {
            get { return CollectionTool.GetValue<string>(dic_location, "subpath"); }
            private set { CollectionTool.Add(dic_location, "subpath", value); }
        }

        public string childpath
        {
            get { return CollectionTool.GetValue<string>(dic_location, "childpath"); }
            private set { CollectionTool.Add(dic_location, "childpath", value); }
        }
        public string scene
        {
            get { return CollectionTool.GetValue<string>(dic_location, "scene"); }
            private set { CollectionTool.Add(dic_location, "scene", value); }
        }
        public GameObject go;

      
        

   

     

        protected override void ReadInfo(int cell_index,ExcelReader reader)
        {
            prefab = reader.ReadCell(cell_index, "Path"); //(string)cells[cell_index, 1].Value;
            subpath = reader.ReadCell(cell_index, "Postion");//(string)cells[cell_index, 2].Value;
            childpath = reader.ReadCell(cell_index, "Index");// (string)cells[cell_index, 3].Value;   
            scene = reader.ReadCell(cell_index, "Scene");
        }



        protected override void WriteInfo(int cell_index, ExcelReader write)
        {
            //cells[cell_index, 1].Value = prefab;
            //cells[cell_index, 2].Value = subpath;
            //cells[cell_index, 3].Value = childpath;
            //write.WriteCell(cell_index, "Path", prefab);
            //write.WriteCell(cell_index, "Postion", subpath);
            //write.WriteCell(cell_index, "Index", childpath);

        }

        internal bool UpdateKey()
        {           
            StringBuilder sb = new StringBuilder();
            sb.Append(Localization.Runtime.Localization.Tag_Loc);
            if(!string.IsNullOrEmpty(scene))
            {
                sb.Append(scene);
               
                sb.Append("_");
                Debug.Log("Append scene" + scene + "  " + sb.ToString());
            }
          
            string[] ps = prefab.Split('/','.');
            if (ps.Length > 1)
            {
                for (int i = 4; i > 2; --i)
                {
                    int index = ps.Length - i;
                    if (index >= 0)
                    {
                        string st = ps[index];
                        sb.Append(st);
                        sb.Append(".");
                    }
                }
                if (ps.Length >= 2)
                {
                    sb.Append(ps[ps.Length - 2]);
                }
            }
            else
            {
                sb.Append(ps[0]);
            }
          
            sb.Append(".");
            sb.Append(childpath);

            string new_key = sb.ToString();
            bool res = (key != new_key);
            Debug.Log(string.Format("Update Key=[{0}] To[{1}]", key, new_key));

            key = new_key;

            return res;
        }

        public override bool Compare(LangBase cp)
        {
            LangGameobject l = cp as LangGameobject;
            if(l==null)
            {
                return false;
            }
           if(l.prefab==prefab&&l.subpath==subpath&&l.childpath==childpath)
            {
                return true;
            }
            return false;
        }
    }



    public class LangFile : LangBase
    {
        public string file
        {
            get { return CollectionTool.GetValue<string>(dic_location, "file"); }
           private set { CollectionTool.Add(dic_location, "file", value); }
        }
        public int line
        {
            get { return CollectionTool.GetValue<int>(dic_location, "line"); }
            private set { CollectionTool.Add(dic_location, "line", value); }
        }
        public int index
        {
            get { return CollectionTool.GetValue<int>(dic_location, "index"); }
            private set { CollectionTool.Add(dic_location, "index", value); }
        }



        public override string ToString()
        {
            return string.Format("line={0},index={1},text={2},File={3}",line,index, lang_ori, file);
        }

        public string NormalKey()
        {
            //if (!string.IsNullOrEmpty(key))
            //{
            //    return false;
            //}
           
            //string new_key = string.Format("{0}{1}_{2}_{3}", Localization.Runtime.Localization.Tag_Loc, file, line, index);
            StringBuilder sb = new StringBuilder();
            sb.Append(Localization.Runtime.Localization.Tag_Loc);
            int start = file.Length;

            for (int i = 0; i < 2; ++i)
            {
                //Debug.Log(string.Format("Calc / count={0},Start={1},String={2}", i, start,file));
                int index = file.LastIndexOf("/", start - 2, start - 2);
                if (index >= 0)
                {
                    start = index + 1;
                }
                else
                {
                    break;
                }
            }

            int end = file.Length;
           
            if (start > end)
            {
                start = Mathf.Max(end - 5, 0);
            }
            sb.Append(file.Substring(start, end - start));
            sb.Append("_");
            sb.Append(line);
            sb.Append("_");
            sb.Append(index);
            //sb.Append("tt");
            string new_key = sb.ToString();
            return new_key;
        }

       
        protected override void ReadInfo(int cell_index, ExcelReader read)
        {

            file = read.ReadCell(cell_index, "Path"); //(string)cells[cell_index, offset++].Value;
            string r_l = read.ReadCell(cell_index, "Postion");
            string r_i = read.ReadCell(cell_index, "Index");
           
            if (!string.IsNullOrEmpty(r_l) && !string.IsNullOrEmpty(r_i))
            {
                line = int.Parse(r_l);//int.Parse((string)cells[cell_index, offset++].Value);
                index = int.Parse(r_i); //int.Parse((string)cells[cell_index, offset++].Value);

            }


        }
        protected override void WriteInfo(int cell_index, ExcelReader write)
        {
            //write.WriteCell(cell_index, "Path", file);
            //write.WriteCell(cell_index, "Postion", line.ToString());
            //write.WriteCell(cell_index, "Index", index.ToString());
         

            //cells[cell_index, offset++].Value = file;
            //cells[cell_index, offset++].Value = line.ToString();
            //cells[cell_index, offset++].Value = index.ToString();

        }


        //internal void UpdateLocation(Dictionary<string,object> dic)
        //{
        //    //string s ;
        //    //if (is_lost)
        //    //{
        //    //    s = string.Format("[重新找到]From{0}.{1}To{2}.{3}", line, index, i, j);
        //    //}
        //    //else
        //    //{
        //    //    s = string.Format("[重定向]From{0}.{1}To{2}.{3}", line, index, i, j);
        //    //}
        //    is_lost = false;
        //    //modified_info = string.Format("{0}\n{1}", s, modified_info);
        //    flag |= Flag.Repostion;
        //    //this.line = i;
        //    //this.index = j;
        //    SetLocation(dic);
        //}

        internal void SetFit()
        {
           if(is_lost)
            {
                is_lost = false;
                string s = string.Format("[重新找到]位置{0}.{1}", line, index);
                modified_info = string.Format("{0}\n{1}", s, modified_info);
            }
        }

        public override bool Compare(LangBase cp)
        {
            LangFile l = cp as LangFile;
            if (l == null)
            {
                return false;
            }
            if (l.file == file && l.index == index && l.line == line)
            {
                return true;
            }
            return false;
        }

        internal void SetSpilt()
        {
            string s = string.Format("[拆分]位置{0}.{1}", line, index);
            modified_info = string.Format("{0}\n{1}", s, modified_info);
        }
    }


}