﻿#if LOCALIZATION_EXPORT
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using XD.Localization.Runtime;

namespace XD.Localization.Editor
{

    public class CryptUtil
    {
        /// <summary>
        /// MD5Hashを作成
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string MakeMD5Hash(string path)
        {
            var md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            byte[] bytehash = md5.ComputeHash(fs);
            var s = BitConverter.ToString(bytehash).Replace("-", string.Empty);
            fs.Close();
            return s;
        }

        /// <summary>
        /// MD5Hashを作成
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string MakeMD5Hash(byte[] data)
        {
            var md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bytehash = md5.ComputeHash(data);
            return BitConverter.ToString(bytehash).Replace("-", string.Empty);
        }
    }

    public class CreateAssetBundle
    {

       
        [MenuItem("本地化/文本/导出文本资源包(当前平台)", false, 114)]
        static void BuildCurrPlatform()
        {
            if (EditorApplication.isPlaying)
            {
                EditorUtility.DisplayDialog("むっ", "ゲーム実行中は使用できません", "残念");
                return;
            }
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            BuildPlatform(target);
        }

        private static void BuildPlatform(BuildTarget target)
        {
            for (LangType l = LangType.JPN; l < LangType.END; ++l)
            {
                Debug.Log("##### windows");
                Caching.ClearCache();
                SetAssetBundleNames(l);

                BuildAllAssetBundles(target, l);
            }
        }

        [MenuItem("本地化/文本/导出文本资源包(所有平台)", false, 114)]
        static void BuildAllPlatform()
        {

            if (EditorApplication.isPlaying)
            {
                EditorUtility.DisplayDialog("むっ", "ゲーム実行中は使用できません", "残念");
                return;
            }
            if (!UnityEditor.EditorUtility.DisplayDialog("提示", "该操作要改变运行平台,确定要执行吗?", "确定", "取消"))
            {
                return;
            }

            Debug.Log("##### windows");
            Caching.ClearCache();
          
            //BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            //BuildAllAssetBundles(target, GetDir(target));

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.iOS, BuildTarget.iOS);
            BuildPlatform(BuildTarget.iOS);

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            BuildPlatform(BuildTarget.Android);

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, BuildTarget.StandaloneOSX);
            BuildPlatform(BuildTarget.StandaloneOSX);

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64);
            BuildPlatform(BuildTarget.StandaloneWindows64);

        }


        private static string GetPlatformString(BuildTarget target)
        {

            switch (target)
            {
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64:
                    return "windows";
                case BuildTarget.Android:
                    return "android";
                case BuildTarget.iOS:
                    return "ios";
                case BuildTarget.StandaloneOSX:
                    return "osx";
            }
            return "default";
        }
        private static string GetDir(BuildTarget target)
        {
            return string.Format("Localization/{0}", GetPlatformString(target));
        }


        private static void EnsureDirectory(string path)
        {
            Debug.Log(string.Format("EnsureDirectory {0} Exists{1}", path, Directory.Exists(path)));
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
            Directory.CreateDirectory(path);
        }

        static void cl()
        {
            string[] guids = AssetDatabase.FindAssets("", new string[] { "Assets" });
            List<string> guids_list = new List<string>();

            foreach (var f in guids)
            {
                guids_list.Add(f);

            }
            foreach (string f in guids_list)
            {
                string path = AssetDatabase.GUIDToAssetPath(f);
                string ext = Path.GetExtension(path);
                if (ext == ".cs" || ext == ".dll" || ext == ".js")
                {
                    continue;
                }
                AssetImporter.GetAtPath(path).assetBundleName = null;
            }
        }
        static void SetAssetBundleNames(LangType l)
        {
            if (EditorApplication.isPlaying)
            {
                EditorUtility.DisplayDialog("むっ", "ゲーム実行中は使用できません", "残念");
                return;
            }

            cl();
           
            string import_path = string.Format(LangConstant.Localization_Output_Dir, "Assets")+"/"+l;
          
            string[] guids = AssetDatabase.FindAssets("t: TextAsset", new string[] { import_path });
            Debug.Log("import_path=" + import_path+"  "+ guids.Length);
            List<string> guids_list = new List<string>();
            foreach (var f in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(f);

                if (path.Contains(".meta"))
                {
                    continue;
                }

                //int depth = path.Length - path.Replace("/", "").Length;

                //if (path == import_path)
                //{
                //    continue;
                //}

                //if (3 == depth && Directory.Exists(Application.dataPath.Replace("Assets", "") + path))
                //{
                //    continue;
                //}

                //if (5 <= depth)
                //{
                //    continue;
                //}


                guids_list.Add(f);
            }

            foreach (string f in guids_list)
            {
                string path = AssetDatabase.GUIDToAssetPath(f);
                string bundle_name = Path.GetFileNameWithoutExtension(path);
                Debug.Log("bundle_name=" + bundle_name);
                AssetImporter.GetAtPath(path).assetBundleName = bundle_name;
            }

            AssetDatabase.RemoveUnusedAssetBundleNames();
            Debug.Log("Marvelous.");
        }
        static void BuildAllAssetBundles(BuildTarget target,LangType l)
        {
         
            string dirName = GetDir(target);
            Debug.Log($"[{DateTime.Now.ToLongTimeString()}]: -----PopBackupAssetBundles-----");
            string path = Path.Combine(Application.dataPath, "..", "AssetBundles", dirName,l.ToString());
            EnsureDirectory(path);


            Debug.Log($"[{DateTime.Now.ToLongTimeString()}]: -----BuildPipeline.BuildAssetBundles-----");
            AssetBundleManifest manifest = BuildPipeline.BuildAssetBundles(path, BuildAssetBundleOptions.IgnoreTypeTreeChanges, target);

            Debug.Log($"[{DateTime.Now.ToLongTimeString()}]: manifest=" + manifest);


            // マニフェストファイルの作成＆暗号化
            CreateManifestAndEncrypt(path);

            Debug.Log("##### finish manifest(AssetBundles" + target + ")");



        }

        static List<string> GetTargetsFiles(string path)
        {
            Debug.Log("input path: " + path);

            // 対象となるファイルを取得(manifest, ds_store, metaを除く)
            var fileList = Directory.GetFiles(path, "*", SearchOption.AllDirectories)
                .Where(fn => {
                    return !(Path.GetExtension(fn).Equals(".manifest")
                                 || Path.GetExtension(fn).Equals(".DS_Store")
                                 || Path.GetExtension(fn).Equals(".meta")
                                 || Path.GetDirectoryName(fn).EndsWith(".backup"));
                })
                .ToList();

            Debug.Log("file count: " + fileList.Count);
            return fileList;
        }
        static LocalizationAssetList MakeManifestList(string basePath, List<string> fileList)
        {
            LocalizationAssetList list = new LocalizationAssetList();
            foreach (var filePath in fileList)
            {
                var info = new Runtime.LocalizationAsset();
#if UNITY_EDITOR_OSX
                info.name = filePath.Replace(basePath, "").TrimStart('/');
#elif UNITY_EDITOR_WIN
                info.name = filePath.Replace(basePath, "").TrimStart('\\');
#endif
                info.hash = CryptUtil.MakeMD5Hash(filePath);

                info.size = new FileInfo(filePath).Length;
                uint crc = 0;

                BuildPipeline.GetCRCForAssetBundle(filePath, out crc);
                info.crc = crc;

                list.AddOrUpdate(info);
            }

            return list;
        }
        private static void CreateManifestAndEncrypt(string path)
        {
            // 入力ベースpathを作成


            // 対象となるファイルを取得
            var fileList = GetTargetsFiles(path);

            // ベースとなるDLマニフェスト情報を作成
            var manifestData = MakeManifestList(path, fileList);



            // 出力用manifestファイルを作成
            string manifestJson = MakeManifestJson(manifestData);

            // ファイル書き出し処理(出力先はTargetのディレクトリと並列にする)
            WriteManifestJson(path + "/asset.json", manifestJson);
        }
        static string MakeManifestJson(LocalizationAssetList infoList)
        {

            return JsonUtility.ToJson(infoList);
        }
        static void WriteManifestJson(string path, string manifestJson)
        {
            File.WriteAllText(path, manifestJson);
            Debug.Log("write manifest: " + path);
        }
    }
}
#endif