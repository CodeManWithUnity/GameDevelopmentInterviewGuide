﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;
using XD.tool;

using XD.Editor;
using XD.Editor.Build;

namespace XD.Localization.Editor
{
    public class ExcelToZip
    {

        [MenuItem("本地化/文本/Excel导出Zip")]
        public static void Export()
        {
            //Debug.Log("開始時間 _" + System.DateTime.Now.ToString());
            //Debug.Log("Start Export UIPrefab Text to excel File!!");
            string file = OpenFile("zip_export");
            if (string.IsNullOrEmpty(file))
            {
                return;
            }
            string dir_path = $"{LangConstant.Excel_Path_Dir}/Generate/Source";

            bool full = XDEditorDialog.ShowDialog("提示", "选择导出模式", "全量", "增量");
            string file2 = "";
            if (!full)
            {
                file2 = OpenFile("zip_source");
                if (string.IsNullOrEmpty(file2))
                {
                    return;
                }
            }
            EditorCoroutineRunner.StartEditorCoroutine(LangImport.RunImport(file,dir_path,ExportZip, file2));
        }

        private static void ExportZip()
        {
            string version = DateTime.Now.ToString("yyyyMMddHHmmss");
            for (LangType l = LangType.JPN; l < LangType.END; ++l)
            {
                string dir= $"{LangConstant.Excel_Path_Dir}/Generate/Source/{l.ToString()}";
                string target= $"{LangConstant.Excel_Path_Dir}/Generate/Target/{l.ToString()}.zip";
                XDZip.Archieve(target, dir, Localization.Runtime.Localization.Zip_Password, 5);              
                FileEX.WriteAllText($"{target}_ver", version);
            }
            string path = BuildTool.GetPath($"../../LanguageFiles/Generate/Target").Replace("/", "\\");
            UnityEngine.Debug.Log($"Path={path}");
            System.Diagnostics.Process.Start("explorer.exe", path);
        }

        public static string OpenFile(string key)
        {
            string file = XDEditorDialog.OpenFilePanel("选择Excel文件", key, "xlsx");
            return file;
            //return EditorUtility.OpenFilePanel("选择Excel文件", GetExcelDir(), "xlsx");
        }
    }
}