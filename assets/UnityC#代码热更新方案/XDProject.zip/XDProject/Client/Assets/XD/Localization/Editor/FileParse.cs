﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Editor
{

    public class LangWord
    {
        public int start;
        public int end;
        public string text;
        public Dictionary<string, object> dic_location;

        public LangWord(int start, int end, string text)
        {
            this.start = start;
            this.end = end;
            this.text =Format( text);
        }
        public void SetLocation(Dictionary<string, object> dic_location)
        {
            this.dic_location = dic_location;
        }
        public override string ToString()
        {
            return string.Format("start={0},end={1},text={2}",start,end,text);
        }
        public static string Format(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return s;
            }
            return s.Replace("\n", "\\n").Replace("\r", "");
        }
    }
    //public class LangLine
    //{
    //    public int line;
    //    public List<LangWord> words;

    //    public LangLine(int line, List<LangWord> words)
    //    {
    //        this.line = line;
    //        this.words = words;
    //    }
    //}



    public static class ParseManager
    {
        //public static Dictionary<string, ParseBase> dic_process;
        public static List<ParseBase> process;
        static ParseManager()
        {
            Debug.Log("ParseManager Static Init");
            //dic_process = new Dictionary<string, ParseBase>();
            //dic_process.Add(".csv", new ParseCSV());
            //dic_process.Add(".cs",new ParseCS());
            //dic_process.Add(".json", new ParseCS());
            //dic_process.Add(".xml",new ParseCS());          
            //dic_process.Add("e.lua.txt",new ParseLua());
            //dic_process.Add("e.txt", new ParseLua());
            //dic_process.Add("e.lua..txt", new ParseLua());
            //dic_process.Add("e.lua.txt.txt", new ParseLua());
            //dic_process.Add(".lua.txt", new ParseLua());
            //dic_process.Add("LuaRoot", new ParseLua());

            process = new List<ParseBase>();
          
            Assembly assembly = Assembly.GetExecutingAssembly(); // 获取当前程序集 
            var subTypeQuery = from t in assembly.GetTypes()
                               where IsSubClassOf(t, typeof(ParseBase))
                               select t;
            Debug.Log("Load subTypeQuery：" + subTypeQuery.Count());
            foreach (Type type in subTypeQuery)
            {
                ParseBase p = (ParseBase)assembly.CreateInstance(type.FullName);
                process.Add(p);
                Debug.Log("Load Commond：" + type.Name + "  Plugin:" + p);
            }
            process.Sort((l, r) => { return r.GetPriority() - l.GetPriority(); });
            //dic_process.Add("default", new VerifyCS());
        }

        static bool IsSubClassOf(Type type, Type baseType)
        {
            //Debug.Log("IsSubClassOf:" + type + "  " + baseType);
            if (baseType.IsInterface)
            {
                foreach (var t in type.GetInterfaces())
                {
                    if (t == baseType||t.IsSubclassOf(baseType))
                    {
                        return true;
                    }
                }
                return false;
            }
            else
            {
                return type.IsSubclassOf(baseType);
            }
        }

        internal static LangSource Parse(string file, TextAsset src)
        {
            ParseBase parse = GetProcess(file);
            if(parse==null)
            {
                Debug.Log("No verify With File:" + file);
                return null;
            }
            return parse.Parse(file,src);
         

        }

        public static ParseBase GetProcess(string file)
        {
            //foreach(KeyValuePair<string, ParseBase> pair in dic_process)
            //{
            //    if(file.IndexOf(pair.Key)>=0)
            //    {
            //        return pair.Value;
            //    }
            //}
            for(int i=0;i<process.Count;++i)
            {
                if(process[i].Filter(file))
                {
                    return process[i];
                }
            }
            return null;
        }
    }





    public abstract class ParseBase
    {

        public interface ModifyHandler
        {
            void Modify(LangFile f, LangWord word);
            void Save(string file);
            string ExcuteKey(LangFile f);
        }

        protected delegate void VerifyBasec(List<LangWord> words,int index);
        //public delegate void VerifyFun(List<LangWord> words,string line);
        //public delegate List<LangWord> ParseWord(string line,int line_index);
        protected Dictionary<string, VerifyBasec> dic_verify;

        public ParseBase()
        {
            dic_verify = new Dictionary<string, VerifyBasec>();
        }
        //public abstract ParseWord GetParse();
        //public abstract VerifyFun GetVerify();


        protected static List<LangWord> ParseDefault(string line,int line_index)
        {
            List<int> list = ParseSymbol(line, -1);
            List<LangWord> words = ParseIndex(line, list);
           
            //return CombineWords(words, line);        
            return words;
        }
        protected static List<int> ParseSymbol(string line, int start_index)
        {
            if(start_index+1>line.Length)
            {
                return null;
            }
            int index = start_index;
            List<int> list = new List<int>();
            bool is_start = true;
            while ((index = line.IndexOf("\"", index + 1)) >= 0)
            {
                if (index<1||line[index - 1] != '\\')
                {
                    list.Add(is_start ? index + 1 : index);
                    is_start = !is_start;
                }
               
            }

            return list;
        }

        protected static List<LangWord> ParseIndex(string line, List<int> list)
        {
            if (list == null)
            {
                return null;
            }
            List<LangWord> words = new List<LangWord>();

            for (int i = 0; i < list.Count >> 1; ++i)
            {
                int start = list[i << 1];
                int end = list[(i << 1) + 1];
                string str = line.Substring(start, end - start).Replace("\r", "");

                //if (!string.IsNullOrEmpty(str))
                {
                    words.Add(new LangWord(start, end, str));
                }
            }

            return words;
        }

        public void VerifyDefault(List<LangWord> words, string line)
        {
            if(words==null||words.Count<1)
            {
                return;
            }
            for (int i = words.Count - 1; i >= 0; --i)
            {
                string str = line.Substring(0, words[0].start);
                bool fit = false;
                foreach (KeyValuePair<string, VerifyBasec> pair in dic_verify)
                {
                    if (str.IndexOf(pair.Key) >= 0)
                    {
                        //Debug.Log("VerifyDefault Fit="+ pair.Key+"  " + line+"  "+words[i]);
                        pair.Value(words,i);
                        fit = true;
                        break;
                    }
                }
                if (!fit)
                {
                    VerifyDefault(words, i);
                }
            }
        }

        protected void VerifyClear(List<LangWord> words,int index)
        {
            if (words != null)
            {
                //Debug.Log("VerifyClear=" + words[index]);
                words.RemoveAt(index);
            }
            
        }


        protected void VerifyDefault(List<LangWord> words, int i)
        {

            if (!LangTool.IsJPN(words[i].text)&& (!words[i].text.StartsWith(Localization.Runtime.Localization.Tag_Loc)))
            {
                //Debug.Log("VerifyDefault Remove=" + words[i].text);
                words.RemoveAt(i);
            }

        }

        protected void VerifyNone(List<LangWord> words, string line)
        {

        }

        public abstract int GetPriority();

        public abstract bool Filter(string file);

        internal abstract LangSource Parse(string file, TextAsset src);
    }



 
 

  
}
