using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Runtime
{
    public static class StringTool
    {
        public static string Tag = "StringTool";
        public static string FormatEndNumber(int v)
        {
            StringBuilder sb = new StringBuilder();
            if(v<10)
            {
                sb.Append("    ");
            }
            else if(v<100)
            {
                sb.Append("  ");
            }
            sb.Append(v);
            return sb.ToString();
        }

        public static string SplitText(string str, int max_char,int max_line=4)
        {
            StringBuilder sb = new StringBuilder();
            str = str.Replace("/", "\n").Replace("\\","\n");//.Replace("\n", "");
            int line_start = 0;
            int i = 0;
            int except_line = 0;
            int line_count=0;
            bool flag_line = true;
            int line_flag = 0;
            while (i < str.Length)
            {
                if (str[i] == '\n')
                {
                   
                    int leng = i - line_start + 1;
                    if (leng > 0)
                    {
                        ++line_flag;
                        if (leng > 1 && IsPunctuation(str[i - 1]) && flag_line)
                        {
                            if (except_line == 0)
                            {
                                sb.Append(str.Substring(line_start, leng));
                            }
                            else
                            {
                                sb.Append(str.Substring(line_start, leng).Replace("\n", ""));
                                sb.Append("\n");
                            }
                            //if(XD.tool.Debug.IsTagEnable("StringTool"))Debug.Log("Append Line=" + str.Substring(line_start, leng) + "  " + Char.IsPunctuation(str[i - 1]) + "  " + leng);
                            line_start = i + 1;
                            ++line_count;
                            except_line = 0;
                        }
                        else
                        {
                            except_line++;
                        }
                    }
                    else
                    {
                        line_start = i + 1;
                    }
                }
                if (i - line_start - except_line >= max_char)
                {
                    //flag_line = false;
                    int end_p = IsPunctuation(str[i]) ? 1 : 0;

                    int leng = i - line_start + end_p;
                    //if(XD.tool.Debug.IsTagEnable("StringTool"))Debug.Log("SplitText line=" + i +" char= "+str[i] + " " + line_start + "  " + except_line + "  " + end_p+"   "+leng+"  "+str.Length);
                    sb.Append(str.Substring(line_start, leng).Replace("\n", ""));
                    if (i != str.Length - 1)
                    {
                        sb.Append("\n");
                    }
                    ++line_count;
                    line_start = i+end_p;
                    except_line = 0;

                }
                else
                {
                    ++i;
                }
                if(i== str.Length)
                {
                    int leng = i - line_start ;
                    if(leng>0)
                    {
                        sb.Append(str.Substring(line_start, leng).Replace("\n", ""));
                        ++line_count;
                    }
                }
                
            }
            int max_line_count = (str.Length - 1-line_flag) / max_char + 1;
            if(XD.tool.Debug.IsTagEnable("StringTool"))Debug.Log(()=>"SplitText=" + str + "  sb=" + sb.ToString(),Tag);
            if(XD.tool.Debug.IsTagEnable("StringTool"))Debug.Log(()=>"line_count=" + line_count + "  max_line_count=" + max_line_count,Tag);
            string res = sb.ToString();
            if(line_count>max_line_count+1||line_count> max_line)
            {
                res = res.Replace("\n", "");
            }
            return res; 
        }
        private static char[] End_Punctuation = new char[]
            {'.', ',','，', '。',':','?','？'};

        private static bool IsPunctuation(char v)
        {
            for(int i=0;i<End_Punctuation.Length;++i)
            {
                if(v==End_Punctuation[i])
                {
                    return true;
                }
            }
            return false;
        }

        public static string FormatPurchase(int priceValue)
        {
            if (priceValue > 100)
            {
                return (priceValue / 100).ToString("F0");
            }
            else
            {
               return (priceValue * 0.01f).ToString("F2"); //shopItem.priceValue.ToString("N0");
            }
        }
    }
}