using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Runtime
{
    public static class Localization
    {
        public static string Zip_Password = "z2A&4X0xOQKwCa7r2%MhTb@Z8";
        //public enum LangType
        //{
        //    JPN = 0,
        //    CHS,
        //    CHT,
        //    ENG,
        //    CHS_BS,
        //    END,
        //}

        //#if LANG_CHT
        //         public  const string Lang= "CHT";
        //#elif LANG_CHS
        //         public  const string Lang= "CHS";
        //#elif LANG_ENG
        //         public  const string Lang= "ENG";
        //#elif LANG_JPN
        //        public const string Lang = "JPN";
        //#else
        //        public const string Lang = "JPN";
        //#endif
        public static string Lang;
        public const string Func_Name = "XD.Localization.Runtime.Localization.GetLocalization(\"{0}\")";
        public static string Path_Resources_Local { get { return "Localization/" + Lang; } }
        public const char Data_Split = '=';
        public const string Tag_Loc = "Loc_";
        private static Dictionary<int, string>[] dic;
        private static List<string> name_list;
        private static List<string> name_bundles;

        private const int Init_Capacity = 30000;

        private const int Max_Dic_Count = 1 << 8;
        private const int Sub_Capacity = Init_Capacity / Max_Dic_Count;
        private const int Mask = (Max_Dic_Count - 1);
        private static bool is_load_res;
        static Localization()
        {
            is_load_res = false;
            dic = new Dictionary<int, string>[Max_Dic_Count];

            for(int i=0;i<dic.Length;++i)
            {
                dic[i] = new Dictionary<int, string>(Sub_Capacity);
            }
            name_list = new List<string>();
            name_bundles = new List<string>();
            //LoadResources();
        }

        public static void LoadLocalResources()
        {
            if (is_load_res)
            {
                return;
            }
            is_load_res = true;

            name_list = new List<string>();
            TextAsset[] txt = Resources.LoadAll<TextAsset>(Path_Resources_Local);
            for (int i = 0; i < txt.Length; ++i)
            {
                Parse(txt[i].name, txt[i].text);
            }
            //PrintDictionary();
           
          
        }

        public static IEnumerator LoadLocalAsset()
        {
            if (File.Exists(LocalizationDownload.localManifestFilePath))
            {
                string json = File.ReadAllText(LocalizationDownload.localManifestFilePath);
                LocalizationAssetList local_list = JsonUtility.FromJson<LocalizationAssetList>(json);

                yield return LoadAssetList(local_list.resources);
               
            }
        }

        private static void PrintDictionary()
        {
            int total = 0;
            for(int i=0;i<dic.Length;++i)
            {
                //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning(string.Format("Localization Dic Key={0},Count={1}",i,dic[i].Count));
                total += dic[i].Count;
            }
            if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning(string.Format("Localization Dic Total={0}", total));
        }

        private static void LoadAssetBundle(string name, string txt)
        {
#if UNITY_EDITOR
            //if (!name_list.Contains(name))
#endif
            {
                //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.Log(string.Format("Load Asset Name={0} Txt={1}", name, txt));
                Parse(name, txt);
            }
            PrintDictionary();
        
        }

        private static string Format(string str)
        {
            return str.Replace("\\n", "\n").Replace("\\t", "\t").Replace("\\r","\n").Replace("\r","\n");
        }
        //private const int Subkey_Length = 10;
        private static Dictionary<int, string> GetSubDictionary(string key)
        {
            int keylen = key.Length;
            //int len = keylen - (keylen >> 2);
            //if(key.Length<Subkey_Length)
            //{
            //    sub_leng = key.Length;
            //}
            //int sub_key = (key.Substring(keylen - len, len).GetHashCode() & Mask);
            int sub_key = (key.Substring(keylen>>2, keylen >> 1).GetHashCode() & Mask);
            return dic[sub_key];
        }

        private static void Parse(string name, string text)
        {
            using (StringReader sr = new StringReader(text))
            {
                string line = null;
                int last_code = 0;
                Dictionary<int, string> dic_sub = null;
               
                while (sr.Peek()!=-1)
                {
                    line = sr.ReadLine();
                    if (string.IsNullOrEmpty(line))
                    {
                        continue;
                    }

                    //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.Log("Parse Line=" + line);
                    int index = line.IndexOf(Data_Split);
                    if (index < 0)
                    {
                        dic_sub[last_code] +="\n" +Format(line);
                    }
                    else
                    {
                        string key = line.Substring(0, index);
                        dic_sub = GetSubDictionary(key);
                        int code = key.GetHashCode();
                        last_code = code;
                        string value = Format(line.Substring(index + 1, line.Length - index - 1));
                        if (dic_sub.ContainsKey(code))
                        {
                            //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning(string.Format("存在相同的本地化文字{0},原值=[{1}],新值=[{2}]", key, dic_sub[code], value));
                            dic_sub[code] = value;
                        }
                        else
                        {
                            dic_sub.Add(code, value);
                        }
                    }
                }
            }
            name_list.Add(name);
        }

        // Use this for initialization
        public static IEnumerator LoadAssetList(List<LocalizationAsset> down_list)
        {
            string installTargetPath = LocalizationDownload.installTargetPath;
            for (int i = 0; i < down_list.Count; ++i)
            {
                LocalizationAsset asset = down_list[i];
                if (asset.name == "Localization")
                {
                    continue;
                }
               
                //if (name_bundles.Contains(asset.name))
                //{
                //    if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning("Already Loaded:" + asset.name);
                //    continue;
                //}
                //else
                {
                    name_bundles.Add(asset.name);
                    yield return LoadAsset(asset, installTargetPath);
                }
            }
        }
        private static IEnumerator LoadAsset(LocalizationAsset asset, string installTargetPath)
        {
            string name = asset.name;
            string www_path = "";
#if UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN
            www_path = "file:///" + Path.Combine(installTargetPath, name);
#else
                www_path = "file://" + Path.Combine(installTargetPath, name);
#endif
            // 安全装置





            WWW www = new WWW(www_path);
            while (!www.isDone)
            {
                yield return null;
            }


            if (!string.IsNullOrEmpty(www.error))
            {
                if(XD.tool.Debug.IsTagEnable("LogError"))Debug.LogError(name + " : " + www.error);


                yield break;
            }

            byte[] bytes = www.bytes;

            AssetBundleCreateRequest _createReq = AssetBundle.LoadFromMemoryAsync(bytes, asset.crc);
            if(XD.tool.Debug.IsTagEnable("Localization"))Debug.Log("AssetBundleCreateRequest=" + _createReq + "  " + bytes.Length);
            yield return _createReq;
            AssetBundleRequest _loadReq = _createReq.assetBundle.LoadAllAssetsAsync();
            yield return _loadReq;
            //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.Log(name + " : " + BitConverter.ToString(bytes, 0, 32));

            UnityEngine.Object[] assets = _loadReq.allAssets;
            for (int i = 0; i < assets.Length; ++i)
            {
                TextAsset txt = assets[i] as TextAsset;
                if (txt != null)
                {
                    Localization.LoadAssetBundle(txt.name, txt.text);
                }
            }

            _loadReq = null;
            _createReq.assetBundle.Unload(true);
            _createReq = null;




        }

        public static string GetLocalization(string key)
        {
            //if (key.StartsWith(Tag_Loc))
            {
              
                Dictionary<int, string> dic_sub = GetSubDictionary(key);
                int code = key.GetHashCode();
                if (dic_sub.ContainsKey(code))
                {
                    //if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning(string.Format("GetLocalization key={0},value={1}", key, dic_sub[code]));
                    return dic_sub[code];
                }
                else
                {
                    //if (Application.isPlaying)
                        if(XD.tool.Debug.IsTagEnable("Localization"))Debug.LogWarning(string.Format("GetLocalization key={0},value=Null", key));
                }
            }
#if __DEBUG_
            return key;
#else
            return string.Empty;
#endif

        }

        public static IEnumerator LoadZipResources(string zip_dir)
        {
            List<XDZip.FileData> list_file = XDZip.GetFileDatas(zip_dir);
            string per_dir = PathUnity.GetPersistentWrite(zip_dir);
            yield return XD.Mono.CoroutineManager.EnumeratorWithThread(() =>
            {
                              
                for (int i = 0; i < list_file.Count; ++i)
                {

                    XDZip.FileData file = list_file[i];
                    using (new StopWatch($"LoadMaster File={file.entry}", "LoadZipResources"))
                    {
                        string map_name = file.entry;
                    

                        string path = $"{per_dir}/{file.entry}";
                        string data = System.IO.File.ReadAllText(path);

                        Parse(file.entry, data);

                    }
                }
                //});
            });
        }
    }
}