﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace XD.Localization.Editor
{
    public class CombineSource
    {
        public enum ParseType
        {
            Variable,
            Comment,
            ConstantV,
            ConstantVV,
            Constant,
            CommentLine
        }
        public class Data
        {
            public enum Type
            {
                Function_Start,
                Function_End,
                Valuation,
                Comment,
                Variable,
                Constant,
                ConstantV,
                Symbol,
                Link,
                Combines,
                Const_Value
            }
            public Type type;
            public string text;
            public int line;

            public Data(Type type, string text, int line)
            {

                this.type = type;
                this.text = text;
                this.line = line;
                //Debug.Log("New Data=" + this);

            }
            public override string ToString()
            {
                return string.Format("type=[{0}],text=[{1}]", type, text);

            }
        }

        public enum ParseFlag
        {
            None = 0,
            End = 1 << 0,
            JPN = 1 << 1,
            Link = 1 << 2,
            Constant = 1 << 3,
            //Const_Tag=1<<4,
            //Read_Only=1<<5,
            //Debug_Function=1<<6,
        }


        private static class Functions
        {
            private static Dictionary<string, Action<ParseLine>> dele_variable = new Dictionary<string, Action<ParseLine>>();
            private static Dictionary<string, Action<ParseLine>> dele_comment = new Dictionary<string, Action<ParseLine>>();
            private static Dictionary<string, Action<ParseLine>> dele_comment_line = new Dictionary<string, Action<ParseLine>>();
            private static Dictionary<string, Action<ParseLine>> dele_constant = new Dictionary<string, Action<ParseLine>>();
            private static Dictionary<string, Action<ParseLine>> dele_constant_v = new Dictionary<string, Action<ParseLine>>();
            private static Dictionary<string, Action<ParseLine>> dele_constant_vv = new Dictionary<string, Action<ParseLine>>();
            static Functions()
            {
                dele_comment_line.Add("#end", (pl) =>
                {
                    pl.Add(Data.Type.Comment, PopString());
                    pl.flag |= ParseFlag.End;
                    curr_parse = ParseType.Variable;
                });
                dele_comment.Add("*/", (pl) =>
                {
                    pl.Add(Data.Type.Comment, PopString());
                    pl.flag |= ParseFlag.End;
                   curr_parse = ParseType.Variable;
                });
               
                dele_comment.Add("#end", (pl) =>
                {
                    pl.Add(Data.Type.Comment, PopString());
                    pl.flag |= ParseFlag.End;
                    curr_parse = ParseType.Variable;
                });

                dele_variable.Add("@", (pl) =>
                {
                    build.Remove(build.Length - 1,1);
                    //pl.flag |= ParseFlag.End;
                });
                dele_variable.Add("//", (p1) => {
                   
                    curr_parse = ParseType.CommentLine;
                });

                dele_variable.Add("/*", (pl) =>
                {
                    pl.Add(Data.Type.Variable, PopString(2).Trim(' '));

                    pl.flag &= ~ParseFlag.End;
                    curr_parse = ParseType.Comment;
                });
                dele_variable.Add("{", (pl) =>
                 {
                     pl.flag |= ParseFlag.End;

                     pl.Add(Data.Type.Variable, PopString(1).Trim(' '));

                     pl.Add(Data.Type.Symbol, PopString());

                 });
                dele_variable.Add("}", (pl) =>
                {
                    pl.flag |= ParseFlag.End;

                    pl.Add(Data.Type.Variable, PopString(1).Trim(' '));

                    pl.Add(Data.Type.Symbol, PopString());

                });
                dele_variable.Add("(",(pl)=> //(c == '(')
                {

                    pl.flag &= ~ParseFlag.End;

                    pl.Add(Data.Type.Function_Start, PopString());

                });
                dele_variable.Add("[", (pl) => //(c == '[')
                {

                    pl.flag &= ~ParseFlag.End;

                    pl.Add(Data.Type.Function_Start, PopString());

                });
                dele_variable.Add(")", (pl) =>//(c == ')')
                 {
                     pl.Add(Data.Type.Variable, PopString(1).Trim(' '));
                     pl.Add(Data.Type.Function_End, PopString());
                 });
                dele_variable.Add("]",(pl) =>//(c == ']')
                 {
                    pl.Add(Data.Type.Variable, PopString(1).Trim(' '));
                    pl.Add(Data.Type.Function_End, PopString());
                });
               
                dele_variable.Add("=>", (pl) => //(c == '=')
                {
                    pl.flag &= ~ParseFlag.End;

                    pl.Add(Data.Type.Valuation, PopString());

                });
                dele_variable.Add("=", (pl) => //(c == '=')
                {
                    pl.flag &= ~ParseFlag.End;

                    pl.Add(Data.Type.Valuation, PopString());

                });
                dele_variable.Add("return ", (pl) => //(c == '=')
                {
                    pl.flag &= ~ParseFlag.End;

                    pl.Add(Data.Type.Valuation, PopString());

                });
                
                dele_variable.Add("$\"", (pl) => {
                    PopString(1);
                    pl.flag |= ParseFlag.Constant;
                    curr_parse = ParseType.ConstantV;
                });
                dele_variable.Add("\"", (pl) =>//(c == '\"')
                {
                    curr_parse = ParseType.Constant;
                });
                dele_variable.Add(",", (pl) =>//(c == ',')
                {

                    pl.Add(Data.Type.Variable, PopString(1).Trim(' '));

                    pl.Add(Data.Type.Symbol, PopString());
                    //curr_index = i+1;
                });
                //dele_variable.Add("//", (pl) =>//(c == '/' && c_prev == '/')
                //{

                //    pl.Add(Data.Type.Variable, PopString(2).Trim(' '));

                //    string next_string = GetNextString();

                //    pl.Add(Data.Type.Comment, next_string);
                //    return;
                //});

                dele_variable.Add(";", (pl) => //(c == ';')
                {
                    pl.flag |= ParseFlag.End;
                    pl.Add(Data.Type.Variable, PopString(1).Trim(' '));
                    pl.Add(Data.Type.Symbol, PopString().Trim(' '));
                });
                dele_variable.Add("global", (p1) => {
                   if(line[char_index]==':'&&line[char_index+1]==':')
                    {
                        build.Append("::");
                        char_index += 2;
                    }
                });
                dele_variable.Add(":",(p1)=>{
                    p1.flag |= CombineSource.ParseFlag.End;
                    p1.Add(Data.Type.Variable, PopString(1).Trim(' '));
                    p1.Add(Data.Type.Symbol, PopString().Trim(' '));
                });
                dele_variable.Add("+", (pl) =>//(c == '+')
                {
                    pl.Add(Data.Type.Variable, PopString(1).Trim(' '));
                    pl.Add(Data.Type.Link, PopString());
                    pl.flag &= ~ParseFlag.End;
                    //curr_index = i + 1;
                });
                dele_variable.Add("?", (pl) =>//(c=='?')
                 {
                     if (line[char_index] == '.' )
                     {
                         build.Append(line[char_index++]);
                       
                     }
                     else
                     { 
                         pl.Add(Data.Type.Symbol, PopString());
                     }
                 });
                dele_variable.Add(">", (pl) =>//(c == '>')
                 {

                     pl.Add(Data.Type.Symbol, PopString());

                 });
                dele_variable.Add("#end", (pl) =>
                 {
                     pl.Add(Data.Type.Variable, PopString().Trim(' '));
                 });

                dele_constant.Add("\"", (pl) =>//(c == '\"')
                {
                    curr_parse = ParseType.Variable;
                    pl.Add(Data.Type.Constant, PopString().Trim('\n').Trim('\r').Trim(' '));
                });

                dele_constant_v.Add("\"", (pl) =>//(c == '\"')
                 {
                     curr_parse = ParseType.Variable;
                     string v = GetCurr().StartsWith("\"") ? PopString() : PopString(1);
                     if (v.Length > 0)
                     {
                        //Debug.Log(" Add Constant With [\"] str="+v);
                        pl.Add(Data.Type.Constant, v.Trim('\n').Trim('\r').Trim(' '));

                     }
                     PopString();
                 });
                dele_constant_v.Add("{", (pl) =>
                 {
                    //Debug.Log(" Add Constant With [{]");
                    pl.Add(Data.Type.Constant, PopString(1).Trim('\n').Trim('\r').Trim(' '));
                     PopString();
                     pl.Add(Data.Type.Link, "+");
                     curr_parse = ParseType.ConstantVV;
                 });
                //dele_constant_v.Add("}", (pl) =>
                // {
                //    //Debug.Log(" Add Variable With [}]");
                //    pl.Add(Data.Type.Variable, PopString(1).Trim('\n').Trim('\r').Trim(' '));
                //     PopString();
                //     pl.Add(Data.Type.Link, "+");
                // });
                dele_constant_vv.Add("}", (pl) =>
                 {
                     //Debug.Log(" Add Variable With [}]");
                     string value = PopString(1).Trim('\n').Trim('\r').Trim(' ');
                     int sp_index_c = value.IndexOf("?");
                     int sp_index = value.IndexOf(":");
                     //string[] sps = value.Split(':');
                     if (sp_index >0 && sp_index_c<0)
                     {
                         string v1 = value.Substring(0, sp_index);
                         if (!v1.Contains("ToString"))
                         {
                             string v2 = value.Substring(sp_index + 1, value.Length - sp_index - 1);
                             value = $"({v1}).ToString(\"{v2}\")";
                         }
                     }
                     pl.Add(Data.Type.Variable, value);
                     PopString();
                     pl.Add(Data.Type.Link, "+");
                     curr_parse = ParseType.ConstantV;
                 });

            }

            private static string GetNextString()
            {
                int start = char_index - 1 >= 0 ? char_index - 1 : 0;
                return line.Substring(start, line.Length - start);
            }

            public static void ExcuteComment(bool end, ParseLine parseLine, Dictionary<string, Action<ParseLine>> dele)
            {
                string curr = GetCurr();
                foreach (KeyValuePair<string,Action< ParseLine>> pair in dele)
                {
                    if(curr.EndsWith(pair.Key))
                    {
                        pair.Value.Invoke(parseLine);
                        return;
                    }
                }
                if (end)
                {
                    dele["#end"].Invoke(parseLine);
                    return;
                }
            }
            public static StringBuilder build = new StringBuilder();

            public static string PopString(int wipe = 0)
            {
                int leng = build.Length - wipe;
                if (leng <= 0)
                {
                    return "";
                }
                string str = build.ToString(0, leng);
                build.Remove(0, leng);
                return str;
            }
            public static ParseType curr_parse = ParseType.Variable;
            public static int char_index;
            public static string line;
            public static void ProcessString(string line, ParseLine pl)
            {
                //build.Clear();
                Functions.line = line;

                char_index = 0;
                while (char_index < line.Length)
                {
                    //char c = line[i];
                    //char c_prev = i > 0 ? line[i - 1] : ' ';
                    build.Append(line[char_index++]);

                    switch (curr_parse)
                    {

                        case ParseType.CommentLine:
                            ExcuteComment(char_index == line.Length, pl, dele_comment_line);
                            break;
                        case ParseType.Comment:
                            ExcuteComment(char_index == line.Length, pl, dele_comment);

                            break;
                        case ParseType.Variable:
                            ExcuteComment(char_index == line.Length, pl, dele_variable);
                            break;
                        case ParseType.Constant:
                            ExcuteComment(false, pl, dele_constant);

                            break;
                        case ParseType.ConstantV:
                            ExcuteComment(false, pl, dele_constant_v);
                            break;
                        case ParseType.ConstantVV:
                            ExcuteComment(false, pl, dele_constant_vv);
                            break;

                    }
                }
                pl.ProcessStringEnd();

            }

            private static string GetCurr()
            {
                return build.ToString();
            }
        }

        private class ParseLine
        {
        

            public ParseFlag flag = CombineSource.ParseFlag.End;
            private int line_start = -1;
            private int line_end = -1;

            private List<Data> list_data = new List<Data>();

            public void Add(Data.Type type, string text)
            {
                //curr_type = Data.Type.Variable;
                text = text.Trim('\r').Trim('\n');

                if (string.IsNullOrEmpty(text))
                {
                    return;
                }
                //if(type==  Data.Type.Constant)
                //{
                //    Debug.Log("type=" + type);
                //}


                flag |= ParseFlag(type, text);
                list_data.Add(new Data(type, text, line_end));
                //Debug.Log(string.Format("AddData={0}",list_data[list_data.Count-1]));
            }

            private ParseFlag ParseFlag(Data.Type type, string text)
            {
                ParseFlag flag = CombineSource.ParseFlag.None;
                if (type == Data.Type.Constant)
                {
                    flag |= CombineSource.ParseFlag.Constant;
                    //if (LangTool.IsJPN(text))
                    //{
                    //    flag |= CombineSource.ParseFlag.JPN;
                    //}
                }

                if (type == Data.Type.Valuation)
                {
                    //if (text.Contains("const"))
                    //{
                    //    flag |= Flag.Const_Tag;
                    //}
                }
                if (type == Data.Type.Function_Start)
                {
                    if (text.Contains("Debug") || text.Contains("ActivityLogger"))
                    {
                        //flag |= Flag.Debug_Function;
                    }
                }
                return flag;
            }

            public static ParseFlag FULL_TAG = CombineSource.ParseFlag.End | CombineSource.ParseFlag.Link | CombineSource.ParseFlag.Constant /*| CombineSource.ParseFlag.JPN*/;
            public void Parse(string[] srcs, int l_index, ref bool modify)
            {
                if (line_start == -1)
                {
                    line_start = l_index;
                }
                line_end = l_index;
                //try
                {
                    //ProcessString(srcs[l_index]);
                    Functions.ProcessString(srcs[l_index], this);
                }
                //catch(Exception)
                {
                    //Debug.Log("ProcessString:" + srcs[l_index]);
                }
                //Debug.Log("ParseFlag=" + srcs[l_index] + "   " + flag + "   " + FULL_TAG);
                if (flag != FULL_TAG)//((flag & FULL_TAG) != FULL_TAG )
                {
                    return;
                }

                ProcessDataNew(srcs);
                //ProcessData();
                modify = true;
                //WriteFiles(srcs);
            }

            private void WriteFiles(string[] srcs)
            {

                //Debug.Log("Parse Flag" + flag + "  " + list_data.Count + "  " + line_start + "   " + line_end);
                //for (int i = 0; i < list_data.Count; ++i)
                //{
                //    Debug.Log(string.Format("[{0}]Type={1} ,Value=[{2}]", i, list_data[i].type, list_data[i].text));
                //}
                StringBuilder new_line = new StringBuilder();
                for (int i = 0; i < list_data.Count; ++i)
                {
                    if (list_data[i].type == Data.Type.Combines)
                    {
                        CombineData cd = list_data[i] as CombineData;
                        new_line.Append(string.Format("string.Format(\"{0}\"{1})", cd.text, cd.param));
                    }
                    else if (list_data[i].type != Data.Type.Comment)
                    {
                        new_line.Append(list_data[i].text);
                    }
                }
                for (int i = 0; i < list_data.Count; ++i)
                {
                    if (list_data[i].type == Data.Type.Comment)
                    {
                        new_line.Append(list_data[i].text);
                    }
                }

                srcs[line_start] = new_line.ToString();
                for (int i = line_start + 1; i <= line_end; ++i)
                {
                    srcs[i] = "";
                }
                //Debug.Log("NewLine=" + new_line.ToString());

            }

            private class CombineData : Data
            {
                //int start;
                //int end;

                public string param;
                public CombineData(string text, string param, int line) : base(Type.Combines, text, line)
                {
                    //Debug.Log(string.Format("CombineData={0},param={1}", text, param));
                    this.param = param;
                }
            }
            private void ProcessDataNew(string[] srcs)
            {
                Stack<Data> stack = new Stack<Data>();
                for (int i = 0; i < list_data.Count; ++i)
                {
                    Data data = list_data[i];

                    if (data.type == Data.Type.Symbol)
                    {
                        PopStackVar(stack);
                        PopStackAdd(stack);
                        stack.Push(data);
                    }
                    else if (data.type == Data.Type.Function_End)
                    {
                        PopStackVar(stack);
                        PopStackAdd(stack);
                        PopFunction(stack, data);
                    }
                    else if (data.type == Data.Type.Link)
                    {
                        PopStackVar(stack);
                        stack.Push(data);
                    }
                    else
                    {
                        stack.Push(data);

                    }
                    //Debug.Log("AddStack=" + stack.Count + " text= " + data);
                }
                Data[] array = stack.ToArray();
                //Debug.Log("stack=" + stack.Count + "  " + array.Length);
                StringBuilder new_line = new StringBuilder();
                for (int i = array.Length - 1; i >= 0; --i)
                {
                    //Debug.Log(string.Format("StringBuilder array[{0}]={1}", i, array[i]));
                    new_line.Append(array[i].text);
                }
                //Debug.Log("New_Line=" + new_line.ToString());
                string str = new_line.ToString();
                str = LangTool.FormatConst(str);

                srcs[line_start] = str;
                for (int i = line_start + 1; i <= line_end; ++i)
                {
                    srcs[i] = "";
                }
            }



            private void PopFunction(Stack<Data> stack, Data end)
            {
                if (stack.Count == 0)
                {
                    return;
                }
                Data data;
                List<Data> combines = new List<Data>();
                //Debug.Log(string.Format("PopFunction Stack=[{0}] Peek=[{1}]", stack.Count,stack.Peek()));
                while (stack.Count > 0 && (data = stack.Pop()) != null)
                {
                    combines.Insert(0, data);
                    //Debug.Log(string.Format("PopFunction Data=[{0}],Type=[{1}]", data.text,data.type));
                    if (data.type == Data.Type.Function_Start)
                    {
                        break;
                    }
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < combines.Count; ++i)
                {
                    sb.Append(combines[i].text);
                }
                sb.Append(end.text);
                //Debug.Log("PopFunction=" + sb.ToString());
                stack.Push(new Data(Data.Type.Variable, sb.ToString(), line_start));
            }

            private void PopStackVar(Stack<Data> stack)
            {
                if (stack.Count <= 1)
                {
                    return;
                }

                Data data;
                List<Data> combines = new List<Data>();

                while (stack.Count > 0 && (data = stack.Peek()) != null && (data.type == Data.Type.Constant || data.type == Data.Type.Variable))
                {
                    if (data.type != Data.Type.Comment)
                    {
                        combines.Insert(0, data);
                    }
                    //Debug.Log("PopStack=" + data);
                    stack.Pop();
                }
                Data cd = CombineStack(combines);
                //Debug.Log("PopStackVar=" + cd);
                if (cd != null)
                {
                    stack.Push(cd);
                }
            }

            private void PopStackAdd(Stack<Data> stack)
            {
                if (stack.Count == 0)
                {
                    return;
                }
                Data data;
                List<Data> combines = new List<Data>();
                bool has_constant = false;


                while (stack.Count > 0 && (data = stack.Peek()) != null && (data.type == Data.Type.Constant || data.type == Data.Type.Variable || data.type == Data.Type.Link))
                {
                    if (data.type != Data.Type.Comment)
                    {
                        combines.Insert(0, data);
                    }
                    if (data.type == Data.Type.Constant)
                    {
                        has_constant = true;
                    }

                    //Debug.Log("PopStackAdd=" + data);
                    stack.Pop();
                }
                Data cd = null;
                if (has_constant)
                {
                    cd = CombineStackAdd(combines);
                }
                else
                {
                    cd = CombineStackNormal(combines);
                }
                if (cd != null)
                {
                    stack.Push(cd);
                }
            }

            private Data CombineStackNormal(List<Data> combines)
            {
                StringBuilder new_line = new StringBuilder();
                for (int i = 0; i < combines.Count; ++i)
                {
                    //Debug.Log(string.Format("StringBuilder array[{0}]={1}", i, array[i]));
                    new_line.Append(combines[i].text);
                }
                //Debug.Log("New_Line=" + new_line.ToString());
                return new Data(Data.Type.Variable, new_line.ToString(), line_start);
            }

            private ParseFlag ParseFlag(List<Data> combines)
            {
                ParseFlag flag = CombineSource.ParseFlag.None;
                for (int i = 0; i < combines.Count; ++i)
                {
                    flag |= ParseFlag(combines[i].type, combines[i].text);
                }
                return flag;
            }
            private Data CombineStack(List<Data> combines)
            {
                if (combines.Count == 0)
                {
                    return null;
                }
                if (combines.Count == 1)
                {
                    return combines[0];
                }

                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < combines.Count; ++i)
                {
                    //Debug.Log("Combine Stack=" + combines[i]);
                    sb.Append(combines[i].text);
                }
                return new Data(Data.Type.Variable, sb.ToString(), line_start);
            }
            private Data CombineStackAdd(List<Data> combines)
            {
                if (combines.Count == 0)
                {
                    return null;
                }
                if (combines.Count == 1)
                {
                    return combines[0];
                }


                StringBuilder sb = new StringBuilder();
                sb.Append("string.Format(\"");
                int val_index = 0;
                for (int i = 0; i < combines.Count; ++i)
                {

                    Data d = combines[i];
                    //Debug.Log("ProcessCombine:" + d);
                    if (d.type == Data.Type.Constant)
                    {
                        //Debug.Log("ProcessCombine:" + d.text.Trim('"'));
                        sb.Append(d.text.Trim('\t').Trim('"'));
                    }
                    else if (d.type == Data.Type.Variable)
                    {
                        sb.Append("{");
                        sb.Append(val_index++);
                        sb.Append("}");
                    }

                }
                sb.Append("\"");
                //StringBuilder param = new StringBuilder();
                for (int i = 0; i < combines.Count; ++i)
                {
                    Data d = combines[i];
                    if (d.type == Data.Type.Variable)
                    {
                        sb.Append(",");
                        sb.Append(d.text);
                    }
                }
                sb.Append(")");
                //Debug.Log("CombineStack=" + sb.ToString());
                return new Data(Data.Type.Constant, sb.ToString(), line_start);
            }

            private void ProcessData()
            {


                List<Data> combines = new List<Data>();
                for (int i = 0; i < list_data.Count; ++i)
                {

                    if (list_data[i].type == Data.Type.Function_End || list_data[i].type == Data.Type.Symbol)
                    {
                        //if (combines.Count >= 2)
                        //{
                        //    Debug.Log("Do Combine" + list_data[i].text);
                        //}
                        Data new_data = ProcessCombine(combines);

                        combines.Clear();
                        if (new_data != null)
                        {
                            list_data.Insert(i, new_data);
                            ++i;
                        }

                    }
                    else if (list_data[i].type == Data.Type.Constant || list_data[i].type == Data.Type.Variable)
                    {

                        combines.Add(list_data[i]);
                        //Debug.Log("Add To Combines:" + list_data[i].text+"  "+combines.Count);
                        list_data.RemoveAt(i);
                        --i;
                    }
                    else if (list_data[i].type == Data.Type.Link)
                    {
                        list_data.RemoveAt(i);
                        --i;
                    }
                }




            }

            private Data ProcessCombine(List<Data> combines)
            {
                if (combines.Count == 0)
                {
                    return null;
                }
                if (combines.Count == 1)
                {
                    return combines[0];
                }

                StringBuilder sb = new StringBuilder();
                //sb.Append("string.Format(\"");
                int val_index = 0;
                for (int i = 0; i < combines.Count; ++i)
                {

                    Data d = combines[i];
                    //Debug.Log("ProcessCombine:" + d.text);
                    if (d.type == Data.Type.Constant)
                    {
                        sb.Append(d.text);
                    }
                    else if (d.type == Data.Type.Variable)
                    {
                        sb.Append("{");
                        sb.Append(val_index++);
                        sb.Append("}");
                    }
                }
                //sb.Append("\"");
                StringBuilder param = new StringBuilder();
                for (int i = 0; i < combines.Count; ++i)
                {
                    Data d = combines[i];
                    if (d.type == Data.Type.Variable)
                    {
                        param.Append(",");
                        param.Append(d.text);
                    }
                }
                //sb.Append(")");
                return new CombineData(sb.ToString(), param.ToString(), line_start);
            }

          

            public ParseType curr_parse = ParseType.Variable;
            //private Data.Type curr_type = Data.Type.Variable;
            private StringBuilder build = new StringBuilder();
            private string PopString(int wipe = 0)
            {
                int leng = build.Length - wipe;
                if (leng <= 0)
                {
                    return "";
                }
                string str = build.ToString(0, leng);
                build.Remove(0, leng);
                return str;
            }
            //private void ProcessString(string line)
            //{


            //    int char_index = 0;
            //    while (char_index < line.Length)
            //    {
            //        //char c = line[i];
            //        //char c_prev = i > 0 ? line[i - 1] : ' ';
            //        build.Append(line[char_index++]);
            //        string curr = build.ToString();
            //        switch (curr_parse)
            //        {

            //            case ParseType.Comment:
            //                if (curr.EndsWith("*/"))
            //                {
            //                    Add(Data.Type.Comment, PopString());
            //                    flag |= CombineSource.ParseFlag.End;
            //                    curr_parse = ParseType.Variable;
            //                }
            //                else if (char_index == line.Length)
            //                {
            //                    Add(Data.Type.Comment, PopString());
            //                }
            //                break;
            //            case ParseType.Variable:
            //                if (curr.EndsWith("@"))
            //                {
            //                    flag |= CombineSource.ParseFlag.End;
            //                    return;
            //                }
            //                else if (curr.EndsWith("/*"))
            //                {
            //                    Add(Data.Type.Variable, PopString(2).Trim(' '));

            //                    flag &= ~CombineSource.ParseFlag.End;
            //                    curr_parse = ParseType.Comment;
            //                    //curr_index = i;
            //                }
            //                else if (curr.EndsWith("{") || curr.EndsWith("}"))//(c=='{'||c=='}')
            //                {
            //                    flag |= CombineSource.ParseFlag.End;

            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));

            //                    Add(Data.Type.Symbol, PopString());

            //                }
            //                else if (curr.EndsWith("(") || curr.EndsWith("[")) //(c == '(')
            //                {

            //                    flag &= ~CombineSource.ParseFlag.End;

            //                    Add(Data.Type.Function_Start, PopString());

            //                }
            //                else if (curr.EndsWith(")") || curr.EndsWith("]"))//(c == ')')
            //                {

            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));

            //                    Add(Data.Type.Function_End, PopString());


            //                }
            //                else if (curr.EndsWith("=") || curr.EndsWith("return ")) //(c == '=')
            //                {
            //                    flag &= ~CombineSource.ParseFlag.End;

            //                    Add(Data.Type.Valuation, PopString());

            //                }
            //                else if (curr.EndsWith("$\""))
            //                {

            //                    PopString(1);

            //                    curr_parse = ParseType.ConstantV;
            //                }
            //                else if (curr.EndsWith("\""))//(c == '\"')
            //                {

            //                    curr_parse = ParseType.Constant;
            //                }
            //                else if (curr.EndsWith(","))//(c == ',')
            //                {

            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));

            //                    Add(Data.Type.Symbol, PopString());
            //                    //curr_index = i+1;
            //                }
            //                else if (curr.EndsWith("//"))//(c == '/' && c_prev == '/')
            //                {

            //                    Add(Data.Type.Variable, PopString(2).Trim(' '));

            //                    int start = char_index - 1 >= 0 ? char_index - 1 : 0;
            //                    Add(Data.Type.Comment, line.Substring(start, line.Length - start));
            //                    return;
            //                }

            //                else if (curr.EndsWith(";")) //(c == ';')
            //                {
            //                    flag |= CombineSource.ParseFlag.End;

            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));


            //                    Add(Data.Type.Symbol, PopString().Trim(' '));

            //                }
            //                else if (curr.EndsWith(":")) //(c == ';')
            //                {
            //                    flag |= CombineSource.ParseFlag.End;

            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));


            //                    Add(Data.Type.Symbol, PopString().Trim(' '));

            //                }
            //                else if (curr.EndsWith("+"))//(c == '+')
            //                {


            //                    Add(Data.Type.Variable, PopString(1).Trim(' '));



            //                    Add(Data.Type.Link, PopString());
            //                    flag &= ~CombineSource.ParseFlag.End;
            //                    //curr_index = i + 1;

            //                }
            //                else if (curr.EndsWith("?"))//(c=='?')
            //                {

            //                    Add(Data.Type.Symbol, PopString());

            //                }
            //                else if (curr.EndsWith(">"))//(c == '>')
            //                {

            //                    Add(Data.Type.Symbol, PopString());

            //                }
            //                else if (char_index == line.Length)
            //                {

            //                    Add(Data.Type.Variable, PopString().Trim(' '));

            //                }
            //                break;
            //            case ParseType.Constant:
            //                if (curr.EndsWith("\""))//(c == '\"')
            //                {
            //                    curr_parse = ParseType.Variable;
            //                    Add(Data.Type.Constant, PopString().Trim('\n').Trim('\r').Trim(' '));
            //                }
            //                break;
            //            case ParseType.ConstantV:
            //                if (curr.EndsWith("\""))//(c == '\"')
            //                {
            //                    curr_parse = ParseType.Variable;
            //                    string v = curr.StartsWith("\"") ? PopString() : PopString(1);
            //                    if (v.Length > 0)
            //                    {
            //                        //Debug.Log(" Add Constant With [\"] str="+v);
            //                        Add(Data.Type.Constant, v.Trim('\n').Trim('\r').Trim(' '));

            //                    }
            //                    PopString();
            //                }
            //                else if (curr.EndsWith("{"))
            //                {
            //                    //Debug.Log(" Add Constant With [{]");
            //                    Add(Data.Type.Constant, PopString(1).Trim('\n').Trim('\r').Trim(' '));
            //                    PopString();
            //                    Add(Data.Type.Link, "+");
            //                    curr_parse = ParseType.ConstantVV;
            //                }
            //                else if (curr.EndsWith("}"))
            //                {
            //                    //Debug.Log(" Add Variable With [}]");
            //                    string value = PopString(1).Trim('\n').Trim('\r').Trim(' ');
            //                    string[] sps = value.Split(':');

            //                    if (sps.Length == 2 && !value.Contains("ToString"))
            //                    {
            //                        value = $"({sps[0]}).ToString(\"{sps[1]}\")";
            //                    }
            //                    Add(Data.Type.Variable, value);
            //                    PopString();
            //                    Add(Data.Type.Link, "+");
            //                }

            //                break;
            //            case ParseType.ConstantVV:
            //                if (curr.EndsWith("}"))
            //                {
            //                    //Debug.Log(" Add Variable With [}]");
            //                    string value = PopString(1).Trim('\n').Trim('\r').Trim(' ');
            //                    string[] sps = value.Split(':');
            //                    if (sps.Length == 2 && !value.Contains("ToString")&&value.IndexOf("?")<0)
            //                    {
            //                        value = $"({sps[0]}).ToString(\"{sps[1]}\")";
            //                    }
            //                    Add(Data.Type.Variable, value);
            //                    PopString();
            //                    Add(Data.Type.Link, "+");
            //                    curr_parse = ParseType.ConstantV;
            //                }
            //                break;

            //        }
            //    }
            //    ProcessStringEnd();
            //}

            public void ProcessStringEnd()
            {
                if ((flag & CombineSource.ParseFlag.End) == CombineSource.ParseFlag.End)
                {
                    for (int i = 0; i < list_data.Count; ++i)
                    {
                        if (list_data[i].type == Data.Type.Link)
                        {
                            Data left = i > 1 ? list_data[i - 1] : null;
                            Data right = i < list_data.Count - 1 ? list_data[i + 1] : null;
                            if ((left != null && left.type == Data.Type.Constant) || (right != null && right.type == Data.Type.Constant))
                            {
                                flag |= CombineSource.ParseFlag.Link;
                                return;
                            }
                        }
                    }
                }
            }

            internal bool HasFlag(ParseFlag f)
            {
                return (flag & f) != CombineSource.ParseFlag.None;
            }
        }

        public string file;
        public bool modify;
        public string[] srcs;
        public TextAsset asset;

        private List<ParseLine> list = new List<ParseLine>();

        public CombineSource(string file, TextAsset asset)
        {
            
            this.file = file;
            this.srcs = LangCSFormat.SplitSrcs(asset.text);
            //Debug.Log($"CombineSource={ file},srcs.Length={srcs.Length}");
            this.asset = asset;
            modify = false;
          
            Parse(srcs);
        }
        private void Parse(string[] srcs)
        {
            this.srcs = srcs;
            for (int i = 0; i < srcs.Length; ++i)
            {
                if (!string.IsNullOrEmpty(srcs[i]))
                {
                    ParseLine pl = GetParse();
                    pl.Parse(srcs, i, ref modify);
                }
            }

        }

        private ParseLine GetParse()
        {
            if (list.Count == 0 || list[list.Count - 1].HasFlag(ParseFlag.End))
            {
                ParseLine p = new ParseLine();
                list.Add(p);
            }
            return list[list.Count - 1];

        }


    }
}