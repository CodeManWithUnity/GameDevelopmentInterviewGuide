﻿////#define LOCALIZATION_NGUI
//using System;
//using System.Collections;
//using System.Collections.Generic;
//using UnityEditor;
//using UnityEditor.SceneManagement;
//using UnityEngine;
//using UnityEngine.UI;
//using XD.Editor;
//using XD.Editor.Finder;
//using XD.Localization.Runtime;

//namespace XD.Localization.Editor
//{
//    public class LabelSpaceFix
//    {

//        [MenuItem("本地化/功能/修复字间距", false, 0)]
//        public static void FixLabelSpace()
//        {
//            EditorCoroutineRunner.StartEditorCoroutine(FixeE(FixSpaceAction));
//        }

//        private static IEnumerator FixeE(Func<GameObject, string, bool> action)
//        {
//            yield return Finder.ForeachPrefab(new string[] { @"Assets\AssetBundles\prefabs\no_naming\common" }/*LangConstant.Prefab_Directionay*/, action, false);
//            //yield return Finder.ForeachBuildScene(action, false);
          

//        }

//        private static bool FixSpaceAction(GameObject obj, string path)
//        {
//            bool is_dirty = false;
//#if LOCALIZATION_NGUI
//                is_dirty |= Fix<UILabel>(obj,  label => label.spacingX < 0, (label) => label.spacingX = 0);
//#endif
//#if LOCALIZATION_UGUI_PRO
//            Func<TMPro.TextMeshProUGUI, bool> check = (label) => label.lineSpacing < 0 || label.characterSpacing < 0;
//            Action<TMPro.TextMeshProUGUI> fix = (label) => {
//                if (label.lineSpacing < 0) label.lineSpacing = 0;
//                if (label.characterSpacing < 0) label.characterSpacing = 0;
//            };
//            is_dirty |= Fix<TMPro.TextMeshProUGUI>(obj, check, fix);
//            //is_dirty |= Fix<TMPro.TextMeshProUGUI>(obj, label => label.lineSpacing < 0, (label) => label.lineSpacing = 0);
//            //is_dirty |= Fix<TMPro.TextMeshProUGUI>(obj, label => label.characterSpacing < 0, (label) => label.characterSpacing = 0);
//#else
//              is_dirty |= Fix<Text>(obj, label => label.lineSpacing < 0, (label) => label.lineSpacing = 0);
//#endif

//            return is_dirty;
//        }

//      public static bool Fix<T>(GameObject obj, Func<T, bool> check, Action<T> set) where T : MonoBehaviour
//        {
//            T[] labels = obj.GetComponentsInChildren<T>(true);

//            bool is_dirty = false;
//            for (int j = 0; j < labels.Length; ++j)
//            {
//                //string str = LangTool.FilterString(labels[j].text);
//                bool c = check(labels[j]);
//                if (c)
//                {
//                    set(labels[j]);
//                    is_dirty = true;
//                }

//            }
//            return is_dirty;
//        }

//        [MenuItem("本地化/功能/修复文本内容", false, 0)]
//        public static void FixLabelContent()
//        {
//            //GameObject obj = AssetDatabase.LoadAssetAtPath("Assets/AssetBundles/prefabs/no_naming/common/footer.prefab", typeof(GameObject)) as GameObject;
//            //Debug.Log($"FixLabelContent Obj={obj}");
//            //FixPrefabContent(obj, "");
//            //EditorUtility.SetDirty(obj);
//            //AssetDatabase.SaveAssets();
//            EditorCoroutineRunner.StartEditorCoroutine(FixeE(FixPrefabContent));
//        }
//#if LOCALIZATION_UGUI_PRO
//        [MenuItem("本地化/功能/修复SubMesh", false, 0)]
//        public static void FixSubMesh()
//        {
//            GameObject obj = AssetDatabase.LoadAssetAtPath("Assets/AssetBundles/prefabs/no_naming/common/footer.prefab", typeof(GameObject)) as GameObject;
//            FixSubmeshContent(obj, "");
//            EditorUtility.SetDirty(obj);
//            AssetDatabase.SaveAssets();
//            //EditorCoroutineRunner.StartEditorCoroutine(FixeE(FixSubmeshContent));
//        }

//        private static bool FixSubmeshContent(GameObject obj, string arg2)
//        {
//            bool is_dirty = false;

//            TMPro.TextMeshProUGUI[] labels = obj.GetComponentsInChildren<TMPro.TextMeshProUGUI>(true);


//            for (int j = 0; j < labels.Length; ++j)
//            {
//                Debug.Log($"labels [{j}] Text={labels[j].text}");
//                LocalizationLabel.Attach(labels[j], labels[j].text);
//                labels[j].text = LocalizationLabel.Replace_Value;
//                //GameObject.DestroyImmediate(submeshes[j].gameObject, true);
//                is_dirty = true;


//            }


//            return is_dirty;
//        }
//#endif

//        private static bool FixPrefabContent(GameObject obj, string arg2)
//        {

//            bool is_dirty = false;

//            LocalizationLabel[] labels = obj.GetComponentsInChildren<LocalizationLabel>(true);

           
//            for (int j = 0; j < labels.Length; ++j)
//            {
//#if LOCALIZATION_NGUI
//                is_dirty |= FixLabel<UILabel>(labels[j],  label => label.text!=LocalizationLabel.Replace_Value, (label) => label.text = LocalizationLabel.Replace_Value);
//#endif
//#if LOCALIZATION_UGUI_PRO
//                is_dirty |= FixLabel<TMPro.TextMeshProUGUI>(labels[j], label => {
//                    Debug.Log($"label.text={label.text},label.name={label.name}");
//                    return label.text != LocalizationLabel.Replace_Value;

//                }, (label) =>
//                {
//                    //TMPro.TMP_SubMeshUI[] submeshes = label.GetComponentsInChildren<TMPro.TMP_SubMeshUI>(false);
//                    //for (int i = 0; i < submeshes.Length; ++i)
//                    //{
//                    //    submeshes[i].gameObject.SetActive(false);
//                    //}
//                    //label.text = LocalizationLabel.Replace_Value;
//                    label.SetMeshText(LocalizationLabel.Replace_Value);
//                    //for (int i = 0; i < submeshes.Length; ++i)
//                    //{
//                    //    submeshes[i].RefreshMaterial();
//                    //    submeshes[i].SetAllDirty();
//                    //    submeshes[i].gameObject.SetActive(true);
//                    //}
//                }
//                ) ;
//#else
//              is_dirty |= FixLabel<Text>(labels[j], label => label.text!=LocalizationLabel.Replace_Value, (label) => label.text = LocalizationLabel.Replace_Value);
//#endif
//            }


//            return is_dirty;

//        }

//        private static bool FixLabel<T>(LocalizationLabel label, Func<T, bool> check, Action<T> set) where T : MonoBehaviour
//        {
//            T t = label.GetComponent<T>();
//            if (t != null)
//            {
//                bool is_dirty = false;
//                bool c = check(t);
//                if (c)
//                {
//                    set(t);
//                    is_dirty = true;
//                }
//                return is_dirty;
//            }
//            return false;
           
//        }
//    }
//}