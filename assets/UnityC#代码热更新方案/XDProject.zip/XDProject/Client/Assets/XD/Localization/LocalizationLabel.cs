
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Runtime
{
    [DefaultExecutionOrder(1000)]
    public partial class LocalizationLabel : MonoBehaviour {

        [SerializeField]
        public string key;
        [SerializeField]
        public MonoBehaviour label;
        [SerializeField]
        public string value;



        // Use this for initialization
        void Start() {
            //UpdateLabel(false);

        }
        public const string Replace_Value = "\t\t\t";

      

       
        public void UpdateLabel(bool reset = false)
        {
          
            string text = Localization.GetLocalization(key);
#if UNITY_EDITOR
            value = text;
#endif
            strategy.Excute(label.GetType(), new object[] { this, text ,reset});
           
        }
      


        private static Strategy<Type, object[], object> strategy=new Strategy<Type, object[], object>(null,null);
    
        public static void Regist(Type type,Func<object[],object> func)
        {
            strategy.Regist(type,func);
        }
        static LocalizationLabel()
        {
#if LOCALIZATION_NGUI
            strategy.Regist(typeof(UILabel), ParseNGUI);
#endif
#if LOCALIZATION_UGUI_PRO
            strategy.Regist(typeof(TMPro.TextMeshProUGUI), ParseUGUIPro);
#endif
            strategy.Regist(typeof(Text), ParseUGUI);
        }
        private static object ParseUGUI(object[] val)
        {
            LocalizationLabel l = CollectionTool.GetValue<LocalizationLabel>(val, 0);
            Text label = l.label as Text;
            //label.lineSpacing = 1;//   m_LineSpacing
            bool reset = CollectionTool.GetValue<bool>(val, 2);
            if (label.text.Equals(Replace_Value) || reset)
            {
                label.text = CollectionTool.GetValue<string>(val, 1);
            }
           
            return label;
        }
#if LOCALIZATION_UGUI_PRO
        private static object ParseUGUIPro(object[] val)
        {
            LocalizationLabel l = CollectionTool.GetValue<LocalizationLabel>(val, 0);
            TMPro.TextMeshProUGUI label = l.label as TMPro.TextMeshProUGUI;
            bool reset = CollectionTool.GetValue<bool>(val, 2);
            if (label.text.Equals(Replace_Value)|| reset)
            {
                label.SetText(CollectionTool.GetValue<string>(val, 1));
            }
            //else
            //{
            //    if(XD.tool.Debug.IsTagEnable("LocalizationLabel"))Debug.Log($"Label_Changed GameObject={l.name}, text=[{label.text}],Key={l.key},value={CollectionTool.GetValue<string>(val, 1)}");
            //}

            return label;
        }
#endif
#if LOCALIZATION_NGUI
        private static object ParseNGUI(object[] val)
        {
            LocalizationLabel l = CollectionTool.GetValue<LocalizationLabel>(val, 0);
            UILabel label = l.label as UILabel;
         
            UIWidget.OnDimensionsChanged change = label.onChange;
            bool reset = CollectionTool.GetValue<bool>(val, 2);
            if (label.text.Equals(Replace_Value)|| reset)
            {
                label.text = CollectionTool.GetValue<string>(val, 1);
            }
            label.onChange = change;
            return label;
        }
#endif



        public static bool Attach(MonoBehaviour mono,string key)
        {
            bool modify = false;
            LocalizationLabel l = mono.GetComponent<LocalizationLabel>();
         
            if(l==null)
            {
                l = mono.gameObject.AddComponent<LocalizationLabel>();
                modify = true;
            }
          
            if (l.key != key) modify = true;
          
            l.key = key;
            l.label = mono;
            return modify;
        }

        public static string GetText(MonoBehaviour mono)
        {
            LocalizationLabel l = mono.GetComponent<LocalizationLabel>();
            if(l!=null)
            {
             
                return  Localization.GetLocalization(l.key);
            }            
            return "";
        }
    }

}