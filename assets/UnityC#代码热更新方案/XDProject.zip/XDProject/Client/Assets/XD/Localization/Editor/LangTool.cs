﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEditor;
using System.Linq;

namespace XD.Localization.Editor
{


    public static class LangTool
    {


        public delegate bool FilterFunction(string str);
        private static Dictionary<string, FilterFunction> dic = new Dictionary<string, FilterFunction>();

        static LangTool()
        {
            Debug.Log("LangTool Static");
            dic.Add("prefab", FilterUILabel);
            dic.Add("cs", FilterCS);
            dic.Add("lua.txt", FilterLUA);
            Debug.Log("LangTool Static Over");
        }

        public static bool Filter(string type, string str)
        {
            if (dic.ContainsKey("type"))
            {
                FilterFunction f = dic[type];
                return f(str);
            }
            return false;
        }



        private static bool FilterCS(string str)
        {
            return IsJPN(str);
            //return true;
        }

        private static bool FilterLUA(string str)
        {
            return IsJPN(str);
            //return true;
        }
        private static List<string> list = new List<string>() {
            //"LV","Lv","lv","HP","Hp","hp",
            //"ATK","Atk","atk","DEF","Def","def","INT","Int","int",
            //"RES","Res","res","SPD","Spd","spd","MAXHP",
            //"OK","ok","Cancel","cancel","Yes","yes","No","no",
            //"easy","Easy","EASY","normal","Normal","NORMAL","hard","Hard","HARD",
            //"STAGE","Stage","stage","WAVE","Wave","wave"
        };
        public static bool IsJPN(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return false;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(str, @"[\u2e80-\u9fbf]"))//@"[\u1000-\uffff]"))
                                                                                      //if (!System.Text.RegularExpressions.Regex.IsMatch(str, @"^[\0000-\u00ff]"))
                                                                                      //if (!System.Text.RegularExpressions.Regex.IsMatch(str, @"^[\u0000-\u00ff\u4e00-\u9fa5]+$"))
            {
                return true;
            }
            else
            {
                int i = list.FindIndex((f) => Mathf.Abs(str.Length - f.Length) <=5&&str.Contains(f));
                return i>=0;
            }
        }
        public static bool IsJPN2(string str)
        {
            return IsInRange(str, 0x3040, 0x309f, 0x30a0, 0x30ff, 0x4e00, 0x9fbf);
        }

        private static bool IsInRange(string text, params int[] pairs)
        {
            int count = pairs.Length >> 1;
            foreach (char e in text)
            {
                for (int i = 0; i < count; ++i)
                {
                    if (e >= pairs[i << 1] && e <= pairs[(i << 1) + 1])
                    {
                        return true;
                    }
                }
            }
            return false;

        }

        public static string[] charTrim = new string[] { " ", "-", ":", "/", "!", "+", "%", "?", "★", "(", ")", "○", ".", "！", "$", "￥", ",", "♥", "\n", "\r", "％", "×", "x", "０", "１", "２", "３", "４", "５", "６", "７", "８", "９", "◯", "：", "©", "・", "●", "♪", "|", "[", "]", "？", "=", "＝", "◎", "△", "→" };

        public static string FilterString(string value)
        {
            int length = value.Length;
            if (length == 1 && value == "\\" || string.IsNullOrEmpty(value))
            {
                return "";
            }

            foreach (var item in charTrim)
            {
                if (length == 1 && value == item)
                {
                    return "";
                }
            }
            string trimSpace = value;
            foreach (string item in charTrim)
            {
                trimSpace = trimSpace.Replace(item, "");
            }
            if (string.IsNullOrEmpty(trimSpace))
                return "";
            trimSpace = trimSpace.Replace("\\", "");
            bool isNumber = IsNumber(trimSpace);
            if (!isNumber)
            {
                return value;
            }
            return "";

        }
        public static string FormatConst(string str)
        {
            int index = str.IndexOf("const ");
           
            if (index >= 0)
            {
                str = str.Replace("const ", "static ");
                str = str.Replace("=", "{ get {return ");
                str = str.Replace(";", "; } }");
            }
            //index = str.IndexOf("static");
            //if (consted)
            //{
            //    str = str.Replace("=", "{get{return ");
            //    str = str.Replace(";", ";}}");
            //    //if (str[str.Length - 1]=='\n'|| str[str.Length - 1] == '\r')
            //    //{
            //    //    str= str.Insert(str.Length - 1, "}}");
            //    //}
            //    //else
            //    //{
            //    //    str+= "}}";
            //    //}               
            //}
            str = str.Replace("readonly", "");
            return str;
        }
        public static bool FilterUILabel(string value)
        {
            int length = value.Length;
            if (length == 1 && value == "\\" || string.IsNullOrEmpty(value))
            {
                return false;
            }

            foreach (var item in charTrim)
            {
                if (length == 1 && value == item)
                {
                    return true;
                }
            }
            string trimSpace = value;
            foreach (string item in charTrim)
            {
                trimSpace = trimSpace.Replace(item, "");
            }
            if (string.IsNullOrEmpty(trimSpace))
                return true;
            trimSpace = trimSpace.Replace("\\", "");
            bool isNumber = IsNumber(trimSpace);
            if (!isNumber)
            {
                return true;
            }
            return false;

        }
        public static bool IsNumber(string s)
        {
            const string pattern = "^[0-9]+$"; //[0-9a-zA-Z]
            Regex regex = new Regex(pattern);
            return regex.IsMatch(s);
        }

        internal static FilterFunction GetFilter(string v)
        {
            if (dic.ContainsKey(v))
            {
                return dic[v];
            }
            return IsJPN;
        }

       

      
    }
}