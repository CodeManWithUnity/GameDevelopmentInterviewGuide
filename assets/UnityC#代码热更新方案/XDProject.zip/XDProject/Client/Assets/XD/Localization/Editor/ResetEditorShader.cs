﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using UnityEngine.SceneManagement;
using System.Linq;
using Debug = XD.tool.Debug;
using XD.tool;
using System;

public class ResetEditorShader 
{
    [MenuItem("本地化/功能/重置shader  &r", false, 0)]
    public static void Reshader()
    {
       
        //List<Material> thisMaterial = new List<Material>(6);
        //List<string> shaders = new List<string>(6);

        Debug.SetTag(Debug.tag_default, true);
        Debug.Log("-----------重置shader");
        using (new StopWatch("ResetShader", "ResetShader"))
        {
            FindAll();
        }
      

     
    }

    private static void FindAll()
    {
        List<Material> list = new List<Material>();
       
                ResetObjs<Renderer>(list,  (obj) => obj.materials);
                ResetObjs<Image>(list, (obj) => new Material[] { obj.material });
#if LOCALIZATION_UGUI_PRO
                ResetObjs<TMPro.TextMeshProUGUI>(list, (obj) => obj.fontMaterials);
#endif
        
        for (int i = 0; i < list.Count; i++)
        {
            Shader s = list[i].shader;
            list[i].shader = Shader.Find(s.name);
        }
    }

    private static void ResetObjs<T>(List<Material> list, System.Func<T, Material[]> get) where T : Component
    {
        T[] objs = Resources.FindObjectsOfTypeAll<T>();
        //T[] objs = root.GetComponentsInChildren<T>(true);
        int length2 = objs.Length;

        for (int i = 0; i < length2; i++)
        {
            if (objs[i] != null && !string.IsNullOrEmpty(objs[i].gameObject.scene.name))
            {
                try
                {
                    Material[] mats = get(objs[i]);

                    if (mats != null)
                    {
                        for (int j = 0; j < mats.Length; ++j)
                        {
                            Material m = mats[j];
                            if (m != null && !list.Contains(m)) list.Add(m);
                        }
                    }
                }
                catch(Exception e)
                {
                    Debug.Log($"ResetObjs Error={objs[i].name}");
                }
            }
        }
    }
}
