﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using XD.Editor;
using XD.tool;

namespace XD.Localization.Editor
{

    public class LangGenCS
    {
        // Start is called before the first frame update

        private ExcelReader er;
        public LangGenCS(string file)
        {
             er= new ExcelReader(file);
        }

        internal void Gen()
        {
            EditorCoroutineRunner.StartEditorCoroutine(RunGen());
        }
      
        private IEnumerator RunGen()
        {

            EditorUtility.DisplayProgressBar($"正在启动", $"", 0);
            string log_path = $"{LangConstant.Excel_Path_Dir}/Logs/Lang_{DateTime.Now.ToString("yyyy_MM_dd_HH_mm")}.log";
            XDEditorLog.Start(log_path);
            Dictionary<string, string> dic_values=new Dictionary<string, string>();
            for (int i = 0; i < er.GetSheetCount(); ++i)
            {
                yield return ImportSheet(i + 1, dic_values);
            }
            string cs = "LocalizationCS";
            string datapath = $"{Application.dataPath}/Netease/Scripts/{cs}.cs";

            using (StreamWriter sw = File.CreateText(datapath))
            {
                sw.WriteLine("using XD.tool;\n");
                sw.WriteLine("namespace XD.Localization.Runtime");
                sw.WriteLine("{");
                sw.WriteLine($"\t public static class {cs}");
                sw.WriteLine("\t{");
                foreach (KeyValuePair<string, string> pair in dic_values)
                {
                    string key=pair.Key.Replace("/","_").Replace(".","_");
                    sw.WriteLine($"\t\t[SerializeDictionary.Attibute] public static string {key}=\"{pair.Value}\";");
                }
                sw.WriteLine("\t}");
                sw.WriteLine("}");
                sw.Flush();
            }
            AssetDatabase.ImportAsset(string.Format(LangConstant.Localization_Output_Dir, "Assets"), ImportAssetOptions.ImportRecursive | ImportAssetOptions.ForceUpdate);
            er = null;
            XDEditorLog.Flash();
            EditorUtility.ClearProgressBar();
        }

        private IEnumerator ImportSheet(int curr_sheet_index, Dictionary<string, string> dic_values)
        {

            //ExcelRange cells = param.Get<ExcelRange>("cells", null);
            er.SetSheet(curr_sheet_index);


            string sheet_name = er.GetSheetName();
            if (!sheet_name.StartsWith("File"))
            {
                yield break;
            }





            yield return new WaitForSeconds(0.1f);




            //LangLog.Log("Read Curr=" + i);
            int cell_index = 2;
            int total_count = er.GetCellsRows();
            while (cell_index < total_count)
            {
                string key = er.ReadCell(cell_index, "Key");
                if (!string.IsNullOrEmpty(key))
                {

                    string value = er.ReadCell(cell_index, LangType.JPN.ToString());

                   CollectionTool.Add( dic_values,key, value);
                }
                ++cell_index;
                //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
                if ((cell_index - 2) % 100 == 0)
                {
                    XDEditorLog.Log("读取数据 :" + (cell_index - 2) + "/" + (total_count - 2));
                    EditorUtility.DisplayProgressBar($"读取数据 :{sheet_name}", $"{cell_index - 2 }/ {total_count - 2}", 0);
                    yield return new WaitForSeconds(0.1f);
                }

            }



            //dic_fs.Clear();
            //curr_sheet_index++;
            XDEditorLog.Log("读取表单结束:" + sheet_name);


        }

      
    }
}
