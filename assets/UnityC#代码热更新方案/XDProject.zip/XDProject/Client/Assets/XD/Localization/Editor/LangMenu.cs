﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using OfficeOpenXml;
using XD.Localization.Runtime;
// using Poppin.Network;
// using Poppin;
using System.Text;
using System.Linq;
using System.Reflection;
using XD.Editor;
using UnityEngine.SceneManagement;

namespace XD.Localization.Editor
{
    public class LangMenu
    {
        public delegate void  TestDelegate();
        static LangMenu()
        {
            XD.tool.Debug.SetTag(XD.tool.Debug.tag_default, true);
        }

        //[MenuItem("本地化/测试", false, 0)]
        //public static void TestLang()
        //{

        //    //System.Type type = typeof(TestDelegate);
        //    //Debug.Log($"Type={type},BaseType={type.BaseType},DeclaringType={type.DeclaringType},MemberType={type.MemberType}");
        //    //string path = "Assets/AssetBundles/prefabs/no_naming/common/EquipInfo.prefab";
        //    //string attach = "DetailManager/Canvas/EquipInfo(Clone)/inocent_change/anchor_base/equip_plate/status_plate/int_line/big_st_txt";
        //    //GameObject go = AssetDatabase.LoadAssetAtPath(path, typeof(GameObject)) as GameObject;
        //    //bool f1 = go.transform.Find("inocent_change/anchor_base/equip_plate/status_plate/int_line/big_st_txt");
        //    //bool f2 = go.transform.Find("TT/TT2");
        //    //Transform sechild = SearchChild(go, attach);
        //    //string json = "{\"test\":\"\"}";
        //    //IDictionary dic = XD.MiniJSON.Json.Deserialize(json) as IDictionary;
        //    //Debug.Log($"Test Data={XD.tool.CollectionTool.Print(dic)}");
        //    //Debug.Log($"Test Json={dic["test"]}");
        //    //Debug.Log($"Test Json={XD.tool.CollectionTool.GetValue<int>(dic, "test")}");
        //    ////System.Type t = typeof(MasterDataAccesser.DataCache<,>);

        //    ////System.Type type = typeof(List<PubClass>);
        //    //PriClass c;
        //    //TestType(typeof(List<PubClass>),out c);
        //    //TestType(typeof(List<PriClass>),out c);
        //    //Debug.Log($"{IsPublic(typeof(Modifier))}");
        //    //System.Type type_cache = System.Type.GetType("MasterDataAccesser+DataCache`2[ulong,MasterAgendaData],Assembly-CSharp");
        //    //Debug.Log($"Test TestTemp={t},Fullname={t.FullName},Name={t.Name},type_cache={type_cache}");
        //    //MethodInfo m = typeof(LangMenu).GetMethod("TestType", BindingFlags.Static| BindingFlags.Public| BindingFlags.NonPublic);
        //    //XDHotfixEx.SkipPrivateParam(m);
          
        //}

        private static void TestType(System.Type type,out PriClass c)
        {
            c = new PriClass();
            Debug.Log($"Test type={type},{type.IsGenericType},{type.IsGenericParameter}");
            System.Type t2 = type.GetGenericArguments()[0];
            Debug.Log($"Test type={t2},{t2.IsPublic},{t2.IsNotPublic},{IsPublic(t2)}");
            System.Type t3 = c.GetType();
            Debug.Log($"Test T3={t3},{t3.IsPublic},{t3.IsPointer},{IsPublic(t3)}");
        }
        static bool IsPublic(System.Type type)
        {
            if (type.IsNested)
            {
                if (!type.IsNestedPublic)
                    return false;

                if (IsPublic(type.DeclaringType))
                    return true;

                return false;
            }

            return type.IsPublic;
        }
        public enum Modifier
        {

        }
        public class PubClass
        {

        }
        private class PriClass
        {

        }
        public static class TestTemp<TKey,TValue>
        {

        }
        private static Transform SearchChild(GameObject obj, string path)
        {
            //path = path.Replace("/", "\\");
            int end = path.Length;
            int index;
            while (end > 0 && (index = path.LastIndexOf('/', end - 1, end - 1)) >= 0)
            {
                Transform t = obj.transform.Find(path.Substring(index + 1, path.Length - index - 1));
                if (t != null)
                {
                    return t;
                }
                end = index;
            }

            return null;
        }

        public static bool IsJPN(string str)
        {
            return GetCharsInRange(str, 0x3040, 0x309f).Any() || GetCharsInRange(str, 0x30a0, 0x30ff).Any();//||GetCharsInRange(str,0x4e00,0x9fbf).Any();
        }

        private static IEnumerable<char> GetCharsInRange(string text, int min, int max)
        {
            return text.Where(e => e >= min && e <= max);
        }

        public static string OpenFile(string title)
        {
            string file = XDEditorDialog.OpenFilePanel(title, "lang_file", "xlsx");
            return file;
            //return EditorUtility.OpenFilePanel("选择Excel文件", GetExcelDir(), "xlsx");
        }
        public static string GetExcelDir()
        {
            string path = Application.dataPath;
            for (int i = 0; i < 2; ++i)
            {
                int index = path.LastIndexOf("/");
                path = path.Remove(index, path.Length - index);
            }
            string dir = path + "/LanguageFiles";
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            return dir;
        }
        public static string SaveFile()
        {
            return EditorUtility.SaveFilePanel("选择Excel文件", GetExcelDir(), "Lang", "xlsx");
        }

        [MenuItem("本地化/文本/导出/预制体")]
        public static void ExportPrefab()
        {

            string file = SaveFile();
            if (string.IsNullOrEmpty(file))
            {
                return;
            }
            LangPrefabSheet sheet = new LangPrefabSheet(file);
            //LangType l = GetCurrLang();
            sheet.Export();
        }
        [MenuItem("本地化/文本/导出/场景")]
        public static void ExportScene()
        {
            string file = SaveFile();
            if (string.IsNullOrEmpty(file))
            {
                return;
            }
            LangSceneSheet sheet = new LangSceneSheet(file);
            //LangType l = GetCurrLang();
            sheet.Export();
        }
        [MenuItem("本地化/文本/导出/文本")]
        static void ExportFile()
        {
            if (!XDEditorDialog.ShowDialog("提示","请先执行字符串拼接转换.","继续","返回"))
            {
                return;
            }
                string file = SaveFile();
            if (string.IsNullOrEmpty(file))
            {
                return;
            }

            LangSheetFile sheet = new LangSheetFile(file);
            //LangType l = GetCurrLang();
            sheet.Export();

        }

        //public static LangType GetCurrLang()
        //{
        //    return LangType.JPN;
        //}
        [MenuItem("本地化/文本/导入TXT")]
        public static void ImportAll()
        {
            //Debug.Log("開始時間 _" + System.DateTime.Now.ToString());
            //Debug.Log("Start Export UIPrefab Text to excel File!!");
            string file = OpenFile("选择Excel文件");
            if (string.IsNullOrEmpty(file))
            {
                return;
            }

            string dir_path = string.Format(LangConstant.Localization_Output_Dir, Application.dataPath);
            //LangImport imp = new LangImport(file);
            LangImport.ImportAll(file, dir_path);
            string dir_path_old = string.Format(LangConstant.Localization_Output_Dir_Old, Application.dataPath);
            if (Directory.Exists(dir_path_old))
            {
                Directory.Delete(dir_path_old);
            }

        }
       
        //[MenuItem("本地化/停止")]
        //public static void Stop()
        //{
        //    //EditorCoroutineRunner.st
        //    //LangUpdate.Stop();

        //}
        [MenuItem("本地化/文本/生成CS")]
        public static void GenCS()
        {
            string file = OpenFile("选择Excel文件");
            if (string.IsNullOrEmpty(file))
            {
                return;
            }
            LangGenCS imp = new LangGenCS(file);
            imp.Gen();
        }

        [MenuItem("本地化/文本/字符拼接转换")]
        public static void FormatFile()
        {
            LangCSFormat format = new LangCSFormat();

            format.Format();

        }

        [MenuItem("本地化/功能/删除本地资源")]
        public static void DeleteDir()
        {
            if (Directory.Exists(Application.persistentDataPath))
                Directory.Delete(Application.persistentDataPath, true);
            if (Directory.Exists(Application.temporaryCachePath))
                Directory.Delete(Application.temporaryCachePath, true);
        }
        [MenuItem("本地化/功能/重启测试 &k")]
        public static void Reboot()
        {
            if(Application.isPlaying)
            {
                SceneManager.LoadSceneAsync(0);
            }
        }
    }
}