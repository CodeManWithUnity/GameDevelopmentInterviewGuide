﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

using System.Text;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using XD.Editor;
using XD.Editor.Finder;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Editor
{
    public class LangSheetFile : LangSheetBase<LangFile>
    {

        private List<LangSource> list_srcs = new List<LangSource>();
        public LangSheetFile(string file) : base(file)
        {


        }

        
      

        private LangSource GetSrcs(string filepath)
        {
            XDEditorLog.Log("filepath=" + filepath);
            LangSource l = list_srcs.Find(r =>
            {
                return r.Fit(filepath);
            });
            if (l != null)
            {
                return l;
            }
            else
            {
                var src = AssetDatabase.LoadAssetAtPath<TextAsset>(filepath);

                if (src == null)
                {
                    return null;
                }

                LangSource s = ParseManager.Parse(filepath, src);
                list_srcs.Add(s);

                return s;
            }
        }

        //protected override void UpdateExport(IParam param, LangFunction.State state)
        //{

        //    LangType lang = LangMenu.GetCurrLang();
        //    if (lang != LangType.JPN)
        //    {
        //        return;
        //    }
        //    if (state == LangFunction.State.Enter)
        //    {
        //        string[] filepaths = AssetDatabase.FindAssets("t:TextAsset", LangConstant.File_Directionay);
        //        for (int i = 0; i < filepaths.Length; i++)
        //        {
        //            filepaths[i] = AssetDatabase.GUIDToAssetPath(filepaths[i]);
        //        }
        //        List<string> list = new List<string>(filepaths);
        //        list.Sort((string str, string str2) =>
        //        {
        //            int index1 = str.IndexOf('/');
        //            int index2 = str2.IndexOf('/');

        //            string p1 = str.Substring(index1 >= 0 ? index1 : 0);
        //            string p2 = str2.Substring(index2 >= 0 ? index2 : 0);
        //            return string.Compare(p1, p2);
        //        });
        //        filepaths = list.ToArray();
        //        param.SetObject(filepaths);
        //        param.SetTotal(filepaths != null ? filepaths.Length : 0);

        //    }
        //    else if (state == LangFunction.State.Run)
        //    {
        //        string[] filepaths = param.GetObject<string[]>();
        //        int curr_index = param.GetStep();
        //        if (filepaths == null || curr_index >= filepaths.Length)
        //        {
        //            return;
        //        }
        //        string filepath = filepaths[curr_index];

        //        bool exclude = false;
        //        for (int i = 0; i < LangConstant.File_Exclude.Length; ++i)
        //        {
        //            if (filepath.IndexOf(LangConstant.File_Exclude[i]) >= 0)
        //            {
        //                exclude = true;
        //                break;
        //            }
        //        }
        //        if (exclude)
        //        {
        //            return;
        //        }
        //        LangSource lsrc = GetSrcs(filepath, false);
        //        if (lsrc == null || !lsrc.HasData())
        //        {
        //            return;
        //        }
        //        lsrc.Replace(list);
        //        //LangTool.FilterFunction filter_function = GetFilter(filepath);
        //        //bool is_lua = filepath.EndsWith("lua.txt");


        //    }
        //    else if (state == LangFunction.State.Leave)
        //    {
        //        //OutputLocFile(lang, "/loc_asset.txt");
        //        for (int i = 0; i < list_srcs.Count; ++i)
        //        {
        //            list_srcs[i].ModifySources();

        //        }
        //        for (int i = 0; i < LangConstant.File_Directionay.Length; ++i)
        //        {
        //            AssetDatabase.ImportAsset(LangConstant.File_Directionay[i]);
        //        }
        //    }
        //}





        private static LangTool.FilterFunction GetFilter(string filepath)
        {
            LangTool.FilterFunction filter_function = null;
            if (filepath.EndsWith("cs"))
            {
                filter_function = LangTool.GetFilter("cs");
            }
            else if (filepath.EndsWith("lua.txt"))
            {
                filter_function = LangTool.GetFilter("lua.txt");
            }
            else
            {
                filter_function = LangTool.GetFilter("default");

            }

            return filter_function;
        }

        //public override void Export(LangType lang)
        //{
        //    if (lang != LangType.JPN)
        //    {
        //        return;
        //    }

        //    var file_guids = AssetDatabase.FindAssets("t:TextAsset", LangConstant.File_Directionay);

        //    int new_record = 0;
        //    foreach (var guid in file_guids)
        //    {
        //        var filepath = AssetDatabase.GUIDToAssetPath(guid);

        //        bool filter = false;
        //        for(int i=0;i< LangConstant.File_Filter.Length;++i)
        //        {
        //            if (filepath.IndexOf(LangConstant.File_Filter[i]) >= 0 )
        //            {
        //                filter = true;
        //                break;
        //            }
        //        }
        //        if(filter)
        //        {
        //            continue;
        //        }
        //        string[] srcs = GetSrcs(filepath, false);
        //        if (srcs == null)
        //        {
        //            continue;
        //        }            

        //        for (int l = 0; l < srcs.Length; ++l)
        //        {
        //            string line = srcs[l];

        //            LangWord[] ls = ParseWords(line);
        //            if (ls != null && ls.Length > 0)
        //            {
        //                AddToDictionary(filepath, srcs);
        //                for (int j = 0; j < ls.Length; ++j)
        //                {
        //                    LangFile f = GetLangFile(filepath, l, j);
        //                    if (f == null)
        //                    {
        //                        //LangLog.Log(string.Format("New Record={0},{1},{2},{3}", filepath, l, j, list.Count));
        //                        f = new LangFile();
        //                        f.file = filepath;
        //                        f.line = l;
        //                        f.index = j;
        //                        f.SetOri(ls[j].text, LangType.JPN);
        //                        list.Add(f);
        //                        new_record++;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    Log(string.Format("新增了{0}条记录", new_record), LangLog.Type.Log);
        //}

        //private void TestParse()
        //{
        //    string[] srcs = GetSrcs("Assets/TestLang.cs", false);
        //    ParseSource ps = new ParseSource();
        //    ps.Parse(srcs);
        //}

        //private LangWord[] ParseWords(string line, LangTool.FilterFunction fun, bool is_lua)
        //{
        //    if (string.IsNullOrEmpty(line))
        //    {
        //        return null;
        //    }
        //    int index = -1;
        //    List<int> list = new List<int>();
        //    bool is_start = true;
        //    while ((index = line.IndexOf("\"", index + 1)) >= 0)
        //    {
        //        list.Add(is_start ? index + 1 : index);
        //        is_start = !is_start;
        //    }
        //    if (is_lua && list.Count == 0)
        //    {
        //        int l = line.IndexOf(" > ");
        //        l = l < 0 ? line.IndexOf(" < ") : l;
        //        if (l >= 0)
        //        {
        //            list.Add(l + 3);
        //            list.Add(line.Length);
        //        }

        //    }
        //    bool include = false;
        //    if (list.Count > 0)
        //    {
        //        for (int i = 0; i < LangConstant.Txt_Exclude.Length; ++i)
        //        {
        //            if (line.IndexOf(LangConstant.Txt_Exclude[i], 0, list[0]) >= 0)
        //            {
        //                return null;
        //            }
        //        }

        //        for (int i = 0; i < LangConstant.Txt_Include.Length; ++i)
        //        {
        //            if (line.IndexOf(LangConstant.Txt_Include[i], 0, list[0]) >= 0)
        //            {
        //                include = true;
        //                break;
        //            }
        //        }
        //    }

        //    List<LangWord> words = new List<LangWord>();

        //    for (int i = 0; i < list.Count >> 1; ++i)
        //    {
        //        int start = list[i << 1];
        //        int end = list[(i << 1) + 1];
        //        string str = line.Substring(start, end - start).Replace("\r", "");

        //        if (!string.IsNullOrEmpty(str) && (include || fun(str) || str.IndexOf(Localization.Runtime.Localization.Tag_Loc) >= 0))
        //        {
        //            words.Add(new LangWord(start, end, str));
        //        }
        //    }
        //    //return CombineWords(words, line);        
        //    return words.ToArray();
        //}

        //private LangWord[] CombineWords(List<LangWord> list, string line)
        //{

        //    if (list.Count > 1)
        //    {
        //        StringBuilder new_line = new StringBuilder();
        //        new_line.Append(line.Substring(0, list[0].start));
        //        new_line.Append("string.Format(\"");

        //        new_line.Append(list[0].text);
        //        List<string> val = new List<string>();
        //        int va_index = 0;
        //        for (int i = 0; i < list.Count - 1; ++i)
        //        {
        //            int start = list[i].end;
        //            int end = list[i + 1].start;
        //            string va = line.Substring(start + 1, end - start - 1).Trim(new char[] { '+', ' ' });
        //            if (!string.IsNullOrEmpty(va))
        //            {
        //                new_line.Append("{");
        //                new_line.Append(va_index++);
        //                new_line.Append("}");
        //                val.Add(va);
        //            }
        //            new_line.Append(list[i + 1].text);
        //        }
        //        new_line.Append("\",");
        //        for (int i = 0; i < val.Count; ++i)
        //        {
        //            new_line.Append(val[i]);
        //            new_line.Append(i == val.Count - 1 ? ")" : ",");
        //        }
        //        int last = list[list.Count - 1].end;
        //        new_line.Append(line.Substring(last + 1, line.Length - last - 1));
        //        LangLog.Log("new_line=" + new_line);
        //    }
        //    return list.ToArray();
        //}



        //protected override void DoImport(LangFile t, string str)
        //{
        //    //LangLog.Log("dic_srcs=" + list_srcs.Count);
        //    //LangSource l = FindSources(t.file);
        //    //if (l == null)
        //    //{
        //    //    return;
        //    //}
        //    //LangTool.FilterFunction filter_function = GetFilter(t.file);
        //    //bool is_lua = t.file.EndsWith("lua.txt");
        //    //LangWord[] words = ParseWords(l.srcs[t.line], filter_function, is_lua);
        //    //LangWord word = words[t.index];
        //    ////l.srcs[t.line] = l.srcs[t.line].Replace(word.text, str);

        //    //l.srcs[t.line] = l.srcs[t.line].Remove(word.start + 1, word.end - word.start - 1).Insert(word.start + 1, str);
        //    //l.modify = true;
        //    //LangLog.Log(string.Format("DoImport:{0} Replace={1}", word.text, str));

        //}
        //protected override void ImportOver()
        //{
        //    foreach (KeyValuePair<string, LangSource> pair in dic_srcs)
        //    {
        //        LangSource s = pair.Value;
        //        if (s.modify)
        //        {
        //            ModifySources(pair.Key, s.srcs);
        //        }
        //    }
        //}
        //protected override void UpdateImportOver(IParam p, LangFunction.State state)
        //{
        //    if (state == LangFunction.State.Enter)
        //    {
        //        LangType lang = LangMenu.GetCurrLang();
        //        OutputLocFile(lang, "/loc_asset.txt");
        //        //p.SetTotal(list_srcs.Count);
        //    }
        //    else if (state == LangFunction.State.Run)
        //    {
        //        //int curr_index = p.GetStep();

        //        //if (curr_index >= list_srcs.Count)
        //        //{
        //        //    return;
        //        //}
        //        //LangSource s = list_srcs[curr_index];

        //        //if (s.modify)
        //        //{
        //        //    ModifySources(s.file, s.srcs);
        //        //}


        //    }
        //    else if (state == LangFunction.State.Leave)
        //    {

        //    }
        //}
        protected void ModifySources(string path, string[] srcs)
        {
            StringBuilder sb = new StringBuilder();
            string file = Application.dataPath + "/../" + path;
            //using (FileStream file = File.OpenWrite(Application.dataPath + "/../" + pair.Key))
            {
                //using (StreamWriter sw = new StreamWriter(file))
                {
                    for (int i = 0; i < srcs.Length; ++i)
                    {
                        //LangLog.Log(string.Format("Write Line:{0}", srcs[i]));
                        //sw.WriteLine(s.srcs[i]);
                        sb.Append(srcs[i]);
                        sb.Append("\n");
                    }
                }
            }
            File.WriteAllText(file, sb.ToString());
        }



        protected override string GetSheetName()
        {
            return "File";
        }




        protected override void ReadCallback(LangFile t)
        {

            //LangSource lsrc = GetSrcs(t.file);

            //if (lsrc == null)
            //{
            //    t.SetFlag( LangBase.Flag.Lost_Source_Deleted);
            //    return;
            //}
            //lsrc.Serach(t);

        }

        protected override void WriteCallback(LangFile t)
        {

        }

        protected override int SortFuncEx(LangFile l, LangFile r)
        {
            int c = l.file.CompareTo(r.file);
            if (c != 0)
            {
                return c;
            }
            c = l.line - r.line;
            if (c != 0)
            {
                return c;
            }
            c = l.index - r.index;
            return c;
        }

        protected override IEnumerator UpdateExport()
        {

            Action<string> action = (filepath) =>
            {
                bool exclude = false;
                for (int i = 0; i < LangConstant.File_Exclude.Length; ++i)
                {
                    if (filepath.IndexOf(LangConstant.File_Exclude[i]) >= 0)
                    {
                        exclude = true;
                        break;
                    }
                }
                if (exclude)
                {
                    return;
                }
                LangSource lsrc = GetSrcs(filepath);
                if (lsrc == null || !lsrc.HasData())
                {
                    return;
                }
                lsrc.Replace(this);

            };
            yield return Traveral.ForeachText(LangConstant.File_Directionay, action);

            //string[] filepaths = AssetDatabase.FindAssets("t:TextAsset", LangConstant.File_Directionay);
            //for (int i = 0; i < filepaths.Length; i++)
            //{
            //    filepaths[i] = AssetDatabase.GUIDToAssetPath(filepaths[i]);
            //}
            //List<string> list_path = new List<string>(filepaths);
            //list_path.Sort((string str, string str2) =>
            //{
            //    int index1 = str.IndexOf('/');
            //    int index2 = str2.IndexOf('/');

            //    string p1 = str.Substring(index1 >= 0 ? index1 : 0);
            //    string p2 = str2.Substring(index2 >= 0 ? index2 : 0);
            //    return string.Compare(p1, p2);
            //});
            //filepaths = list_path.ToArray();


            //int curr_index = 0;
            //while (curr_index < filepaths.Length)
            //{
            //    string filepath = filepaths[curr_index];
            //    ++curr_index;
            //    bool exclude = false;
            //    for (int i = 0; i < LangConstant.File_Exclude.Length; ++i)
            //    {
            //        if (filepath.IndexOf(LangConstant.File_Exclude[i]) >= 0)
            //        {
            //            exclude = true;
            //            break;
            //        }
            //    }
            //    if (exclude)
            //    {
            //        continue;
            //    }
            //    LangSource lsrc = GetSrcs(filepath);
            //    if (lsrc == null || !lsrc.HasData())
            //    {
            //        continue;
            //    }
            //    lsrc.Replace(this);
               
            //    yield return null;
            //}
            //LangTool.FilterFunction filter_function = GetFilter(filepath);
            //bool is_lua = filepath.EndsWith("lua.txt");

            //OutputLocFile(lang, "/loc_asset.txt");
            for (int i = 0; i < list_srcs.Count; ++i)
            {
                list_srcs[i].ModifySources();

            }
            for (int i = 0; i < LangConstant.File_Directionay.Length; ++i)
            {
                AssetDatabase.ImportAsset(LangConstant.File_Directionay[i]);
            }

        }

        internal override void WriteOver()
        {
           
        }
    }

    public class LangCSFormat
    {

        public void Over(LangUpdate.OverState e)
        {

        }
        public void Format()
        {
            //if (lang != LangType.JPN)
            //{
            //    return;
            //}
            //LangFunction combine = new LangFunction(UpdateModify, 10, "正在解析代码---------");

            //LangFunction[] fun = new LangFunction[] { combine, };
            //LangUpdate.Create(Over, fun);

            EditorCoroutineRunner.StartEditorCoroutine(RunFormat());

        }

        private IEnumerator RunFormat()
        {
            List<CombineSource> list = new List<CombineSource>();
            Action<string> action = (filepath) =>
            {
                bool filter = false;
                for (int j = 0; j < LangConstant.File_Exclude.Length; ++j)
                {
                    if (filepath.IndexOf(LangConstant.File_Exclude[j]) >= 0)
                    {
                        filter = true;
                        break;
                    }
                }
                if (!filter && filepath.EndsWith(".cs"))
                {
                    var src = AssetDatabase.LoadAssetAtPath<TextAsset>(filepath);

                    if (src == null)
                    {
                        return;
                    }

                    CombineSource c = new CombineSource(filepath, src);
                    if (c.modify)
                    {
                        list.Add(c);
                       
                    }
                }
            };
            yield return Traveral.ForeachText(LangConstant.File_Directionay,action);

            for(int i=0;i<list.Count;++i)
            {
                CombineSource c = list[i];
                ModifySources(c.file, c.srcs);
                UnityEditor.EditorUtility.SetDirty(c.asset);
            }
        }

        //private void UpdateModify(IParam p, LangFunction.State state)
        //{
        //    if (state == LangFunction.State.Enter)
        //    {

        //        string[] file_guids = AssetDatabase.FindAssets("t:TextAsset", LangConstant.File_Directionay);
        //        List<string> list = new List<string>();
        //        for (int i = 0; i < file_guids.Length; ++i)
        //        {
        //            string path = AssetDatabase.GUIDToAssetPath(file_guids[i]);
        //            bool filter = false;
        //            for (int j = 0; j < LangConstant.File_Exclude.Length; ++j)
        //            {
        //                if (path.IndexOf(LangConstant.File_Exclude[j]) >= 0)
        //                {
        //                    filter = true;
        //                    break;
        //                }
        //            }
        //            if (!filter && path.EndsWith(".cs"))
        //            {
        //                list.Add(path);
        //            }
        //        }
        //        string[] file_paths = list.ToArray();
        //        p.SetObject(file_paths); ;
        //        p.SetTotal(file_paths.Length);

        //    }
        //    else if (state == LangFunction.State.Run)
        //    {
        //        string[] file_paths = p.GetObject<string[]>();
        //        int curr_index = p.GetStep();
        //        if (file_paths == null || curr_index >= file_paths.Length)
        //        {
        //            return;
        //        }

        //        var filepath = file_paths[curr_index];



        //        var src = AssetDatabase.LoadAssetAtPath<TextAsset>(filepath);

        //        if (src == null)
        //        {
        //            return;
        //        }



        //        CombineSource c = new CombineSource(filepath, src);
        //        if (c.modify)
        //        {
        //            ModifySources(filepath, c.srcs);
        //            UnityEditor.EditorUtility.SetDirty(src);
        //        }

        //        return;
        //    }

        //}

     

        public static void ModifySources(string path, string[] srcs)
        {
        

            StringBuilder sb = new StringBuilder();
            string file = Application.dataPath + "/../" + path;
            //using (FileStream file = File.OpenWrite(Application.dataPath + "/../" + pair.Key))
            {
                //using (StreamWriter sw = new StreamWriter(file))
                {
                    for (int i = 0; i < srcs.Length; ++i)
                    {
                        //LangLog.Log(string.Format("Write Line:{0}", srcs[i]));
                        //sw.WriteLine(s.srcs[i]);                        
                        sb.Append(srcs[i].Replace("\r", ""));
                        if(i!=srcs.Length-1)
                        sb.Append("\n");

                    }
                }
            }
            //FileInfo f = new FileInfo(file);

            File.WriteAllText(file, sb.ToString());
           
        }

        internal static string[] SplitSrcs(string src)
        {          
            return src.Split('\n'); ;
        }

        //public static void ChangeAsmdef()
        //{
        //    Assembly[] playerAssemblies = CompilationPipeline.GetAssemblies();
        //    Assembly a = new List<Assembly>(playerAssemblies).Find((Assembly ass) => {
        //        return ass.name == "Localization";
        //    });
        //    LangLog.Log("Find Assemby=" + a);
        //    for (int i = 0; i < playerAssemblies.Length; ++i)
        //    {
        //        Assembly b = playerAssemblies[i];
        //        if (b != a)
        //        {
        //            Assembly[] ass = new Assembly[b.assemblyReferences.Length+1];
        //            System.Array.Copy(b.assemblyReferences, ass, b.assemblyReferences.Length );
        //            ass[b.assemblyReferences.Length] = a;
        //            new Assembly(b.name, b.outputPath, b.sourceFiles, b.defines, ass, b.compiledAssemblyReferences, b.flags);
        //        }
        //        CompilationPipeline.
        //    }
        //}
    }
}