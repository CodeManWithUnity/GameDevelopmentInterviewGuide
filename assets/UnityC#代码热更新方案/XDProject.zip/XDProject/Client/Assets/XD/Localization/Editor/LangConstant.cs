﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XD.Localization.Editor
{
    public static class LangConstant
    {
        public static string Excel_Path_Dir = Application.dataPath + "/../../LanguageFiles/";

        public static string File_Excel = "Lang.xlsx";
        public static string Localization_Output_Dir_Old = "{0}/XD/Resources/Localization";
        public static string Localization_Output_Dir = "{0}/Netease/Resources/Localization";
        public static string Localization_Output_File = "{0}/{1}/loc_{2}.txt";
        public static string[] Prefab_Directionay = new string[] { "Assets" };
        public static string[] File_Directionay = new string[] { /*"Assets/Test"*/"Assets/Scripts", "Assets/Orange/Scripts" };

        public static string[] File_Exclude = new string[] { "/Language/", "Editor", "NGUI", "Debug", "Externals", "ai_behaviour" };

        public static string[] Txt_Exclude = new string[] { "Debug", "//", "/*", "--", "dump", "ActivityLogger", "[Header", "[MenuItem", "Tooltip(", "Tooltip (" };

        public static string[] Txt_Include = new string[] { /*"label", "telop", "serif"*/ };

        public static bool Clean_Excel = false;
        
    }
}