﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using XD.Localization.Editor;
using System.Linq;

public class ExcelReader : System.IDisposable
{
    private string file;
    private static ExcelPackage CreatePackage(string filepath)
    {
        //string fileName = LangConstant.File_Excel;
        //string path = LangConstant.Excel_Path_Dir;
        //if (!Directory.Exists(path))
        //{
        //    Directory.CreateDirectory(path);
        //}
        //string filepath = path + "/" + fileName;

        FileInfo newFile = new FileInfo(filepath);

        ExcelPackage package = new ExcelPackage(newFile);
        return package;
    }
    public ExcelReader(string file)
    {
        this.file = file;
        package = CreatePackage(file);
        dic_read_index = new Dictionary<string, int>();
    }

    private int cell_offset = 2;
    private List<string> ori_sheet = new List<string>()
    {
        "Location","Key","Modify","Flag","JPN",
    };

    //public static string[] GetTitles()
    //{
    //    string[] titles = new string[(int)LangType.END + 5];
    //    int offset = 0;
    //    titles[offset++] = "Location";
    //    titles[offset++] = "Key";
    //    titles[offset++] = "Modify";
    //    titles[offset++] = "Flag";
    //    for (LangType i = LangType.JPN; i < LangType.END; ++i)
    //    {
    //        titles[offset++] = i.ToString();
    //    }
    //    return titles;

    //}
    public void InitSheet(string sheetname)
    {

        ExcelWorksheets worksheet = package.Workbook.Worksheets;
        ExcelWorksheet sheet = worksheet[sheetname];
        string[] old_titles = dic_read_index.Keys.ToArray();
        if (sheet != null)
        {
            sheet.Cells.Clear();
            dic_read_index.Clear();
        }
        else
        {
            sheet = worksheet.Add(sheetname);
        }
        List<string> titles = new List<string>();
        titles.AddRange(ori_sheet);
        if (old_titles != null)
        {
            for (int i = 0; i < old_titles.Length; ++i)
            {
                if (!titles.Contains(old_titles[i]))
                {
                    titles.Add(old_titles[i]);
                }
            }
        }
       
       
        cells = sheet.Cells;

        for (int i = 0; i < titles.Count; ++i)
        {
            cells[1, i + 1].Value = titles[i];
        }
        ReadTitles();
        cell_offset = 2;
    }
    public void SetSheet(int curr_sheet_index)
    {

        ExcelWorksheet sheet = package.Workbook.Worksheets[curr_sheet_index];
        ReloadSheet(sheet);
    }
    private ExcelWorksheet sheet;
    private void ReloadSheet(ExcelWorksheet sheet)
    {
        this.sheet = sheet;
        dic_read_index.Clear();
        if (sheet != null)
        {
            cells = sheet.Cells;
        }
        else
        {
            cells = null;
        }
        ReadTitles();
    }
    public void ReadTitles()
    {
        if (cells != null)
        {
            int cols = GetCellsCols();
            for (int i = 1; i < cols; ++i)
            {
                dic_read_index.Add(cells[1, i].Text, i);
            }
        }
    }

    public void SetSheet(string name)
    {
        dic_read_index.Clear();
        ExcelWorksheet sheet = package.Workbook.Worksheets[name];
        ReloadSheet(sheet);
    }
    public int GetCellsCols()
    {
        if (cells == null)
        {
            return -1;
        }
        int min = 1;
        int max = 100;
        int center;

        while ((!string.IsNullOrEmpty((string)cells[1, max].Value)))
        {
            min = max;
            max = max << 1;
        }
        while (min < max)
        {
            center = (min + max) >> 1;
            string value = (string)cells[1, center].Text;
            if (value == "#END")
            {

                return center;
            }
            else if (string.IsNullOrEmpty(value))
            {
                max = center - 1;
            }
            else
            {
                min = center + 1;
            }

        }
        Debug.Log($"Out min={min},max={max}");
        return max+1;

    }
    public int GetCellsRows()
    {
        if (cells == null)
        {
            return -1;
        }
        int min = 1;
        int max = 10000;
        int center;

        while ((!string.IsNullOrEmpty((string)cells[max, 1].Text)))
        {
            min = max;
            max = max << 1;
        }
        while (min < max)
        {
            center = (min + max) >> 1;
            string value = (string)cells[center, 1].Text;
            if (value == "#END")
            {

                return center;
            }
            else if (string.IsNullOrEmpty(value))
            {
                max = center - 1;
            }
            else
            {
                min = center + 1;
            }

        }
        Debug.Log($"Out min={min},max={max}");
        return max+1;

    }

    private Dictionary<string, int> dic_read_index;
    private ExcelPackage package;
    private ExcelRange cells;
    private int GetCellsIndex(string title)
    {

        if (dic_read_index.ContainsKey(title))
        {
            return dic_read_index[title];
        }
        if (cells != null)
        {
            for (int i = 1; i <= 20; ++i)
            {
                if ((string)cells[1, i].Text == title)
                {
                    dic_read_index.Add(title, i);
                    return i;
                }
            }
        }
        dic_read_index.Add(title, -1);
        return -1;
    }

    internal void Save()
    {
        package.Save();
    }

    public string ReadCell(int cell_index, string title)
    {
        int col = GetCellsIndex(title);
        if (col > 0)
        {
            return LangWord.Format((string)cells[cell_index, col].Text);
        }
        return "";
    }
    public void WriteCell(int cell_index, string title, string value)
    {
        int index = GetCellsIndex(title);
        if (index > 0)
        {
            cells[cell_index, index].Value = LangWord.Format(value);
        }

    }
    public void Dispose()
    {
        package = null;
    }



    internal void WriteEnd()
    {
        //cells[cell_offset, 1].Value = "#END";
    }

    internal int GetSheetCount()
    {
        return package.Workbook.Worksheets.Count;
    }

    internal string GetSheetName()
    {
        return sheet.Name;
    }

    internal Dictionary<string, string> ReadOther(int cell_index)
    {
        Dictionary<string, string> dic = new Dictionary<string, string>();
        foreach (KeyValuePair<string, int> pair in dic_read_index)
        {
            string key = pair.Key;
            if (!ori_sheet.Contains(key))
                dic.Add(key, ReadCell(cell_index, pair.Key));
        }
        return dic;
    }
}
