﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace XD.Localization.Editor
{
    public class ParseLua : ParseBase
    {
        private ParseFunction[] keys;
        public ParseLua() : base()
        {
            dic_verify.Add("--", VerifyClear);
            dic_verify.Add("dump", VerifyClear);
            dic_verify.Add("function", VerifyClear);
             keys = new ParseFunction[] { new ParseFunction("telop",new int[]{0} ),
               new ParseFunction("serif",new int[]{0,1} ),
                new ParseFunction("show_tutorial_dialog",new int[]{0,1} ),
                  new ParseFunction("set_tutorial_tap_do_action",new int[]{0,1} ),
                   new ParseFunction("set_tutorial_tap_end_action",new int[]{0,1} ),
                    new ParseFunction("set_tutorial_tap_active_skill_1",new int[]{0,1} ),
                     new ParseFunction("set_tutorial_tap_active_skill_2",new int[]{0,1} ),
                      new ParseFunction("set_tutorial_tap_cell",new int[]{0,1} ),
            };
        }
        private class ParseFunction
        {
            public string key;
            public int[] index;

            public ParseFunction(string key, int[] index)
            {
                this.key = key;
                this.index = index;
            }
        }

        private static List<LangWord> ParseELuaF(string line)
        {
            List<LangWord> list = new List<LangWord>();


            string[] spl = line.Split(new char[] { '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (spl.Length>=4&&(spl[1] == ">" || spl[1] == "<"))
            {

                int index = line.IndexOf(spl[1], 0);
                index = line.IndexOf(spl[2], index + 1);
                list.Add(new LangWord(index,index+spl[2].Length,spl[2]));
                index = index + spl[2].Length;
                index = line.IndexOf(spl[3], index + 1);
                list.Add(new LangWord(index, index + spl[3].Length, spl[3]));
                //Debug.Log("ParseELuaF=" + spl[2] + "  " + spl[3]);
                return list;
            }
            return null;
        }
  

        private List<LangWord> ParseLuaF(string line, int line_index)
        {
            List<int> list = null;
           

            for (int i = 0; i < keys.Length; ++i)
            {
                ParseFunction fun = keys[i];
                int start = line.IndexOf(fun.key);
                if (start < 0)
                {
                    continue;
                }
                else
                {
                    list = ParseSymbol(line, start);
                    List<LangWord> l = ParseIndex(line, list);
                    List<LangWord> ll = new List<LangWord>();
                    //Debug.Log("Parse=" + fun.key + "   " + l.Count + "  " + line + "  " + CollectionTool.Print(fun.index));
                    for (int j = 0; j < fun.index.Length; ++j)
                    {
                        if (fun.index[j] < l.Count)
                        {
                            ll.Add(l[fun.index[j]]);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    return ll;                  
                }
            }
            return ParseELuaF(line);
        }

        //public override ParseWord GetParse()
        //{
        //    return ParseLuaF;
        //}

        //public override VerifyFun GetVerify()
        //{
        //    return VerifyNone;
        //}

        public override int GetPriority()
        {
            return 10;
        }

        public override bool Filter(string file)
        {
            //dic_process.Add("e.lua.txt",new ParseLua());
            //dic_process.Add("e.txt", new ParseLua());
            //dic_process.Add("e.lua..txt", new ParseLua());
            //dic_process.Add("e.lua.txt.txt", new ParseLua());
            //dic_process.Add(".lua.txt", new ParseLua());
            //dic_process.Add("LuaRoot", new ParseLua());
            return file.Contains("e.lua.txt") || file.Contains("e.txt") || file.Contains("e.lua..txt") || file.Contains("e.lua.txt.txt") || file.Contains(".lua.txt") || file.Contains("LuaRoot");
        }
        internal override LangSource Parse(string file,TextAsset src)
        {
           string[] srcs = src.text.Split('\n');
            List<LangWord> list = new List<LangWord>();
            for (int i = 0; i < srcs.Length; ++i)
            {
                string line = srcs[i];
                List<LangWord> list_words = ParseLuaF(line, i);
              
                if (list_words != null && list_words.Count > 0)
                {
                    //list.Add(new LangLine(i, list_words));
                    for (int j = 0; j < list_words.Count; ++j)
                    {
                        Dictionary<string, object> dic = new Dictionary<string, object>() { { "file", file }, { "line", i }, { "index", j } };
                        list_words[j].SetLocation(dic);
                    }
                    list.AddRange(list_words);
                }
            }
            return new LangSource(file,src, list,new ModifyLua(srcs));
        }
        public class ModifyLua : ModifyHandler
        {
            private string[] srcs;

            public ModifyLua(string[] srcs)
            {
                this.srcs = srcs;
            }

            public void Modify(LangFile f, LangWord word)
            {
                string str = srcs[f.line];

                string new_string;
                int fix = 0;

                new_string = f.key;
                str = str.Remove(word.start, word.end - word.start + fix).Insert(word.start, new_string);

                srcs[f.line] = str;
            }
            public string ExcuteKey(LangFile f)
            {
                return f.NormalKey();
            }
            public void Save(string file)
            {
                LangCSFormat.ModifySources(file, srcs);
            }
        }
    }

}