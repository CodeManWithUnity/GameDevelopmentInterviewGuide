using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using Debug = XD.tool.Debug;

namespace XD.Localization.Runtime
{
    [System.Serializable]
    public partial class LocalizationAsset
    {
        public string name;
        public string hash;
        public long size;
        public uint crc;
    }
    [System.Serializable]
    public partial class LocalizationAssetList
    {
        [UnityEngine.SerializeField]
        public List<LocalizationAsset> resources= new List<LocalizationAsset>();

        public LocalizationAsset Find(string file)
        {
            return resources.Find((LocalizationAsset asset) => { return asset.name == file; });
        }
        public void Add(LocalizationAsset asset)
        {

        }
        public void Remove(LocalizationAsset asset)
        {

        }
        public string ToJsonString()
        {
            return UnityEngine.JsonUtility.ToJson(this);
        }

        public void AddOrUpdate(LocalizationAsset info)
        {
            LocalizationAsset oldInfo = Find(info.name);

            if (oldInfo == null)
            {
                resources.Add(info);

            }
            else
            {
                //if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.Log(string.Format("Update Info =[{0}] To[{1}]", oldInfo.hash, info.hash));
                oldInfo.name = info.name;
                oldInfo.hash = info.hash;
                oldInfo.size = info.size;
                oldInfo.crc = info.crc;
               
            }
        }
    }

    public partial class LocalizationDownload
    {


        static public LocalizationDownload instance
        {
            get
            {
                if (mInstance == null)
                {
                    mInstance = new LocalizationDownload();
                }
                return mInstance;
            }

        }
        static private LocalizationDownload mInstance = null;

        public LocalizationAssetList total_list;
        public LocalizationAssetList local_list;

      

        IEnumerator FetchJSON(string remote_json_url, System.Action<string> on_success, System.Action<string> on_error)
        {
            //WWW www = new WWW(remote_json_url);
            UnityWebRequest www = UnityWebRequest.Get(remote_json_url);
            www.SendWebRequest();
            float timeout = 0;
            float recent_progress = 0;
            while (!www.isDone)
            {
                yield return null;
                if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.Log(www.downloadProgress);
                if (recent_progress < www.downloadProgress)
                {
                    timeout = 0;
                    recent_progress = www.downloadProgress;
                }
                else
                {
                    timeout += Time.deltaTime;
                    if (10 < timeout)
                    {
                        www.Dispose();
                        on_error("timeout");
                        yield break;
                    }
                }
            }
            if (!string.IsNullOrEmpty(www.error))
            {
                on_error(www.error);
                www.Dispose();
                yield break;
            }

            string remote_json = www.downloadHandler.text;
            www.Dispose();

            on_success(remote_json);
        }
        public static string installTargetPath
        {
            get
            {
                return Application.persistentDataPath + "/Localization";
            }
        }

        public static string localManifestFilePath
        {
            get
            {
                return Path.Combine(installTargetPath, "asset.json");
            }
        }
        private string basicUrl;
        private long needInstallBytes;
        private long downloaded = 0;
        public static string platform
        {
            get
            {
                if (Application.platform == RuntimePlatform.OSXEditor)
                {
                    return "osx";
                }
                else if (Application.platform == RuntimePlatform.WindowsEditor)
                {
                    return "windows";
                }
                else if (Application.platform == RuntimePlatform.Android)
                {
                    return "android";
                }
                else if (Application.platform == RuntimePlatform.IPhonePlayer)
                {
                    return "ios";
                }
                return "";
            }
        }
        public IEnumerator LoadAssetBundles(string asset_path )
        {
            basicUrl = asset_path+ platform + "/"+Localization.Lang;
            string remote_json_url = basicUrl + "/asset.json";
            //Localization.LoadResources();
#if UNITY_EDITOR
            if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.LogWarning("LocalizationDownload Initialize :" + remote_json_url);
#endif
           
            if (!Directory.Exists(installTargetPath))
            {
                Directory.CreateDirectory(installTargetPath);
            }

            string remote_json = "";
            string www_error = "";
            bool success = false;
            int retry = 5;
            if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.Log("remote_json_url="+remote_json_url);
            while (!success && 0 < retry)
            {
                yield return FetchJSON(remote_json_url, (string result) =>
                {
                    remote_json = result;
                    success = true;
                }, (string error) =>
                {
                    retry--;
                    www_error = error;
                });
            }
            if (!success)
            {
                if(XD.tool.Debug.IsTagEnable("LogError"))Debug.LogError(www_error);
                yield break;
            }

            total_list = JsonUtility.FromJson<LocalizationAssetList>(remote_json);
            local_list = new LocalizationAssetList();
            if (File.Exists(localManifestFilePath))
            {
                string json = File.ReadAllText(localManifestFilePath);
                local_list = JsonUtility.FromJson<LocalizationAssetList>(json);
            }

            DeleteOldFile();

            List<LocalizationAsset> down_list = new List<LocalizationAsset>();
            for (int i = 0; i < total_list.resources.Count; ++i)
            {
                LocalizationAsset asset = total_list.resources[i];
                LocalizationAsset old = local_list.Find(asset.name);
                if (old == null || old.hash != asset.hash)
                {
                    down_list.Add(asset);
                }
            }
            yield return  DownloadAseet(down_list);

            yield return Localization.LoadAssetList(down_list);

        }

      

        private IEnumerator DownloadAseet(List<LocalizationAsset> down_list)
        {
           
            foreach (var item in down_list)
            {
                needInstallBytes += item.size;
            }
            for (int i = 0; i < down_list.Count; ++i)
            {
                yield return DownloadAsset(down_list[i]);
            }
        }

        private void DeleteOldFile()
        {
            bool deleted = false;
            for (int i = local_list.resources.Count - 1; i >= 0; --i)
            {
                LocalizationAsset asset = local_list.resources[i];
                if (total_list.Find(asset.name) == null)
                {
                    string save_path = Path.Combine(installTargetPath, asset.name);
                    if (File.Exists(save_path))
                    {
                        File.Delete(save_path);
                    }
                    local_list.resources.Remove(asset);
                    deleted = true;
                }
            }
            if (deleted)
            {
                File.WriteAllText(localManifestFilePath, local_list.ToJsonString());
            }
        }



        class FileDownloadHandler : DownloadHandlerScript
        {
            FileStream fs;
            int offset = 0;
            int length = 0;

            System.Action<Exception> _onException;

            public FileDownloadHandler(string path, byte[] buffer, System.Action<Exception> on_exception) : base(buffer)
            {
                fs = new FileStream(path, FileMode.Create, FileAccess.Write);
                _onException = on_exception;
            }

            public void Abort()
            {
                if (null != fs)
                {
                    fs.Close();
                }
                fs = null;
            }

            protected override bool ReceiveData(byte[] data, int dataLength)
            {
                try
                {
                    fs.Write(data, 0, dataLength);
                }
                catch (System.Exception e)
                {
                    fs.Close();
                    fs = null;
                    _onException(e);
                    return false;
                }
                offset += dataLength;
                return true;
            }
            protected override void CompleteContent()
            {
                fs.Flush();
                fs.Close();
                fs = null;
            }
            protected override void ReceiveContentLength(int contentLength)
            {
                length = contentLength;
            }
            protected override float GetProgress()
            {
                if (length == 0)
                {
                    return 0.0f;
                }

                return (float)offset / length;
            }
        }

        public event Func<Exception, IEnumerator> onDownloadException;
        private IEnumerator DownloadAsset(LocalizationAsset info)
        {
            bool success = false;
            int retry_count = 5;
            int retry_interval = 3;
            byte[] buffer = new byte[256 * 1024];
            Exception _exception = null;
            UnityWebRequest mCurrentRequest = null;
            while (!success)
            {
                if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.Log("DownloadAsset------------"+Path.Combine(basicUrl, info.name));
                mCurrentRequest = UnityWebRequest.Get(Path.Combine(basicUrl, info.name));

                string save_path = Path.Combine(installTargetPath, info.name);
                FileDownloadHandler handler = new FileDownloadHandler(save_path, buffer, (obj) => _exception = obj);
                mCurrentRequest.downloadHandler = handler;
                mCurrentRequest.SendWebRequest();
                float timeout = 0;
                float recent_progress = 0;
                while (!mCurrentRequest.isDone)
                {
                    yield return null;

                    if (Input.GetKey(KeyCode.E))
                    {
                        handler.Abort();
                        mCurrentRequest.downloadHandler.Dispose();
                        mCurrentRequest.Abort();
                        break;
                    }

                    if (recent_progress < mCurrentRequest.downloadProgress)
                    {
                        recent_progress = mCurrentRequest.downloadProgress;
                        timeout = 0;
                    }
                    else
                    {
                        timeout += Time.deltaTime;
                        if (5 < timeout)
                        {
                            handler.Abort();
                            mCurrentRequest.downloadHandler.Dispose();
                            mCurrentRequest.Abort();
                            break;
                        }
                    }
                }

                if (null != _exception)
                {
                    long bt = needInstallBytes - downloaded;
                    string size = "";
                    if (1024 * 1024 < bt)
                    {
                        size = Mathf.Ceil((bt / 1024) / 1024f) + " MBytes";
                    }
                    else if (1024 < bt)
                    {
                        size = Mathf.Ceil(bt / 1024f) + " KBytes";
                    }
                    else if (0 < bt)
                    {
                        size = bt + " Bytes";
                    }
                    yield return onDownloadException(new Exception(string.Format(XD.Localization.Runtime.Localization.GetLocalization("Loc_AssetInstaller_559_0"), size)));
                    handler.Abort();
                    mCurrentRequest.downloadHandler.Dispose();
                    mCurrentRequest.Dispose();
                    mCurrentRequest = null;
                    yield break;
                }

                if (!mCurrentRequest.isDone /*|| Application.internetReachability == NetworkReachability.NotReachable*/ || mCurrentRequest.isNetworkError || mCurrentRequest.isHttpError || mCurrentRequest.responseCode != 200)
                {
                    string err = mCurrentRequest.error;
                    if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.LogWarning(mCurrentRequest.isDone + "," + err + "," + Application.internetReachability + "," + mCurrentRequest.responseCode);

                    handler.Abort();
                    mCurrentRequest.downloadHandler.Dispose();
                    mCurrentRequest.Dispose();
                    mCurrentRequest = null;

                    if (retry_count <= 0)
                    {
                        yield return onDownloadException(new Exception(XD.Localization.Runtime.Localization.GetLocalization("Loc_AssetInstaller_579_0")));

                    }

                    retry_count--;
                    yield return new WaitForSeconds(retry_interval++);
                    continue;
                }

                success = true;
            }
            buffer = null;


            mCurrentRequest.Dispose();
            mCurrentRequest = null;

            local_list.AddOrUpdate(info);
            // たまに保存
            downloaded += info.size;
            File.WriteAllText(localManifestFilePath, local_list.ToJsonString());
            if(XD.tool.Debug.IsTagEnable("LocalizationDownload"))Debug.Log("WriteAllText="+local_list.ToJsonString());
            downloaded = 0;
        }

    }

}