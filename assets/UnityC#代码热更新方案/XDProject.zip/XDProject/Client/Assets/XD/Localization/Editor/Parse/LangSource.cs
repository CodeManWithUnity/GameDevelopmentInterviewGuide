﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.tool;
using Debug = XD.tool.Debug;

namespace XD.Localization.Editor
{
    internal class LangSource
    {
        private string file;
        private bool modify;
        //private string[] srcs;
        private ParseBase.ModifyHandler modify_handler;
        private TextAsset asset;
        private List<LangWord> parse_lines;


        public LangSource(string file, TextAsset asset,List<LangWord> parse_lines, ParseBase.ModifyHandler modify_handler)
        {
            this.file = file;
            this.modify_handler = modify_handler;
            //this.srcs = asset.text.Split('\n');
            this.asset = asset;
            modify = false;

            this.parse_lines = parse_lines;

        }

        public bool HasData()
        {
            return (parse_lines != null && parse_lines.Count > 0);
        }

       
        //internal LangWord[] GetParseLine(int line)
        //{
        //    if (parse_lines == null)
        //    {
        //        return null;
        //    }
        //    LangLine list = parse_lines.Find((l) => { return l.line == line; });
        //    if (list != null)
        //    {
        //        return list.words.ToArray();
        //    }
        //    return null;

        //}

        internal bool Fit(string key)
        {
            return file == key;
        }

        //internal void Serach(LangFile t)
        //{
        //    if (parse_lines == null || parse_lines.Count <= 0)
        //    {
        //        t.SetFlag( LangBase.Flag.Lost_Source_Deleted);
        //        return;
        //    }
        //    LangWord word = parse_lines.FindLast((l) =>
        //        LangBase.CheckLocation(t.dic_location, l.dic_location)
        //    );
        //    if (word != null)
        //    {
        //        if (CompareWith(t, word))
        //        {
        //            t.SetFit();
        //            t.SetOri(word.text, LangType.JPN);
        //            return ;
        //        }
        //    }
        //    word = parse_lines.FindLast(l =>
        //    {
        //        return CompareWith(t, l);
        //    });
        //    if (word != null)
        //    {
        //        //t.SetLocation(word.dic_location);
        //        t.SetOri(word.text, LangType.JPN);
        //        return ;
        //    }
        //    //t.SetLost(LangBase.Flag.Lost_End);

        //    Debug.LogWarning("Lost At End=" + t);
        //    return ;

        //}
        //internal void Serach(LangFile t)
        //{
        //    if (parse_lines == null || parse_lines.Count <= 0)
        //    {
        //        t.SetLost();
        //        return;
        //    }

        //    //if (t.line >= srcs.Length)
        //    //{
        //    //    t.SetLost();
        //    //    return;
        //    //}
        //    //string[] srcs = lsrc.srcs;
        //    //LangTool.FilterFunction filter_function = GetFilter(t.file);
        //    //bool is_lua = t.file.EndsWith("lua.txt");
        //    //LangWord[] words = ParseWords(srcs[t.line], filter_function, is_lua);
        //    LangWord[] words = GetParseLine(t.line);
        //    //Debug.Log("Lang File=" + t);
        //    //Debug.Log("words Line=" + CollectionTool.Print(words));
        //    if (words != null && t.index < words.Length && CompareWith(t, words[t.index]))
        //    {
        //        //Debug.LogWarning("Fit Text=" + t.lang_list[0] + "  " + t.index);
        //        t.SetFit();
        //        t.SetOri(words[t.index].text, LangType.JPN);
        //        return;
        //    }


        //    //if (words!=null&&words.Length >= 2)
        //    //{
        //    //    string lang = t.lang_list[0].Replace("/","").Replace("\r","\n");
        //    //    int index1 = lang.IndexOf(words[0].text);
        //    //    int index2 = lang.IndexOf(words[1].text.Replace("/","").Replace("\r","\n"), index1 + words[0].text.Length);
        //    //    //if (t.file == "Assets/A3Nene/BundleSource/LuaRoot/cutscene/b/que_advent_30012_02_01e.lua.txt") 
        //    //    //{
        //    //    //    Debug.LogWarning(string.Format("-------------------------------------Test File=[{0}],Word=[{1}]&[{2}],index={3}&{4}", t.lang_list[0], words[0].text, words[1].text, index1, index2));
        //    //    //}
        //    //    if (index1 >= 0 && index2 > index1)
        //    //    {

        //    //        LangFile f1 = new LangFile();
        //    //        f1.file = t.file;
        //    //        f1.line = t.line;
        //    //        f1.index = 0;
        //    //        LangFile f2 = new LangFile();
        //    //        f2.file = t.file;
        //    //        f2.line = t.line;
        //    //        f2.index = 1;

        //    //        for (LangType l = LangType.JPN; l < LangType.END; ++l)
        //    //        {
        //    //            string s_ori = t.lang_list[(int)l];
        //    //            if (!string.IsNullOrEmpty(s_ori))
        //    //            {
        //    //                string[] s = s_ori.Split(new char[] { '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries);

        //    //                f1.SetOri(s.Length > 0 ? s[0] : "", l);

        //    //                f2.SetOri(s.Length > 1 ? s[1] : "", l);
        //    //            }

        //    //        }

        //    //        f1.SetSpilt();
        //    //        f2.SetSpilt();
        //    //        list.Add(f1);
        //    //        list.Add(f2);

        //    //        Debug.Log(string.Format("文本分离=[{0}] To[{1}][{2}] Line=[{3}]&[{4}]", t.lang_list[0], f1.lang_list[0], f2.lang_list[0], t.line, t.line));
        //    //        t.SetLost();
        //    //        return;
        //    //    }
        //    //}


        //    for (int i = 0; i < parse_lines.Count; ++i)
        //    {
        //        //LangWord[] words_new = ParseWords(srcs[i], filter_function, is_lua);
        //        LangLine line = parse_lines[i];
        //        LangWord[] words_new = parse_lines[i].words.ToArray();

        //        if (words_new != null)
        //        {

        //            for (int j = words_new.Length - 1; j > 0; --j)
        //            {
        //                if (CompareWith(t, words_new[j])/*||words_new[j].text==t.key*/)
        //                {
        //                    //Debug.LogWarning("Fit New=" + words_new[j].text + "  ,line=" + line.line + " , index=" + j);
        //                    t.UpdateLine(line.line, j);
        //                    t.SetOri(words_new[j].text, LangType.JPN);
        //                    return;
        //                }
        //            }
        //        }
        //    }
        //    t.SetLost();

        //    Debug.LogWarning("Lost At End=" + t);
        //}
        public static bool CompareWith(LangFile l, LangWord w)
        {

            if (l.key == w.text)
            {
                return true;
            }
            if (l.lang_ori == w.text)
            {
                return true;
            }
            if (Mathf.Abs(l.lang_ori.Length - w.text.Length) >= 2)
            {
                return false;
            }
            //Debug.Log("CompareWith l.key="+l.key+ "   ,l.lang_list[0]=" + l.lang_list[0] + "  ,w.text=" + w.text);
            if (l.lang_ori.IndexOf(w.text) > 0)
            {
                return true;
            }
            if (w.text.IndexOf(l.lang_ori) > 0)
            {
                return true;
            }
            return false;
        }
        private LangFile GetLangFile(List<LangFile> list, string filepath, int line, int index)
        {
            return list.FindLast((LangFile l) =>
            {
                return l.file == filepath && ((l.line == line && l.index == index)) && !l.is_lost;
            });
        }
        internal void Replace(LangSheetFile sheet)
        {
            //for (int l = 0; l < parse_lines.Count; ++l)
            {
                //string line = lsrc.srcs[l];

                //LangWord[] ls = ParseWords(line, filter_function, is_lua);
                //LangLine line = parse_lines[l];
                LangWord[] ls = parse_lines.ToArray();
                if (ls != null && ls.Length > 0)
                {
                    //AddToDictionary(filepath, lsrc);

                    for (int j = ls.Length - 1; j >= 0; --j)
                    {
                        Dictionary<string, object> dic = ls[j].dic_location;//new Dictionary<string, object>() { { "file", file }, { "line", line.line }, { "index", j } };
                        //LangFile f = GetLangFile(list, file, line.line, j);
                        //LangBase.Flag flag = LangBase.Flag.Append;
                        LangFile f = sheet.GetLangData(dic,ls[j].text,ls[j].text);
                        //if (f == null)
                        //{
                        //    //Debug.Log(string.Format("New Record={0},{1},{2},{3}", filepath, l, j, list.Count));
                        //    f = new LangFile();
                           
                        //    //f.file = file;
                        //    //f.line = line.line;
                        //    //f.index = j;
                        //    f.SetOri(ls[j].text, LangType.JPN);
                        //    sheet.Add(f);
                        //}
                        //f.SetLocation(dic);
                        
                        ReplaceLocalization(f, ls[j]);

                    }
                }
            }
        }
        private void ReplaceLocalization(LangFile f, LangWord word)
        {
           
            f.key= modify_handler.ExcuteKey(f);
            if (!f.is_lost && (!string.IsNullOrEmpty(f.key) && word.text != f.key))
            {
                //Debug.Log("ReplaceLocalization=" + lsrc.file);
                //if (lsrc.file.Contains("master_first_view_tutorial"))
                modify = true;
                modify_handler.Modify(f,word);               
            }


        }

        internal void ModifySources()
        {
            if (modify)
            {
                modify_handler.Save(file);
                UnityEditor.EditorUtility.SetDirty(asset);
            }
        }
    }
}