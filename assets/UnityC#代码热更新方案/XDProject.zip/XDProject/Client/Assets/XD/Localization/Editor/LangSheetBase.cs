﻿using OfficeOpenXml;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using XD.tool;
using System.Linq;
using Debug = XD.tool.Debug;
using XD.Editor;

namespace XD.Localization.Editor
{



    public abstract class LangSheetBase<T> where T : LangBase, new()
    {







        protected Distibuted<Dictionary<string, object>, List<T>> distibuted_list = new Distibuted<Dictionary<string, object>, List<T>>(8, KeyInv, CreateList);

        private static List<T> CreateList()
        {
            return new List<T>();
        }

        private static int KeyInv(Dictionary<string, object> arg)
        {
            if (arg == null || arg.Keys.Count <= 0) return 0;
            return arg.Keys.First().GetHashCode();
        }

        //private LangLog log;
        //private LangUpdate thread;



        public const int Count_Read = 1000;
        public const int Count_Export = 100;
        public const int Count_Import = 100;
        private string filepath;
        public LangSheetBase(string filepath)
        {
            this.filepath = filepath;

            //log = new LangLog();
            //ReadExcel();
            //ReadExcelOver();
        }
        internal void Over(LangUpdate.OverState e)
        {

            er = null;
            //log.OutPut();


        }







        protected abstract string GetSheetName();







        public void Export()
        {
            Debug.SetTag(Debug.tag_default, true);
            //LangFunction l_back_up = new LangFunction(UpdateBackup, Count_Read, "正在备份数据------------");
            ////LangUpdate.Create(Over, new LangFunction[] { l_back_up});
            //LangFunction l_read = new LangFunction(UpdateRead, Count_Read, "正在读取数据------------");
            //l_read.param.Set("Check", true);
            //LangFunction l_export = new LangFunction(UpdateExport, Count_Export, "正在导出数据-----------");

            //LangFunction l_save = new LangFunction(UpdateSave, 100, "正在储存数据-------------");

            //LangUpdate.Create(Over, new LangFunction[] { l_back_up, l_read, l_export, l_save });
            //l_export.param.Set("lang", lang);
            EditorCoroutineRunner.StartEditorCoroutine(RunExport());
        }
        private IEnumerator RunExport()
        {
            string log_path = $"{LangConstant.Excel_Path_Dir}/Logs/Lang_{DateTime.Now.ToString("yyyy_MM_dd_HH_mm")}.log";
            XDEditorLog.Start(log_path);
            XDEditorLog.Log("------------导出开始=");
            Backup();
            yield return UpdateRead();
            er.InitSheet(GetSheetName());


            yield return UpdateExport();
            WriteSheet();
            er.Save();

            WriteOver();

            er = null;

            XDEditorLog.Log("------------导出完成=");
            XDEditorLog.Flash();
        }

        internal abstract void WriteOver();

        private ExcelReader er;
        private IEnumerator UpdateRead()
        {
            er = new ExcelReader(filepath);
            er.SetSheet(GetSheetName());
            //ExcelRange cells = param.Get<ExcelRange>("cells", null);
            //this.package = CreatePackage(filepath);

            XDEditorLog.Log(string.Format("读取了表单,{0}", GetSheetName()), XDEditorLog.Type.Log);


            //LangLog.Log("Read Curr=" + i);



            int cell_index = 2;
            int total_count = er.GetCellsRows();
            XDEditorLog.Log("Cell_Count=" + total_count);
            while (cell_index < total_count)
            {
                ReadCell(cell_index);
                ++cell_index;
                if (cell_index % Count_Read == 0)
                {
                    XDEditorLog.Log(string.Format("读取记录{0}/{1}", cell_index - 2, total_count - 2), XDEditorLog.Type.Log);
                    yield return null;
                }
            }

            XDEditorLog.Log(string.Format("读取了{0}条记录", total_count - 2), XDEditorLog.Type.Log);

        }

        private void ReadCell(int cell_index)
        {
            //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
            T data = new T();
            data.ReadCells(cell_index, er);

            ReadCallback(data);

            //string str = data.ParseFlag();
            //if (!string.IsNullOrEmpty(str))
            //{
            //    Log(string.Format("第{0}条记录变化:{1}", cell_index, str), LangLog.Type.Log);
            //}
            if (LangConstant.Clean_Excel && (data.is_lost))
            {
            }
            else
            {
                List<T> list = distibuted_list.GetCollect(data.dic_location);
                if (LangConstant.Clean_Excel)
                {
                    T obs = GetObsoleting(data, list);

                    if (obs != null)
                    {
                        list.Remove(obs);
                    }
                }

                list.Add(data);
            }
        }

        private void Backup()
        {
            string path = LangConstant.Excel_Path_Dir;

            FileInfo ori_file = new FileInfo(filepath);
            if (ori_file != null && ori_file.Exists)
            {
                DateTime t = ori_file.LastWriteTime;


                string dir = string.Format("{0}/Backup", LangConstant.Excel_Path_Dir, t.ToString("yyyy_MM_dd"));
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                string back_filepath = string.Format("{0}/Lang_({1}).xlsx", dir, ori_file.LastWriteTime.ToString("yyyy_MM_dd_HH_mm"));
                if (!File.Exists(back_filepath))
                {
                    File.Copy(filepath, back_filepath);
                }

            }
        }

        private void UpdateBackup(IParam p, LangFunction.State state)
        {
            if (state == LangFunction.State.Enter)
            {
                Backup();
            }
            //newFile.CreationTime;
        }

        //public void Import(LangType lang)
        //{
        //    LangFunction l_read = new LangFunction(UpdateRead,Count_Read, "正在读取数据------------");
        //    l_read.param.Set("Check", false);
        //    //LangFunction l_read_over = new LangFunction(UpdateReadOver, "读取完成------------");
        //    LangFunction l_import = new LangFunction(UpdateImport,Count_Import, "正在导入数据-----------");
        //    LangFunction l_import_over = new LangFunction(UpdateImportOver,100, "导入完成------------");


        //    LangUpdate.Create(Over,  new LangFunction[] { l_read, l_import, l_import_over });

        //    //for (int i=0;i<list.Count;++i)
        //    //{
        //    //    string str = list[i].lang_list[(int)lang];
        //    //    if (!string.IsNullOrEmpty(str))
        //    //    {
        //    //        DoImport(list[i], str);
        //    //    }
        //    //}
        //    //ImportOver();
        //}


        //private void UpdateSave(IParam p, LangFunction.State state)
        //{
        //    if (state == LangFunction.State.Enter)
        //    {
        //        WriteSheet();
        //        package.Save();
        //    }

        //}


        protected abstract IEnumerator UpdateExport();
        //protected abstract void UpdateExport(IParam param, LangFunction.State state);


        //private void UpdateRead(IParam param, LangFunction.State state)
        //{
        //    if (state == LangFunction.State.Enter)
        //    {
        //        //ExcelRange cells = param.Get<ExcelRange>("cells", null);
        //        this.package = CreatePackage(filepath);
        //        ExcelWorksheet sheet = package.Workbook.Worksheets[GetSheetName()];
        //        if (sheet != null)
        //        {
        //            cells = sheet.Cells;
        //            //param.Set("cells", cells);
        //            param.SetObject(cells);
        //            int cell_count = GetCellsRows(cells) - 2;
        //            param.SetTotal(cell_count);
        //            LangLog.Log("Cell_Count=" + cell_count);
        //        }

        //    }
        //    else if (state == LangFunction.State.Run)
        //    {
        //        ExcelRange cells = param.GetObject<ExcelRange>();
        //        if (cells == null)
        //        {
        //            return;
        //        }

        //        int i = param.GetStep();

        //        //LangLog.Log("Read Curr=" + i);
        //        int cell_index = i + 2;
        //        if ((string)cells[cell_index, 1].Value != "#END")
        //        {

        //            ReadCell(cell_index);

        //        }
        //        else
        //        {
        //             Log(string.Format("读取了{0}条记录", list.Count), LangLog.Type.Log);

        //        }
        //    }
        //}

        private T GetObsoleting(T prefab, List<T> list)
        {
            T l = list.Find((t) => { return t.Compare(prefab); });
            return l;
        }



        //protected abstract void UpdateImportOver(IParam p, LangFunction.State state);

        //private void UpdateImport(IParam p, LangFunction.State state)
        //{
        //    if (state == LangFunction.State.Enter)
        //    {
        //        p.SetTotal(list.Count);
        //    }
        //    else if (state == LangFunction.State.Run)
        //    {
        //        int curr_index = p.GetStep();

        //        if (curr_index >= list.Count)
        //        {
        //            return;
        //        }

        //        LangType lang = LangMenu.GetCurrLang();

        //        string str = list[curr_index].lang_list[(int)lang];

        //        if (!string.IsNullOrEmpty(str))
        //        {
        //            DoImport(list[curr_index], str);
        //        }
        //        return;
        //    }

        //}

        ////protected abstract void ImportOver();
        //protected abstract void DoImport(T t, string str);
        //private List<T> GetList()
        //{
        //    return list;
        //}
        public void Add(T t)
        {
            List<T> list = distibuted_list.GetCollect(t.dic_location);

            T co = list.Find((o) => { return t.key == o.key; });
            if (co != null)
            {
                XDEditorLog.Log($"存在重复键值={t.key}");
            }
            list.Add(t);
        }
        public T GetLangData(Dictionary<string, object> location, string str, string key)
        {

            //T ori = null;
            List<T> list = distibuted_list.GetCollect(location);

            //T fit_location=null;
            T fit_clone = null;
            T fit_legacy = null;
            //T fit_key = null;
            list.ForEach((l) =>
            {
                if (l.flag == LangBase.Flag.Legacy)
                {
                    if (l.lang_ori.Equals(str))
                    {
                        fit_legacy = l;
                    }
                }
                else if (l.flag == LangBase.Flag.No_Change)
                {
                    if (l.lang_ori.Equals(str))
                    {
                        fit_clone = l;
                    }
                }

                //else if (l.key == key)
                //{
                //    fit_key = l;
                //}
                //else if (LangBase.CheckLocation(location, l.dic_location))
                //{
                //    fit_location = l;
                //}

            });
            T t = fit_legacy != null ? fit_legacy : fit_clone; /*fit_location != null ?fit_location:fit_key!=null?fit_key:fit_clone!=null?fit_clone:null ;*/
            if (t != null)
            {
                if (t.flag == LangBase.Flag.Legacy)
                {
                    t.SetLocation(location);
                    t.SetFlag(LangBase.Flag.No_Change);
                    t.SetOri(str, LangType.JPN);
                    return t;
                }
                else
                {
                    T clone = new T();
                    clone.SetOri(t.lang_ori, LangType.JPN);
                    clone.SetLocation(location);
                    clone.SetFlag(LangBase.Flag.Clone);
                    clone.lang_other = t.lang_other;

                    Add(clone);
                    return clone;
                }
            }
            //else if (ori != null)
            //{

            //    T clone = new T();
            //    clone.SetLocation(location);
            //    clone.SetFlag(LangBase.Flag.Append_Clone);
            //    clone.lang_list = ori.lang_list;
            //    Add(clone);
            //    return clone;

            //}
            else if (!string.IsNullOrEmpty(str))
            {
                T n = new T();
                n.SetOri(str, LangType.JPN);
                n.SetLocation(location);
                n.SetFlag(LangBase.Flag.Append);
                //prefab.SetData(path, subpath, childpath,"");
                //prefab.BindGameObject(labels[j].gameObject);
                Add(n);
                return n;
            }
            return null;
        }
        //    public T GetLangData(Dictionary<string, object> location, string str, string key, ref LangBase.Flag flag)
        //{
        //    LangBase.Flag temp = LangBase.Flag.New;
        //    T t = list.FindLast((l) =>
        //    {
        //        if (l.key == key)
        //        {
        //            temp = LangBase.Flag.Fit_Key;
        //            return true;
        //        }
        //        if (LangBase.CheckLocation(l.dic_location, location) && l.lang_list[0].Equals(str))
        //        {
        //            temp = LangBase.Flag.No_Change;
        //            return true;
        //        }
        //        return false;
        //    });
        //    flag = temp;
        //    if (t != null)
        //        return t;

        //        t = list.FindLast((l) =>
        //        {
        //            if (l.lang_list[0].Equals(str))
        //            {
        //                temp = LangBase.Flag.Fit_Reloc_Text;
        //                return true;
        //            }
        //            return false;
        //        });

        //    flag = temp;
        //    if (t != null)
        //        return t;


        //    return t;
        //    //{               
        //    //    //foreach (KeyValuePair<string,object> pair in l.dic_location)
        //    //    //{
        //    //    //    if(!pair.Value.Equals(CollectionTool.GetValue<object>(location,pair.Key)))
        //    //    //    {
        //    //    //        return false;
        //    //    //    }
        //    //    //}
        //    //    //return true;
        //    //});
        //}
        protected abstract void ReadCallback(T t);
        protected abstract void WriteCallback(T t);

        //protected void ForeachLang(Action<T> action)
        //{
        //    list.ForEach(action);
        //}
        //protected void ForeachLang(Action<T> action, Predicate<T> p)
        //{           
        //    list.ForEach((t) => { if (p(t)) action(t); });
        //}

        //public void ReadExcel()
        //{
        //    ExcelWorksheet sheet = worksheet[GetSheetName()];
        //    if (sheet != null)
        //    {
        //        ExcelRange cells = sheet.Cells;
        //        int i = 1;
        //        while ((string)cells[++i, 1].Value != "#END")
        //        {

        //            //LangLog.Log(string.Format("Load Sheet------------{0},{1},{2}.{3}", go, p, subpath, index));
        //            T prefab = new T();
        //            prefab.ReadCells(cells, i);
        //            ReadCallback(prefab);
        //            string str = prefab.ParseFlag();
        //            if(!string.IsNullOrEmpty(str))
        //            {
        //                Log(string.Format("第{0}条记录变化:{1}", i,str), LangLog.Type.Log);
        //            }
        //            list.Add(prefab);
        //        }
        //        Log(string.Format("读取了{0}条记录", list.Count), LangLog.Type.Log);
        //    }
        //}

        public void WriteSheet()
        {
            List<T>[] l = distibuted_list.GetAll();
            List<T> list = new List<T>();
            for (int i = 0; i < l.Length; ++i)
            {
                list.AddRange(l[i]);
            }
            list.Sort(SortFunc);
            int cell_offset = 2;
            for (int i = 0; i < list.Count; ++i)
            {

                T p = list[i];
                p.WriteCells(cell_offset++, er);
                WriteCallback(p);
            }
            er.WriteEnd();

        }


        public int SortFunc(T l, T r)
        {
            int v = l.flag - r.flag;
            if (v != 0)
            {
                return v;
            }
            return SortFuncEx(l, r);
        }
        protected abstract int SortFuncEx(T l, T r);





        //protected void OutputLocFile(LangType lang, string file_name)
        //{
        //    string dir_path = string.Format(LangConstant.Localization_Output_Dir, Application.dataPath, lang.ToString());
        //    if (!Directory.Exists(dir_path))
        //    {
        //        Directory.CreateDirectory(dir_path);
        //    }
        //    string file_path = dir_path + file_name;
        //    if (File.Exists(file_path))
        //    {
        //        File.Delete(file_path);
        //    }

        //    using (FileStream file = File.Open(file_path, FileMode.OpenOrCreate))
        //    {

        //        using (StreamWriter sw = new StreamWriter(file, System.Text.Encoding.Unicode))
        //        {
        //            for (int i = 0; i < list.Count; ++i)
        //            {
        //                if (!string.IsNullOrEmpty(list[i].key))
        //                {
        //                    string l = list[i].lang_list[(int)lang];
        //                    if (string.IsNullOrEmpty(l))
        //                    {
        //                        l = list[i].lang_list[0];
        //                    }
        //                    sw.WriteLine(string.Format("{0}{2}{1}", list[i].key, l, XD.Localization.Runtime.Localization.Data_Split));
        //                }
        //            }

        //        }
        //    }
        //}
    }
}