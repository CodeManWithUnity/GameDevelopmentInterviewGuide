﻿using UnityEngine;
using System;

public partial class UnityWebView : WebViewObject
{
    private string _url = "";
    void Awake()
    {
        SetScrollBounceEnabled(true);
        SetAlertDialogEnabled(true);
        Init( transparent : true,
            started : OnWebViewStart,
            ld : OnWebViewLoaded,
            httpErr : OnWebViewError,
            enableWKWebView : true,
            wkContentMode : 0,
            cb:OnCB
            );
    }

    void OnWebViewStart(string url)
    {
        OnPageStarted?.Invoke(this, url);
    }
    void OnCB(string message)
    {
        OnMessageReceived?.Invoke(this,new WebViewMessage(message));
    }

    void OnWebViewLoaded(string url)
    {
        Debug.Log("UnityWebView Loaded");
        OnPageFinished?.Invoke(this, 200, url);
    }

    void OnWebViewError(string msg)
    {
        Debug.LogWarning("UnityWebView http error : " + msg);
        OnPageFinished?.Invoke(this,400,_url);
    }


    #region Layout
    [SerializeField]
    private Vector4 frame;
    public Vector4 Frame
    {
        get { return frame; }
        set
        {
            frame = value;
            UpdateFrame();
        }
    }

    public void UpdateFrame()
    {
        Vector4 rect = NextFrameMargins();
        SetMargins((int)rect.x, (int)rect.y, (int)rect.z, (int)rect.w);
    }

    Vector4 NextFrameMargins()
    {
        if (referenceRectTransform == null)
        {
            Debug.Log("Using Frame setting to determine web view frame.");
            return frame;
        }
        else
        {
            Debug.Log("Using reference RectTransform to determine web view frame.");
            var worldCorners = new Vector3[4];

            referenceRectTransform.GetWorldCorners(worldCorners);

            var bottomLeft = worldCorners[0];
            var topLeft = worldCorners[1];
            var topRight = worldCorners[2];
            var bottomRight = worldCorners[3];

            var canvas = referenceRectTransform.GetComponentInParent<Canvas>();
            if (canvas == null)
            {
                return frame;
            }

            switch (canvas.renderMode)
            {
                case RenderMode.ScreenSpaceOverlay:
                    break;
                case RenderMode.ScreenSpaceCamera:
                case RenderMode.WorldSpace:
                    var camera = canvas.worldCamera;
                    if (camera == null)
                    {
                        Debug.LogWarning(@"You need a render camera 
                        or event camera to use RectTransform to determine correct 
                        frame for UniWebView.");
                        Debug.LogWarning("No camera found. Fall back to ScreenSpaceOverlay mode.");
                    }
                    else
                    {
                        bottomLeft = camera.WorldToScreenPoint(bottomLeft);
                        topLeft = camera.WorldToScreenPoint(topLeft);
                        topRight = camera.WorldToScreenPoint(topRight);
                        bottomRight = camera.WorldToScreenPoint(bottomRight);
                    }
                    break;
            }

            float left = topLeft.x;
            float top = Screen.height - topLeft.y;
            float right = Screen.width - bottomRight.x;
            float bottom = bottomRight.y;
            return new Vector4(left,top, right, bottom);
        }
    }

    #endregion

    #region UniWebViewInterface

    private RectTransform referenceRectTransform;

    public RectTransform ReferenceRectTransform
    {
        get
        {
            return referenceRectTransform;
        }
        set
        {
            referenceRectTransform = value;
            UpdateFrame();
        }
    }

    public void SetShowSpinnerWhileLoading(bool flag)
    {
        //UniWebViewInterface.SetShowSpinnerWhileLoading(listener.Name, flag);
    }

    public void SetHeaderField(string key, string value)
    {
        if (key == null)
        {
            Debug.LogWarning("Header key should not be null.");
            return;
        }
        AddCustomHeader(key, value);
    }

    private Color backgroundColor = Color.white;
    public Color BackgroundColor
    {
        get
        {
            return backgroundColor;
        }
        set
        {
            backgroundColor = value;
           //TODO : 修改背景颜色 
        }
    }

    public void SetHorizontalScrollBarEnabled(bool enabled)
    {
        //TODO : 设置水平滚动条
    }

    public void SetVerticalScrollBarEnabled(bool enabled)
    {
        //TODO : 设置垂直滚动条
    }

    public bool FullScreen { get; set; }
    public bool UseToolbar { get; set; }
    public void SetOpenLinksInExternalBrowser(bool flag)
    {
        //TODO : 设置是否外链打开
    }

    public void Load(string url, bool skipEncoding = false, string readAccessURL = null)
    {
        _url = url;
        LoadURL(url);
    }

    public void SetBackButtonEnabled(bool enabled)
    {

    }

    public bool Show(bool fade = false, int edge = 0, float duration = 0.4f, Action completionHandler = null)
    {
        SetVisibility(true);
        return true;
    }

    public bool Hide(bool fade = false, int edge = 0, float duration = 0.4f, Action completionHandler = null)
    {
        SetVisibility(false);
        return true;
    }

    public void Stop()
    {
        
    }


    public delegate void PageStartedDelegate(UnityWebView webView, string url);
    public event PageStartedDelegate OnPageStarted;
    public delegate void PageFinishedDelegate(UnityWebView webView, int statusCode, string url);
    public event PageFinishedDelegate OnPageFinished;
    public delegate bool ShouldCloseDelegate(UnityWebView webView);
    public event ShouldCloseDelegate OnShouldClose;
    public delegate void KeyCodeReceivedDelegate(UnityWebView webView, int keyCode);
    public event KeyCodeReceivedDelegate OnKeyCodeReceived;
    public delegate void MessageReceivedDelegate(UnityWebView webView, WebViewMessage message);
    public event MessageReceivedDelegate OnMessageReceived;



    #endregion

    public void LoadHTMLString(string htmlString, string baseUrl, bool skipEncoding = false)
    {
        LoadHTML(htmlString, baseUrl);
    }
    public void AddUrlScheme(string scheme)
    {
        if (scheme == null)
        {
          
            return;
        }

        if (scheme.Contains("://"))
        {
          
            return;
        }
        SetURLPattern(scheme,"","");
      
    }
}