﻿using System;
using UnityEngine;
#if UNITY_IOS && !UNITY_EDITOR
using ExUniWebView = UnityWebView;
#else
using ExUniWebView = UniWebView;
#endif

namespace XD.External
{
    public partial class WebView 
    {
        private string url;
        private string html_string;
        //public ViewType viewType { get; private set; } = ViewType.Rect;

       
        public System.Action onTapClose;
        public System.Action onTapReload;
        public System.Action onTapGoBack;
        public System.Action onPageFinished;
        public System.Action<WebViewMessage> onMessageReceived;
        private ExUniWebView _uniWebView;
       
        public WebView(RectTransform rt)
        {
            if (null != rt.GetComponent<UniWebView>())
            {
                GameObject.Destroy(rt.GetComponent<UniWebView>());
            }

            _uniWebView = rt.gameObject.AddComponent<ExUniWebView>();
            //RectTransform rt = this.GetComponent<RectTransform>();

            _uniWebView.ReferenceRectTransform = rt;

            _uniWebView.SetShowSpinnerWhileLoading(false);

            // WebView表示時にユーザーを特定する為のSessionIDを暗号化してヘッダーに付与

            // WebView(HTML)側でbodyの背景が設定されていない場合のデフォルト背景色を設定
            // (下記は透過設定にしていある、通常は白色になっている）
            _uniWebView.BackgroundColor = Color.white;//new Color(0, 0, 0, 0);    
        }

        public void SetUrl(string url)
        {
            this.url = url;
        }
        public void SetHtmlString(string html)
        {
            html_string = html;          
        }

        public void Show(System.Action completionHandler = null, System.Action onTapClose = null)
        {
            this.onPageFinished = completionHandler;
            this.onTapClose = onTapClose;
            ShowInterenl();
        }


        private void ShowInterenl()
        {


            if (!string.IsNullOrEmpty(url))
            {
                _uniWebView.Load(url);
            }
            if (!string.IsNullOrEmpty(html_string))
            {
                _uniWebView.LoadHTMLString(html_string,"");
            }
            _uniWebView.SetBackButtonEnabled(true);

            _uniWebView.OnPageStarted += OnPageStarted;
            _uniWebView.OnPageFinished += OnPageFinished;
            _uniWebView.OnShouldClose += OnShouldClose;
            _uniWebView.OnKeyCodeReceived += OnKeyCodeReceived;
            _uniWebView.OnMessageReceived += OnMessageReceived;

            _uniWebView.Show(false, (int)UniWebViewTransitionEdge.None, 0f, () => { });

        }


        public void AddUrlScheme(string scheme)
        {
            _uniWebView.AddUrlScheme(scheme);
        }
        public void SetHeaderField(string key, string value)
        {
            _uniWebView.SetHeaderField(key, value);
        }
        public void SetScrollBarEnabled(bool h,bool v)
        {
            _uniWebView.SetHorizontalScrollBarEnabled(h);
            _uniWebView.SetVerticalScrollBarEnabled(v);
        }
        
        public void SetToolBar(bool t)
        {
            _uniWebView.UseToolbar = t;
        }
        public void SetFullScreen(bool t)
        {
            _uniWebView.FullScreen = t;
        }
        public void Hide()
        {
            if (null != _uniWebView)
            {
                _uniWebView.Hide(false, (int)UniWebViewTransitionEdge.None, 0f, new System.Action(() => { }));

                if (null != onTapClose)
                {
                    onTapClose();
                }
                _uniWebView.OnPageStarted -= OnPageStarted;
                _uniWebView.OnShouldClose -= OnShouldClose;
                _uniWebView.OnPageFinished -= OnPageFinished;
                _uniWebView.OnKeyCodeReceived -= OnKeyCodeReceived;
                _uniWebView.OnMessageReceived -= OnMessageReceived;
            }
        }

        private void OnKeyCodeReceived(ExUniWebView webView, int keyCode)
        {
            Debug.Log(string.Format("OnKeyCodeReceived:{0}", keyCode));

            if (Application.platform == RuntimePlatform.Android)
            {
                if ((int)KeyCode.Escape == keyCode)
                {
                    Hide();
                }
            }
        }

        private bool OnShouldClose(ExUniWebView webView)
        {
            Hide();
            return _uniWebView.isActiveAndEnabled;
        }

        private void OnPageStarted(ExUniWebView webView, string url)
        {
            Debug.Log(string.Format("OnPageStarted: {0}", url));
            Uri uri = new Uri(url);
            string query = uri.Query;
            if (query.Contains("OpenExternal=1"))
            {
                webView.Stop();
                Application.OpenURL(url);
            }
        }

        private void OnPageFinished(ExUniWebView webView, int statusCode, string url)
        {
            Debug.Log(string.Format("{0}:{1}", webView.name, statusCode));

            if (null != onPageFinished)
            {
                onPageFinished();
            }
        }

        private void OnMessageReceived(ExUniWebView webView, WebViewMessage message)
        {
            Debug.Log("OnMessageRecieved");
            if (null != onMessageReceived)
            {
                onMessageReceived(message);
            }
        }

        public void Reload()
        {
            _uniWebView.Reload();

            if (null != onTapReload)
            {
                onTapReload();
            }
        }

        public void GoBack()
        {
            _uniWebView.GoBack();

            if (null != onTapGoBack)
            {
                onTapGoBack();
            }
        }

    }
}

