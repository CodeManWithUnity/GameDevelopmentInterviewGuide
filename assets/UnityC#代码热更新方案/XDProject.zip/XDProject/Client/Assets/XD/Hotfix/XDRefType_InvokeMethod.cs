namespace XD.Hotfix
{
    public partial class XDRefType
    {
        public void InvokeMethod(string name)
        {
            using (var obj = new global::IL.EmptyObjs())
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0)
        {
            using (var obj = new global::IL.Objects(p0))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1)
        {
            using (var obj = new global::IL.Objects(p0, p1))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                InvokeMethod(name, obj.objs);
            }
        }
        public void InvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                InvokeMethod(name, obj.objs);
            }
        }

        public object InvokeMethodReturn(string name)
        {
            using (var obj = new global::IL.EmptyObjs())
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0)
        {
            using (var obj = new global::IL.Objects(p0))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1)
        {
            using (var obj = new global::IL.Objects(p0, p1))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }
        public object InvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                return InvokeMethodReturn(name, obj.objs);
            }
        }

        public void TryInvokeMethod(string name)
        {
            using (var obj = new global::IL.EmptyObjs())
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0)
        {
            using (var obj = new global::IL.Objects(p0))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1)
        {
            using (var obj = new global::IL.Objects(p0, p1))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }
        public void TryInvokeMethod(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                TryInvokeMethod(name, obj.objs);
            }
        }

        public object TryInvokeMethodReturn(string name)
        {
            using (var obj = new global::IL.EmptyObjs())
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0)
        {
            using (var obj = new global::IL.Objects(p0))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1)
        {
            using (var obj = new global::IL.Objects(p0, p1))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }
        public object TryInvokeMethodReturn(string name, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9)
        {
            using (var obj = new global::IL.Objects(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9))
            {
                return TryInvokeMethodReturn(name, obj.objs);
            }
        }

    }
}
