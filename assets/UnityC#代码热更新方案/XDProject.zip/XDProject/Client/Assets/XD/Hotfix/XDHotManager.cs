﻿#if USE_HOT
namespace wxb
{
    using System.Reflection;
    using ILRuntime.CLR.Utils;
    using ILRuntime.Runtime.Stack;
    using ILRuntime.Runtime.Enviorment;
    using ILRuntime.Runtime.Intepreter;
    using System.Collections.Generic;
    using ILRuntime.CLR.TypeSystem;
    using ILRuntime.Mono.Cecil;
    using ILRuntime.Mono.Collections.Generic;
    using ILRuntime.CLR.Method;
    using global::IL;
    using XD.Hotfix;
    using System;
    using System.Text.RegularExpressions;
    using System.Text;

    public static partial class hotMgr
    {
        static void AutoReplace(UnityEngine.RuntimePlatform rp)
        {
            string rp_string = rp.ToString();
           //wxb.L.LogWarningFormat("key:{0}!", key);

            //List<UnityEngine.RuntimePlatform> platforms = new List<UnityEngine.RuntimePlatform>();
            //UnityEngine.RuntimePlatform rp = GetCurrentPlatform();
            //foreach (var ator in types)
            {
                //ILType type = ator as ILType;
               

                //platforms.Clear();

                //GetPlatform(typeDefinition.CustomAttributes, (p) => { platforms.Add(p); });
                //if (platforms.Count != 0 && !platforms.Contains(rp))
                //{
                //    wxb.L.LogWarningFormat("platorms:{0} type:{1} not hotfix!", rp, type.Name);
                //    continue; // 不属于此平台的
                //    return;
                //}
                // 相同函数名排序问题
                string xdrf = ResLoad.GetXDRF();
                if (!string.IsNullOrEmpty(xdrf))
                {
                    AutoReplaceV2(rp, rp_string, xdrf);
                }
                else
                {
                    AutoReplaceV1(rp, rp_string);
                }
            }
        }
        private static string FormatMethodName(string input)
        {
            string parttern = "[A-za-z0-9]";
            MatchCollection result = Regex.Matches(input, parttern);
            StringBuilder sb = new StringBuilder();
            foreach (var v in result)
            {
                sb.Append(v.ToString());
            }
            return sb.ToString();
        }
        private static void AutoReplaceV2(UnityEngine.RuntimePlatform rp, string rp_string,string xdrf)
        {
            string[] spxdrf = xdrf.Split('@', ',');
            string key = spxdrf[0];
            string random_name = spxdrf[1];
            if (!string.IsNullOrEmpty(key))
            {
                key = XD.tool.FastCryptUtil.Encrypt($"Sk{key.Substring(5)}XD");
            }         
            Dictionary<string, List<MethodInfo>> NameToSorted = new Dictionary<string, List<MethodInfo>>();
            string name =  XD.tool.FastCryptUtil.Encrypt(random_name, key);
            name = FormatMethodName(name);
            ILType type = appdomain.LoadedTypes[$"Hot.Generater.CYrji{name}"] as ILType;
            if (type == null)
                return;

            NameToSorted.Clear();
            var typeDefinition = type.TypeDefinition;

            //xdrf = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(xdrf));
           
            int count = (spxdrf.Length) >> 1;
            for(int i=1;i<count;++i)
            //foreach (var il in type.GetMethods())
            {
                string m = spxdrf[(i << 1) + 0];
                string r = spxdrf[(i << 1) + 1];
                IMethod il = type.GetMethod(m);
                var ilMethod = il as ILMethod;
                XD.tool.Debug.Log(() => $"AutoReplaceV2={m},r={r},il={ilMethod}", "AutoReplaceV2");

                if (ilMethod == null)
                    continue;
             
                var method = ilMethod.Definition;

                //CustomAttribute custom = method.CustomAttributes[0];
                //string cr = XD.tool.FastCryptUtil.Decrypt((string)custom.ConstructorArguments[0].Value, key);
                string cr= XD.tool.FastCryptUtil.Decrypt(r, key);
                string[] sp = cr.Split('|');

                System.Type methodType = GetTypeByName(sp[1]);
                string fieldName = sp[2];
                string hot_method_name = sp[3];
                string platform = sp.Length > 5 ? sp[4] : "";
                if (!string.IsNullOrEmpty(platform) && !platform.Contains(rp_string))
                {
                    wxb.L.LogWarningFormat("platorms:{0} type:{1}.{2} not hotfix!", rp, type.Name, ilMethod.Name);
                    continue; // 不属于此平台的
                }

                System.Type srcType = methodType;
                if (srcType == null)
                {
                    wxb.L.LogErrorFormat("type:{0} method:{1} not set srcType!", type.Name, method.Name);
                    continue;
                }

                //string fieldName = methodFieldName;
                //if (string.IsNullOrEmpty(fieldName))
                //    fieldName = "__Hotfix_" + method.Name;

                var field = srcType.GetField(fieldName, bindingFlags);
                if (field == null)
                {
                    wxb.L.LogErrorFormat("hotType:{0} method:{1} not find srcType:{2}.{3} hot field!", type.Name, method.Name, srcType.FullName, fieldName);
                    continue;
                }

                var bridge = new global::IL.DelegateBridge(ilMethod.ReflectionMethodInfo);
                field.SetValue(null, bridge);
                Fields.Add(field);
                //wxb.L.LogFormat("type:{0} method:{1} Replace {2}.{3}!", type.Name, method.Name, srcType.Name, fieldName);
                //string _hot_method_name= fieldName.Insert(8, srcType.FullName.Replace(".", "_")).Insert(8,"_");
                AutoSetFieldMethodValue(srcType, field, type, fieldName, hot_method_name, bridge, NameToSorted);
            }
        }

        private static void AutoReplaceV1(UnityEngine.RuntimePlatform rp, string rp_string )
        {
            Dictionary<string, List<MethodInfo>> NameToSorted = new Dictionary<string, List<MethodInfo>>();


            string key = "";
            ILType type = appdomain.LoadedTypes[$"Hot.Generater.HotModules"] as ILType;
            if (type == null)
                return;
            RefType ver = new RefType(true, "Hot.Generater.HotVersion");
            if (ver != null)
            {
                string v = (string)ver.GetField("Version");
                if (!string.IsNullOrEmpty(v))
                {
                    key = XD.tool.FastCryptUtil.Encrypt($"Sk{v.Substring(5)}XD");
                }
            }
            foreach (var il in type.GetMethods())
            {
                var ilMethod = il as ILMethod;
                if (ilMethod == null)
                    continue;

                var method = ilMethod.Definition;

                CustomAttribute custom = method.CustomAttributes[0];
                string cr = XD.tool.FastCryptUtil.Decrypt((string)custom.ConstructorArguments[0].Value, key);
                string[] sp = cr.Split('|');

                System.Type methodType = GetTypeByName(sp[1]);
                string fieldName = sp[2];
                string hot_method_name = sp[3];
                string platform = sp.Length > 5 ? sp[4] : "";
                if (!string.IsNullOrEmpty(platform) && !platform.Contains(rp_string))
                {
                    wxb.L.LogWarningFormat("platorms:{0} type:{1}.{2} not hotfix!", rp, type.Name, ilMethod.Name);
                    continue; // 不属于此平台的
                }

                System.Type srcType = methodType;
                if (srcType == null)
                {
                    wxb.L.LogErrorFormat("type:{0} method:{1} not set srcType!", type.Name, method.Name);
                    continue;
                }

                //string fieldName = methodFieldName;
                //if (string.IsNullOrEmpty(fieldName))
                //    fieldName = "__Hotfix_" + method.Name;

                var field = srcType.GetField(fieldName, bindingFlags);
                if (field == null)
                {
                    wxb.L.LogErrorFormat("hotType:{0} method:{1} not find srcType:{2}.{3} hot field!", type.Name, method.Name, srcType.FullName, fieldName);
                    continue;
                }

                var bridge = new global::IL.DelegateBridge(ilMethod.ReflectionMethodInfo);
                field.SetValue(null, bridge);
                Fields.Add(field);
                //wxb.L.LogFormat("type:{0} method:{1} Replace {2}.{3}!", type.Name, method.Name, srcType.Name, fieldName);
                //string _hot_method_name= fieldName.Insert(8, srcType.FullName.Replace(".", "_")).Insert(8,"_");
                AutoSetFieldMethodValue(srcType, field, type, fieldName, hot_method_name, bridge, NameToSorted);
            }
        }

        static void AutoSetFieldMethodValue(System.Type srcType, FieldInfo srcFieldInfo, ILType type, string fieldName, string hot_field_name, DelegateBridge bridge, Dictionary<string, List<MethodInfo>> NameToSorted)
        {
            //var auto_fieldInfo = FindStaticField(type, hot_field_name);
            //if (auto_fieldInfo == null || auto_fieldInfo.FieldType.FullName != "wxb.Hotfix")
            //    return;

            var fieldInfo = type.ReflectionType.GetField(hot_field_name, bindingFlags);


            MethodInfo srcMethodInfo = null;
            {
                string methodName = fieldName.Substring(9);
                int last = methodName.LastIndexOf('_');
                if (last == -1)
                {
                    srcMethodInfo = IL.Help.GetMethod(srcType, methodName);
                }
                else
                {
                    int value = 0;
                    bool isInt = int.TryParse(methodName.Substring(last + 1), out value);
                    if (!isInt)
                    {
                        srcMethodInfo = IL.Help.GetMethod(srcType, methodName);
                    }
                    else
                    {
                        methodName = methodName.Substring(0, last);
                        List<MethodInfo> methods = null;
                        if (!NameToSorted.TryGetValue(methodName, out methods))
                        {
                            methods = FindMethodInfo(srcType, methodName);
                            NameToSorted.Add(methodName, methods);
                        }

                        if (value < methods.Count && value >= 0)
                        {
                            srcMethodInfo = methods[value];
                        }
                    }
                }

                if (srcMethodInfo == null)
                {
                    wxb.L.LogErrorFormat("type:{0} method:{1} not find by Field!", type.Name, methodName, fieldName);
                    return;
                }
            }

            Hotfix hotfix = new Hotfix(srcFieldInfo, srcMethodInfo, bridge);
            XD.tool.DataManager.Set(hot_field_name, hotfix, "Hotfix");
            if (fieldInfo == null)
            {
                wxb.L.LogErrorFormat("type:{0} fieldInfo:{1} find but not find clrType fieldInfo!", type.Name, fieldName);
                return;
            }
            fieldInfo.SetValue(null, hotfix);
        }
        public static void ReleaseAll()
        {
            if (appdomain == null)
                return;

            ResLoad.Set(null);
            //refType.TryInvokeMethod("ReleaseAll");
            //var types = new Dictionary<string, IType>(appdomain.LoadedTypes);
            //InitByProperty(typeof(AutoInitAndRelease), "Release", AllTypes);
            XD.tool.DataManager.UnitSet("Hotfix");
            foreach (var ator in Fields)
                ator.SetValue(null, null);
            Fields.Clear();

            IL.Help.ReleaseAll();
            //AllTypes.Clear();
            //AllTypes = null;
            refType = null;
            appdomain = null;
            if (DllStream != null)
            {
                DllStream.Close();
                DllStream = null;
            }

#if USE_PDB || USE_MDB
            if (SymbolStream != null)
            {
                SymbolStream.Close();
                SymbolStream = null;
            }
#endif
            System.GC.Collect();
        }


    }

}
#endif