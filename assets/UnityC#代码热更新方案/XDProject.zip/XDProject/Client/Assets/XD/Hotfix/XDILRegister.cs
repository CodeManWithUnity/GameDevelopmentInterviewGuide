﻿#if USE_HOT
using ILRuntime.CLR.Method;
using ILRuntime.Runtime.Enviorment;
using ILRuntime.Runtime.Intepreter;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using XD.tool;
using XD.Unity;
using AppDomain = ILRuntime.Runtime.Enviorment.AppDomain;
using Debug = XD.tool.Debug;

namespace XD.Hotfix
{
    [System.AttributeUsage(System.AttributeTargets.Method)]
    public partial class XDRF : System.Attribute
    {       
        public XDRF(string typeName)
        {

        }
    }
    public partial class XDILRegister
    {
        public const string Tag = "XDILRegister";
        private string config;
        private AppDomain appdomain;
        private static char[] split = new char[] { '|', ',' };
        public XDILRegister(string config)
        {
            if (string.IsNullOrEmpty(config))
            {
                return;
            }
            //XDDelegateProxy.Initialize();
            this.config = config;
            strategy.Regist("[RM]", (line) =>
            {
                string[] vals = line.Split(split);
                Type[] types = new Type[vals.Length];
                for (int i = 0; i < vals.Length; ++i)
                {
                    types[i] = TypeCollection.Get(vals[i]);
                }
                MethodInfo m = RegisterMethodDelegate[types.Length - 1].MakeGenericMethod(types);
                m.Invoke(appdomain.DelegateManager, null);
                return 1;
                //appDomain.DelegateManager.RegisterMethodDelegate()
            });
            strategy.Regist("[RF]", (line) =>
            {
                string[] vals = line.Split(split);
                Type[] types = new Type[vals.Length];
                for (int i = 0; i < vals.Length; ++i)
                {
                    types[i] = TypeCollection.Get(vals[i]);

                    //Debug.LogWarning(() => $"vals[i]={vals[i]},types[i]={types[i]}", Tag);
                }
                MethodInfo m = RegisterFunctionDelegate[types.Length - 1].MakeGenericMethod(types);
                m.Invoke(appdomain.DelegateManager, null);
                return 1;
                //appDomain.DelegateManager.RegisterMethodDelegate()
            });
            strategy.Regist("[RD]", (line) =>
            {
                //string[] vals = line.Split('|');
                //Type[] types = new Type[vals.Length];
                //for (int i = 0; i < vals.Length; ++i)
                //{
                //    types[i] = ReflectionTool.ParseDelgateType(vals[i]) ;

                //    Debug.LogWarning(() => $"vals[i]={vals[i]},types[i]={types[i]}", Tag);
                //}
                //Debug.LogWarning(() => $"line={line}", Tag);
                Type t1 = ReflectionTool.ParseDelgateType(line);
                Type t2 = ReflectionTool.TransSystemDelgateType(t1);
                //Debug.LogWarning(() => $"t1={t1},t2={t2}", Tag);
                MethodInfo me = RegisterDelegateConvertor.MakeGenericMethod(new Type[] { t1 });
                //MethodInfo gen = MakeGen.MakeGenericMethod();
                //object make_res = MakeGen.Invoke(this, new Type[] { t1, t2 });
                Func<Delegate, Delegate> make_res = MakeGenDelegate(t1, t2);
                me.Invoke(appdomain.DelegateManager, new object[] { make_res });
                return 1;
            });
        }
        private MethodInfo[] RegisterMethodDelegate, RegisterFunctionDelegate;
        private MethodInfo RegisterDelegateConvertor;
        public void RegistApp(AppDomain appDomain)
        {
            this.appdomain = appDomain;

            RegisterMethodDelegate = new MethodInfo[10];
            RegisterFunctionDelegate = new MethodInfo[10 + 1];
            Type type = typeof(DelegateManager);
            foreach (MethodInfo me in type.GetMethods())
            {
                if (me.Name == "RegisterMethodDelegate")
                {
                    int length = me.GetGenericArguments().Length;
                    //Debug.LogWarning(() => $"RegisterMethodDelegate Args={length},Method={me}", Tag);
                    RegisterMethodDelegate[length - 1] = me;
                }
                else if (me.Name == "RegisterFunctionDelegate")
                {
                    int length = me.GetGenericArguments().Length;
                    //Debug.LogWarning(() => $"RegisterFunctionDelegate Args={length},Method={me}", Tag);
                    RegisterFunctionDelegate[length - 1] = me;
                }
                else if (me.Name == "RegisterDelegateConvertor")
                {
                    RegisterDelegateConvertor = me;
                }
            }

        }
        private Func<Delegate, Delegate> MakeGenDelegate(Type t_ori, Type t_System)
        {
            Func<Delegate, Delegate> res = (act) => {
                XDDelegateProxy proxy = new XDDelegateProxy(act);
                Delegate d = proxy.GetDelegate(t_ori, t_System);
                //Delegate d = (Delegate)m.Invoke(this, new object[] { act });
                //Debug.LogWarning(() => $"MakeGenDelegate Invoke ={act},Method={act}, d={d}", Tag);
                return d;
            };
            return res;
        }




        public void RegistCBA()
        {
            appdomain.RegisterCrossBindingAdaptor(new UnityHandleAdaptor());
            appdomain.RegisterCrossBindingAdaptor(new XDRefTypeAdaptor());
        }
        private string opt = "";
        private Strategy<string, string, int> strategy = new Strategy<string, string, int>((v) => -1);
        public void RegistIL(AppDomain appdomain)
        {
            if(string.IsNullOrEmpty(config))
            {
                return;
            }
            string[] lines = config.Split('\n');
            CollectionTool.ForAsc<string>(lines, (index, line) =>
            {
                line = line.Trim();
                if (string.IsNullOrEmpty(line)||line.StartsWith("--")) return;
                if (line.StartsWith("[") && line.EndsWith("]")) opt = line;

                else strategy.Excute(opt, line);
            });

        }
        public partial class UnityHandleAdaptor : CrossBindingAdaptor
        {
            public override Type BaseCLRType => typeof(UnityHandle);

            public override Type AdaptorType => typeof(Adaptor);
            public override object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILTypeInstance instance)
            {
                return new Adaptor(appdomain, instance);
            }
            internal class Adaptor : UnityHandle, CrossBindingAdaptorType
            {
                ILTypeInstance instance;
                ILRuntime.Runtime.Enviorment.AppDomain appdomain;



                public Adaptor(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILTypeInstance instance) : base(false)
                {
                    this.appdomain = appdomain;
                    this.instance = instance;
                    UnityInteraction.Regist(this);
                }



                public ILTypeInstance ILInstance { get { return instance; } }

                IMethod mGetRecieverMethod;
                bool mGetRecieverMethodGot;


                public override string GetReciever()
                {

                    if (!mGetRecieverMethodGot)
                    {
                        mGetRecieverMethod = instance.Type.GetMethod("GetReciever", 0);
                        if (mGetRecieverMethod == null)
                        {
                            //这里写System.Collections.IEnumerator.get_Current而不是直接get_Current是因为coroutine生成的类是显式实现这个接口的，通过Reflector等反编译软件可得知
                            //为了兼容其他只实现了单一Current属性的，所以上面先直接取了get_Current
                            mGetRecieverMethod = instance.Type.GetMethod("XD.Unity.UnityHandle.GetReciever", 0);
                        }
                        mGetRecieverMethodGot = true;
                    }

                    if (mGetRecieverMethod != null)
                    {
                        var res = appdomain.Invoke(mGetRecieverMethod, instance, null);
                        return (string)res;
                    }
                    else
                    {
                        return null;
                    }

                }
                IMethod mOnResponseMethod;
                bool mOnResponseMethodGot;

                protected override void OnResponse(IDictionary result, string error)
                {
                    if (!mOnResponseMethodGot)
                    {
                        mOnResponseMethod = instance.Type.GetMethod("OnResponse", 1);
                        if (mOnResponseMethod == null)
                        {
                            //这里写System.Collections.IEnumerator.get_Current而不是直接get_Current是因为coroutine生成的类是显式实现这个接口的，通过Reflector等反编译软件可得知
                            //为了兼容其他只实现了单一Current属性的，所以上面先直接取了get_Current
                            mOnResponseMethod = instance.Type.GetMethod("XD.Unity.UnityHandle.OnResponse", 1);
                        }
                        mOnResponseMethodGot = true;
                    }

                    if (mOnResponseMethod != null)
                    {
                        appdomain.Invoke(mOnResponseMethod, instance, result, error);

                    }

                }
            }
        }

        public partial class XDRefTypeAdaptor : CrossBindingAdaptor
        {
            public override Type BaseCLRType => typeof(XDRefType);

            public override Type AdaptorType => typeof(Adaptor);
            public override object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILTypeInstance instance)
            {
                return new Adaptor(appdomain, instance);
            }
            internal class Adaptor : XDRefType, CrossBindingAdaptorType
            {
                ILTypeInstance instance;
                ILRuntime.Runtime.Enviorment.AppDomain appdomain;

                public Adaptor(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILTypeInstance instance) : base()
                {
                    this.appdomain = appdomain;
                    this.instance = instance;                   
                }
                public ILTypeInstance ILInstance { get { return instance; } }
            }
        }

    }
}
#endif