﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

using UnityEngine.UI;
using XD.Attribute;
using XD.tool;
using System.Linq;
using Debug = UnityEngine.Debug;
using XD.Editor;
using XD.Editor.Finder;


[XDEditorName("按TM文本查找")]
public class FinderWithTMText : IFinder
{
    private string text;
    //private List<string> datas = new List<string>();

    public void Check(GameObject obj, Action<GameObject> callback)
    {
      
        Action<GameObject, string> action = (t, str) =>
         {
             if (str.ToLower().Contains(text.ToLower()))
             {
                 callback(t);
                //FinderWindow.CheckGamobject(t, (arg) => true, obj.name, node => datas.Add(FinderWindow.DataParam("Path", node.path, "text", str)));
            }
         };

#if LOCALIZATION_UGUI_PRO
        CheckAll<TMPro.TextMeshProUGUI>(obj, (l) => action(l.gameObject, l.text));
#endif
  

    }

    private void CheckAll<T>(GameObject obj, Action<T> get)
    {
        T[] t = obj.GetComponentsInChildren<T>(true);
        if (t != null)
        {
            for (int i = 0; i < t.Length; ++i)
            {
                get(t[i]);
            }
        }
    }

  

    public bool Input()
    {
        XDEditorUI.Horizontal(() =>
        {
            EditorGUILayout.LabelField("Text", GUILayout.Width(200));
            text = EditorGUILayout.TextField(text, GUILayout.Width(300));
        }, 1);

        return !string.IsNullOrEmpty(text);
    }

    public bool IsTraverse()
    {
        return false;
    }
}
