﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using XD.tool;
using Debug = UnityEngine.Debug;
using XD.Editor;
using XD.Editor.Finder;

namespace XD.Localization.Editor
{
    public static class DebugReplace
    {
        // Start is called before the first frame update
        [MenuItem("本地化/Script功能/替换Debug.Log")]
        public static void Replace()
        {
            Action<string> action = (filepath) =>
            {
                bool exclude = false;
                for (int i = 0; i < LangConstant.File_Exclude.Length; ++i)
                {
                    if (filepath.IndexOf(LangConstant.File_Exclude[i]) >= 0)
                    {
                        exclude = true;
                        break;
                    }
                }
                if (!filepath.EndsWith(".cs"))
                {
                    return;
                }
                if (exclude)
                {
                    return;
                }
                var src = AssetDatabase.LoadAssetAtPath<TextAsset>(filepath);
                if (src == null)
                {
                    return;
                }
                Replace(filepath, src.text);
            };
            string[] test = new string[] { "Assets/Orange/Scripts/FileDownload" };
            EditorCoroutineRunner.StartEditorCoroutine(Traveral.ForeachText(LangConstant.File_Directionay, action));
        }
        private static List<string> list_source = new List<string>() { "WebAPIDebug.Logger.Log","PaymentDebug.Log", "UNDebug.Log","UnityEngine.Debug.Log",  "XD.tool.Debug.Log", "Debug.Log", };
        //private static string append = "XD.tool.Debug.IsTagEnable({0})";
        private static string replaced = "XD.tool.Debug.";
    
        private static void Replace(string filepath, string text)
        {
            
            string tag = Path.GetFileNameWithoutExtension(filepath);
            string[] lines = LangCSFormat.SplitSrcs(text);
            bool modify = false;
            string appendline = $"if(XD.tool.Debug.IsTagEnable(\"{tag}\"))";
            CollectionTool.ForAsc<string>(lines, (i, line) =>
            {
                string l ;
                if (line.Contains("Error") || line.Contains("Exception"))
                {
                    l = $"if(XD.tool.Debug.IsTagEnable(\"LogError\"))";
                }
                else
                {
                    l = appendline;
                }
                int rep_index = 0;
                int end_index = line.Length;
                while ((rep_index = line.LastIndexOf(l, end_index, end_index)) >= 0)
                {
                    end_index = rep_index;
                }
               
                lines[i] = ApplendLine(line, l, end_index, ref modify);
                //while ((rep_index = line.LastIndexOf(replaced, end_index, end_index)) >= 0)
                //{
                //    end_index = rep_index;
                //}
                //lines[i] = ReplaceLine(line, tag, end_index, ref modify);
            });
            if (modify)
            {
                LangCSFormat.ModifySources(filepath, lines);
            }
        }

        private static string ApplendLine(string line, string append, int end_index, ref bool modify)
        {
            int fit_index = -1;
            int index = -1;
            for (int i = 0; i < list_source.Count; ++i)
            {

                if ((fit_index = line.LastIndexOf(list_source[i], end_index)) >= 0)
                {
                    index = i;
                    break;
                }
            }
            if (fit_index >= 0 && index >= 0)
            {
               

                //Debug.Log($"Replace2={line}");
                line = line.Insert(fit_index, append);
                //Debug.Log($"Replace3={line}");
                modify = true;
                return ApplendLine(line, append, fit_index, ref modify);

            }
            return line;
        }

        private static string ReplaceLine(string line, string tag, int end_index, ref bool modify)
        {
            int fit_index = -1;
            int index = -1;
            for (int i = 0; i < list_source.Count; ++i)
            {

                if ((fit_index = line.LastIndexOf(list_source[i], end_index)) >= 0)
                {
                    index = i;
                    break;
                }
            }
            if (fit_index >= 0 && index >= 0)
            {

                //Debug.Log($"Find Fit end_index=={end_index},fit_index={fit_index} in line={line},Tag={tag}");
                int r_index = line.LastIndexOf(')', end_index-1, end_index- fit_index-1);
                int l_index = line.IndexOf('(', fit_index);
                if (r_index > l_index && l_index >= fit_index)
                {
                    //Debug.Log($"Find Fit r_index=={r_index},l_index={l_index} ");
                    line = line.Remove(r_index, 1).Insert(r_index, $",\"{tag}\")");
                    //Debug.Log($"Replace1={line}");
                    line = line.Remove(l_index, 1).Insert(l_index, "(()=>");
                    //Debug.Log($"Replace2={line}");
                    line = line.Remove(fit_index, list_source[index].Length).Insert(fit_index, replaced);
                    //Debug.Log($"Replace3={line}");
                    modify = true;
                    return ReplaceLine(line, tag, fit_index, ref modify);
                }
            }
            return line;
        }

     
    }
}