﻿#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using XD.tool;
using XD.Xml;
using Debug = UnityEngine.Debug;
using System.Xml;
using XD.Editor.Hook;

namespace XD.Editor.Build
{

    internal class Explorer : IBuildCommond
    {
        public void Build(RXMLCommond cmd)
        {

            string dir = BuildTool.GetPath(cmd.GetValue("dir"));

            if (!Directory.Exists(dir))
            {
                throw new Exception($"Dir Not Finded={dir}");
            }

#if UNITY_EDITOR_WIN
            System.Diagnostics.Process.Start("explorer.exe", dir.Replace("/", "\\"));
#endif
        }
    }
    internal class ZIP : IBuildCommond
    {
        public void Build(RXMLCommond cmd)
        {

            string source = BuildTool.GetPath(cmd.GetValue("source"));
            string target = BuildTool.GetPath(cmd.GetValue("target"));
            string password = cmd.GetValue("password");
            int level = cmd.GetAttribute<int>("level");
            FileEX.DirCheckAndCreate(target);
            XDZip.Archieve(target, source, password, level);
            string version = DateTime.Now.ToString("yyyyMMddHHmmss");
            byte[] data=File.ReadAllBytes(target);
            int size = data.Length;
            string fun = cmd.GetValue("varify");// "simple";
            string hash = BinaryVarify.Varify(fun, data);
            FileEX.WriteAllText($"{target}_ver", $"{version},{size},{fun}={hash}");
        }
    }
    internal class BuildFunc : IBuildFunc
    {
        public void Build(string[] scenes, string target_dir, BuildTarget target, BuildOptions buildOptions)
        {
            object res = BuildPipeline.BuildPlayer(scenes, target_dir, target, buildOptions);
            if (res is string str_res)
            {
                if(!string.IsNullOrEmpty(str_res))
                throw new Exception("BuildPlayer failure: " + str_res);
            }
            else if (res != null)
            {              
                Debug.Log("BuildPlayer Result: " + res);
            }
        }
    }
}
#endif