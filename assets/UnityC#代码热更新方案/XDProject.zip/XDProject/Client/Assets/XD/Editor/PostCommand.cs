﻿#if UNITY_EDITOR
using UnityEditor;
using Unity2017.iOS.Xcode;
using System.IO;
using XD.Xml;
using System.Collections.Generic;
using System.Xml;

namespace XD.Editor.Build
{
    internal class RenameOBB : IPostCommond
    {
        public void Post(RXMLCommond cmd)
        {
            string tar = BuildTool.GetBuildDir();
            string obb_file = tar.Replace(".apk", ".main.obb");
            FileInfo file_obb_main = new FileInfo(obb_file);
            if(File.Exists(obb_file))
            {
             
               
                string obb_dir = BuildTool.GetPath("../TargetAndroid/[build_time]");//Path.GetDirectoryName(tar);
                string apk_new_path = $"{obb_dir}/{Path.GetFileName(tar)}";
                string obb_new_path = $"{obb_dir}/main.{PlayerSettings.Android.bundleVersionCode}.{PlayerSettings.applicationIdentifier}.obb";
                Directory.CreateDirectory(obb_dir);
                FileInfo file_apk = new FileInfo(tar);
                file_apk.MoveTo(apk_new_path);
                file_obb_main.MoveTo(obb_new_path);
            }
        }
    }
    internal class PBXSetting : IPostCommond
    {
        private static PBXProject pbx_project;
        public static string GetPBXPath()
        {
            return BuildTool.GetBuildDir() + "/Unity-iPhone.xcodeproj/project.pbxproj";
        }
        internal static PBXProject GetPBXProject()
        {
            string projPath = GetPBXPath();

            if (File.Exists(projPath))
            {
                PBXProject proj = new PBXProject();
                proj.ReadFromString(File.ReadAllText(projPath));
                pbx_project = proj;
            }
            return pbx_project;
        }

        internal static void SavePBX()
        {
            string projPath = GetPBXPath();
            pbx_project.WriteToFile(projPath);
        }
        public void Post(RXMLCommond cmd)
        {
            PBXProject proj = GetPBXProject();
            string projName = PBXProject.GetUnityTargetName();
            string target = proj.TargetGuidByName(projName);

            RxmlNode profile = cmd.GetChild<RxmlNode>("profile");
            if (profile != null)
            {
                UnityEditor.PlayerSettings.iOS.appleEnableAutomaticSigning = false;
                proj.SetBuildProperty(target, "CODE_SIGN_IDENTITY", profile.GetAttribute<string>("CODE_SIGN_IDENTITY"));
                proj.SetBuildProperty(target, "DEVELOPMENT_TEAM", profile.GetAttribute<string>("DEVELOPMENT_TEAM"));
                proj.SetBuildProperty(target, "PROVISIONING_PROFILE", profile.GetAttribute<string>("PROVISIONING_PROFILE_ID"));
                proj.SetBuildProperty(target, "PROVISIONING_PROFILE_SPECIFIER", profile.GetAttribute<string>("PROVISIONING_PROFILE_SPECIFIER"));
            }

            RxmlNode settings = cmd.GetChild<RxmlNode>("settings");
            if (settings!=null)
            {            
                proj.SetBuildProperty(target, "ENABLE_BITCODE", settings.GetAttribute<string>("bitcode"));
                proj.SetBuildProperty(target, "EMBEDDED_CONTENT_CONTAINS_SWIFT", settings.GetAttribute<string>("embed_swift"));
                proj.SetBuildProperty(target, "ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES", settings.GetAttribute<string>("always_embed_swift_lib"));
                proj.SetBuildProperty(target, "SWIFT_VERSION", settings.GetAttribute<string>("swift_version"));
            }
            SavePBX();


            RxmlNode caps = cmd.GetChild<RxmlNode>("capability");
            if (caps != null)
            {
                string[] apps = PlayerSettings.applicationIdentifier.Split('.');
                string aps = $"{apps[apps.Length-1]}.entitlements";
                UnityEngine.Debug.Log($"BuildTool.GetPBXPath()={GetPBXPath()},aps={aps},target={target}");
                
                string targetFile = $"{BuildTool.GetBuildDir()}/{projName}/{aps}";
                var file_name = System.IO.Path.GetFileName(targetFile);
                var targetEntitlementsFile = PBXProject.GetUnityTargetName() + "/" + file_name; 
                
                ProjectCapabilityManager pc = new ProjectCapabilityManager(GetPBXPath(), targetEntitlementsFile, projName);
                string[] caps_value = caps.GetAttributes<string>("value", ",");
                UnityEngine.Debug.Log ("PBXCapabilityType Length=" + caps_value.Length);
                foreach (var cap in caps_value)
                {
                    AddCapbility(pc,cap);
                    UnityEngine.Debug.Log ("PBXCapabilityType Type="+cap);                   
                }
                pc.WriteToFile();
            }            
        }
    
        private void AddCapbility(ProjectCapabilityManager pc,string capbility)
        {
            switch (capbility)
            {
                case "InAppPurchase":
                    pc.AddInAppPurchase();
                    break;
                case "PushNotifications":
                    pc.AddPushNotifications(false);
                    break;
                case "SignInWithApple":
                    pc.AddSignInWithApple();
                    break;                
                default:
                    UnityEngine.Debug.LogWarning ($"PBXCapabilityType Type {capbility} has not been defined");                  
                    break;
            }
        }
    }

    //internal class PlistProcess : IPostCommond
    //{
    //    public void Post(RXMLCommond cmd, RXMLBuildSetting setting)
    //    {
    //        //RXMLID infos = cmd.GetAttribute<RXMLID>("plist");
    //        //// 编辑plist 文件
    //        ////string Infos = IOSConfig.Get("Info");
    //        //if (infos != null)
    //        {
    //            string aimPath = BuildTool.GetBuildDir() + System.IO.Path.DirectorySeparatorChar + "Info.plist";
    //            //string[] Info = Infos.Split(',');

    //            string srcPath = cmd.GetValue("plist");
    //            srcPath = BuildTool.GetPath(srcPath);
    //            PInfoTool.ChangeIosInfo(srcPath, aimPath);

    //            Dictionary<string, string> dic = new Dictionary<string, string>();
    //            dic.Add("{package}", PlayerSettings.applicationIdentifier);

    //            string text = System.IO.File.ReadAllText(aimPath);
    //            //Debug.Log(xmlString);
    //            foreach (KeyValuePair<string, string> pair in dic)
    //            {
    //                text = text.Replace(pair.Key, pair.Value);
    //            }
    //            text = text.Replace("[]", "");
    //            //dst.Save(dst_file);
    //            System.IO.File.WriteAllText(aimPath, text);
    //        }
    //    }
    //}
    //internal class PInfoTool
    //{

    //    public static void ChangeIosInfo(string path_src, string path_dest)
    //    {
    //        UnityEngine.Debug.Log("ChangeIosInfo:" + path_src + "  ," + path_dest);
    //        XmlDocument doc_source = new XmlDocument();
    //        doc_source.Load(path_src);
    //        XmlDocument doc_target = new XmlDocument();
    //        doc_target.Load(path_dest);
    //        XmlNode root_source = doc_source.DocumentElement;
    //        XmlNode root_target = doc_target.DocumentElement;

    //        XmlNode dictRoot_source = root_source.SelectSingleNode("dict");
    //        XmlNode dictRoot_target = root_target.SelectSingleNode("dict");

    //        ErgodicNode(doc_target, dictRoot_source, dictRoot_target);
    //        doc_target.Save(path_dest);

    //    }

    //    private static void ErgodicNode(XmlDocument doc_target, XmlNode dictRoot_source, XmlNode dictRoot_target)
    //    {
    //        XmlNodeList list_key_source = dictRoot_source.SelectNodes("key");
    //        XmlNodeList list_key_target = dictRoot_target.SelectNodes("key");
    //        foreach (XmlNode node_source in list_key_source)
    //        {
    //            bool has = false;
    //            if (node_source.Name == "key")
    //            {
    //                foreach (XmlNode node_target in list_key_target)
    //                {
    //                    if (node_source.InnerText == node_target.InnerText)
    //                    {
    //                        has = true;
    //                        MergeNode(doc_target, dictRoot_target, node_source, node_target);
    //                        break;
    //                    }
    //                }
    //                if (!has)
    //                {
    //                    XmlNode nodetemp1 = doc_target.ImportNode(node_source, true);
    //                    dictRoot_target.AppendChild(nodetemp1);
    //                    XmlNode nodetempNext = doc_target.ImportNode(node_source.NextSibling, true);
    //                    dictRoot_target.AppendChild(nodetempNext);

    //                }
    //            }
    //        }
    //    }

    //    private static void MergeNode(XmlDocument doc_target, XmlNode dictRoot_target, XmlNode node_source, XmlNode node_target)
    //    {

    //        if (node_source.NextSibling.Name == "dict")
    //        {
    //            ErgodicNode(doc_target, node_source.NextSibling, node_target.NextSibling);
    //        }
    //        else if (node_source.NextSibling.Name == "array")
    //        {
    //            foreach (XmlNode node_child in node_source.NextSibling.ChildNodes)
    //            {
    //                XmlNode node_import = doc_target.ImportNode(node_child, true);
    //                node_target.NextSibling.AppendChild(node_import);
    //            }
    //        }
    //        else
    //        {
    //            XmlNode node_import = doc_target.ImportNode(node_source.NextSibling, true);
    //            dictRoot_target.ReplaceChild(node_import, node_target.NextSibling);
    //        }
    //    }
    //}

}
#endif