﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class XDHotTest : MonoBehaviour
{
    [SerializeField]
    private Text text1;
    [SerializeField]
    private Text text2;
    [SerializeField]
    private Text text3;
    [SerializeField]
    private Text text4;
    [SerializeField]
    private Text text5;

    // Start is called before the first frame update
    void Start()
    {
        text1.text = proptype;
        text2.text = Func();
        Action();
    }
    private string proptype { get { return "-------------正常属性"; } }

    private string Func()
    {
        return "-------------------正常方法";
    }
    private void Action()
    {
        text3.text = "---------------正常调用的方法";
    }

    private void Action2()
    {
        text3.text = "---------------从外部调用的方法";
    }
    public void OnButton()
    {
        text5.text = "---------------没反应";
    }

    public void Update()
    {
       
    }
}