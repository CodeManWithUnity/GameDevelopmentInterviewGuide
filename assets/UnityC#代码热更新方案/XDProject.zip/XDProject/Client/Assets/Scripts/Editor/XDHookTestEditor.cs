﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XD.Editor;
using XD.tool;

public class XDHookTestEditor : IXDXmlCache
{
    public void Regist(Action<string, Func<Transform[], string>> fun)
    {
        fun("ParticleColor", (ts) =>
        {
            ParticleSystem tm = ts[0].GetComponent<ParticleSystem>();
            if (tm == null)
            {
                return "";
            }
            UnityEngine.Debug.Log($"tm.main.startColor={tm.main.startColor.color}");
            return DeserializeStrategy.Deserialize(tm.main.startColor.color);
        });
    }
}
