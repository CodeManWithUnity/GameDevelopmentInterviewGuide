﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using XD.Attribute;
using XD.Hook;
using XD.Xml;

[XDEditorName("我是测试"), RequireComponent(typeof(ParticleSystem))]
[XDEditorUsage(XDEditorUsageAttribute.ValueType.User)]
public class XDHookTest : XDHookInterface
{
    public class RXMLTest : RxmlNode
    {
        [RxmlField, XDEditorValue("ParticleColor")]
        public Color color;
    }
    public bool DestroyOnFire()
    {
        return true;
    }

    public void FireEvent(XDPluginHookN go, RxmlNode xml, XDHookStep step)
    {
        ParticleSystem p = go.GetComponent<ParticleSystem>();
        if(p==null)
        {
            return;
        }
        RXMLTest a = (RXMLTest)xml;

        if (a.HasAttribute("color"))
        {
            ParticleSystem.MainModule main = p.main;
            main.startColor = a.color;
        }
    }

    public XDHookStep GetStep()
    {
        return XDHookStep.Awake;
    }

    public Type GetXmlType()
    {
        return typeof(RXMLTest);
    }
}