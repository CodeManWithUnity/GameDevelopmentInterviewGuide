﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using XD.Hook;
using XD.Hotfix;
using XD.Mono;
using XD.tool;

public class XDHotLoader : MonoBehaviour
{
    // Start is called before the first frame update
    IEnumerator Start()
    {
        XDInitialize.Excute();
        yield return LoadHotfix();
        yield return LoadHook();
        AsyncOperation sync = SceneManager.LoadSceneAsync(1);
        yield return sync;
    }
    private static wxb.RefType ref_app;
    public IEnumerator LoadHotfix()
    {

        byte[] dydata = null;
                string local = PathUnity.GetStreamingRead("Data/dydata");
                yield return UrlRequest.RequestE(local, (data) => { dydata = data; });

       
     
      
        if (ref_app != null)
        {
            //RefType refType_r = new RefType("Hot.HotAppInitialize");
            IEnumerator e_r = (IEnumerator)ref_app.TryInvokeMethodReturn("Release");
            ref_app = null;
            yield return e_r;
        }
        UnityEngine.RuntimePlatform rp =UnityEngine.Application.platform;
        yield return CoroutineManager.EnumeratorWithThread(() => Init(dydata, "", rp));
        dydata = null;
        ref_app = new wxb.RefType("Hot.HotAppInitialize");
        IEnumerator e = (IEnumerator)ref_app.TryInvokeMethodReturn("Initialize");
        if (e != null)
        {
            yield return e;
        }
    }
    public static void Init(byte[] data, string config, UnityEngine.RuntimePlatform rp)
    {

        if (data != null)
        {
            data = XDCryptor.Decrypt(data);
        }
        //wxb.L.Set(null);
        XD.Loader.LoaderFunc.DllLoader l = data != null ? new XD.Loader.LoaderFunc.DllLoader(data) : null;
        //CrossBindingAdaptor[] cba = new CrossBindingAdaptor[] { new UnityHandleAdaptor() };
        wxb.hotMgr.Init(new XDILRegister(config), rp, l);



    }
    public IEnumerator LoadHook()
    {
        byte[] hook_data = null;
        string local = PathUnity.GetStreamingRead("Data/hook");
        yield return UrlRequest.RequestE(local, (data) => { hook_data = data; });

        if (hook_data != null)
        {
            XDHookManager.Clear();
            //yield return new WaitForSeconds(wait_duration);
            //hook_data = XDCryptor.Decrypt(hook_data);
            //yield return new WaitForSeconds(wait_duration);
            //string text = System.Text.Encoding.UTF8.GetString(hook_data);
            //yield return new WaitForSeconds(wait_duration);
            //hook_data = null;

            //yield return new WaitForSeconds(wait_duration);
            //XDHookManager.LoadSettings(text);
            //yield return new WaitForSeconds(wait_duration);
            yield return CoroutineManager.EnumeratorWithThread(() =>
            {
                hook_data = XDCryptor.Decrypt(hook_data);

                XDHookManager.LoadSettings(hook_data, XDHookManager.Format.Json);
                hook_data = null;
            });

        }
    }

}
