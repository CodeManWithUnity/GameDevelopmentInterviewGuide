﻿using System;
using XD.Attribute;
using XD.Hook;
using XD.Xml;

[XDEditorName("Hot事件")]
[XDEditorUsage(XDEditorUsageAttribute.ValueType.Developer)]
public partial class XDHookHotEvent : XDHookInterface
{
    public partial class RxmlEventParam : RxmlNode
    {
        [RxmlField]
        public string param_1;
        [RxmlField]
        public string param_2;
        [RxmlField]
        public string param_3;
    }
    public partial class RxmlEvent : RxmlNode
    {
        [RxmlField]
        public RxmlEventParam attach;
        [RxmlField]
        public RxmlEventParam awake;
        [RxmlField]
        public RxmlEventParam start;
        [RxmlField]
        public RxmlEventParam enable;
        [RxmlField]
        public RxmlEventParam disable;
        [RxmlField]
        public RxmlEventParam destroy;
    }
    public Type GetXmlType()
    {
        return typeof(RxmlEvent);
    }
    private void FireEvent(RxmlEventParam p, XDPluginHookN go)
    {
        if (p == null)
        {
            return;
        }
        HotEventProcess.Fire(p, go);
    }
    //public void OnAwake(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.awake,go);
    //}
    //public void OnDestroy(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.destroy,go);
    //}

    //public void OnDisable(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.disable,go);
    //}

    //public void OnEnable(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.enable,go);
    //}

    //public void Start(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.start,go);
    //}

    //public void OnAttach(XDPluginHookN go, RxmlNode xml)
    //{
    //    RxmlEvent evt = (RxmlEvent)xml;
    //    FireEvent(evt.attach, go);
    //}

    public void FireEvent(XDPluginHookN go, RxmlNode xml, XDHookStep step)
    {
        RxmlEvent evt = (RxmlEvent)xml;
        switch (step)
        {
            case XDHookStep.Attach:
                FireEvent(evt.attach, go);
                break;
            case XDHookStep.Awake:
                FireEvent(evt.awake, go);
                break;
            case XDHookStep.Destory:
                FireEvent(evt.destroy, go);
                break;
            case XDHookStep.Disable:
                FireEvent(evt.disable, go);
                break;
            case XDHookStep.Enable:
                FireEvent(evt.enable, go);
                break;
            case XDHookStep.Start:
                FireEvent(evt.start, go);
                break;

        }
    }

    public bool DestroyOnFire()
    {
        return false;
    }

    public XDHookStep GetStep()
    {
        return XDHookStep.All;
    }
}
public partial class HotEventProcess
{
    public static void Fire(XDHookHotEvent.RxmlEventParam p, XDPluginHookN go)
    {

    }
}